<?php
header("Location: https://calc.lomsia.ge/public/login.php");
exit;
