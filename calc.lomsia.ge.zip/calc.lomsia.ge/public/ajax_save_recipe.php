<?php
require_once __DIR__ . '/../config/db.php';

header('Content-Type: application/json');

if (!isset($_POST['dish_id']) || !isset($_POST['ingredients'])) {
    echo json_encode(['status' => 0, 'message' => 'არასაკმარისი მონაცემები']);
    exit;
}

$dish_id = intval($_POST['dish_id']);
$ingredients = json_decode($_POST['ingredients'], true);

if (!is_array($ingredients)) {
    echo json_encode(['status' => 0, 'message' => 'არასწორი მონაცემების ფორმატი']);
    exit;
}

try {
    $pdo->beginTransaction();
    
    // წაშალე ძველი ინგრედიენტები
    $stmt = $pdo->prepare("DELETE FROM dish_calc WHERE dish_id = ?");
    $stmt->execute([$dish_id]);
    
    // დაუმატე ახალი ინგრედიენტები
    $stmt = $pdo->prepare("
        INSERT INTO dish_calc (dish_id, product_id, quantity, unit, yield_coeff) 
        VALUES (?, ?, ?, ?, ?)
    ");
    
    foreach ($ingredients as $ingredient) {
        $stmt->execute([
            $dish_id,
            intval($ingredient['product_id']),
            floatval($ingredient['quantity']),
            $ingredient['unit'],
            floatval($ingredient['yield_coeff'] ?? 1.00)
        ]);
    }
    
    $pdo->commit();
    
    echo json_encode(['status' => 1, 'message' => 'რეცეპტი წარმატებით შეინახა']);
    
} catch (PDOException $e) {
    $pdo->rollBack();
    echo json_encode(['status' => 0, 'message' => 'ბაზის შეცდომა: ' . $e->getMessage()]);
}
?>