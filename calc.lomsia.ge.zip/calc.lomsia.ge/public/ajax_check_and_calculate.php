<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../config/db.php';

// მონაცემების მიღება
$dish_id = intval($_POST['dish_id'] ?? 0);
$quantity = intval($_POST['quantity'] ?? 1);
$unit_price = floatval($_POST['unit_price'] ?? 0);

if ($dish_id <= 0) {
    echo json_encode(['status' => 0, 'message' => 'არასწორი კერძი']);
    exit;
}

try {
    // გამოვთვალოთ VAT-ის სტატუსი has_vat ველის მიხედვით
    $sql = "SELECT dc.id, dc.dish_id, dc.product_id, dc.quantity, dc.unit, dc.yield_coeff,
                   p.name as product_name, p.price, 
                   p.has_vat, -- ვიყენებთ სწორ ველს
                   p.quantity as stock
            FROM dish_calc dc 
            JOIN products p ON dc.product_id = p.id 
            WHERE dc.dish_id = ?";
    
    $stmt = $mysqli->prepare($sql);
    $stmt->bind_param("i", $dish_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $ingredients = $result->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
    
    if (empty($ingredients)) {
        echo json_encode(['status' => 0, 'message' => 'კერძს არ აქვს რეცეპტი']);
        exit;
    }
    
    $response_ingredients = [];
    $total_cost_with_vat = 0;
    $total_cost_excluding_vat = 0;
    $all_enough_stock = true;
    $low_stock_products = [];
    
    // 2. გამოვთვალოთ თითოეული ინგრედიენტის ღირებულება
    foreach ($ingredients as $ing) {
        $required = floatval($ing['quantity']) * $quantity;
        $available = floatval($ing['stock']);
        $has_enough = $available >= $required;
        
        if (!$has_enough) {
            $all_enough_stock = false;
            $low_stock_products[] = [
                'product_name' => $ing['product_name'],
                'required' => $required,
                'available' => $available,
                'unit' => $ing['unit']
            ];
        }
        
        // ღირებულების გაანგარიშება
        $cost_with_vat = $required * floatval($ing['price']);
        $has_vat = intval($ing['has_vat']);
        
        if ($has_vat == 0) {
            // დღგ-ის გარეშე - ფასი უკვე დღგ-ს გარეშეა
            $cost_excluding_vat = $cost_with_vat;
        } else {
            // დღგ-თი - გამოვთვალოთ დღგ-ს გარეშე
            $cost_excluding_vat = $cost_with_vat / 1.18;
        }
        
        $total_cost_with_vat += $cost_with_vat;
        $total_cost_excluding_vat += $cost_excluding_vat;
        
        $response_ingredients[] = [
            'product_id' => $ing['product_id'],
            'product_name' => $ing['product_name'],
            'quantity' => $ing['quantity'],
            'required' => round($required, 3),
            'available' => round($available, 3),
            'has_enough' => $has_enough,
            'unit' => $ing['unit'],
            'price' => floatval($ing['price']),
            'has_vat' => $has_vat,
            'cost_with_vat' => round($cost_with_vat, 2),
            'cost_excluding_vat' => round($cost_excluding_vat, 2)
        ];
    }
    
    // 3. გაყიდვების ანალიზი
    $total_revenue = $unit_price * $quantity;
    $net_amount = $total_revenue / 1.18; // დღგ-ს გარეშე
    $vat_amount = $total_revenue - $net_amount; // დღგ
    $profit = $net_amount - $total_cost_excluding_vat;
    $margin_percent = $total_cost_excluding_vat > 0 ? ($profit / $total_cost_excluding_vat) * 100 : 0;
    
    // 4. პასუხის მომზადება
    $response = [
        'status' => 1,
        'ingredients' => $response_ingredients,
        'cost_details' => [
            'cost_with_vat' => round($total_cost_with_vat, 2),
            'cost_excluding_vat' => round($total_cost_excluding_vat, 2),
            'total_revenue' => round($total_revenue, 2),
            'net_amount' => round($net_amount, 2),
            'vat_amount' => round($vat_amount, 2),
            'profit' => round($profit, 2),
            'margin_percent' => round($margin_percent, 2),
            'unit_price' => $unit_price,
            'quantity' => $quantity
        ],
        'stock_status' => [
            'all_enough' => $all_enough_stock,
            'low_stock_products' => $low_stock_products,
            'can_proceed' => $all_enough_stock
        ]
    ];
    
    // თუ არ არის საკმარისი ნაშთი, გაგზავნეთ გაფრთხილება
    if (!$all_enough_stock) {
        $response['status'] = 2; // გაფრთხილების სტატუსი
        $response['message'] = 'გაფრთხილება: ზოგიერთ პროდუქტს არ აქვს საკმარისი ნაშთი';
    }
    
    echo json_encode($response);
    
} catch (Exception $e) {
    echo json_encode([
        'status' => 0, 
        'message' => 'შეცდომა: ' . $e->getMessage()
    ]);
}
?>