<?php
require_once __DIR__ . '/../config/db.php';

$dishId = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($dishId <= 0) {
    echo json_encode(['status' => 0, 'message' => 'არასწორი კერძის ID']);
    exit;
}

// ვამოწმებთ menu_id სვეტის არსებობას
$checkQuery = $mysqli->query("SHOW COLUMNS FROM dishes LIKE 'menu_id'");
$hasMenuId = $checkQuery->num_rows > 0;

if ($hasMenuId) {
    $query = "SELECT id, name, sale_price, cost_price, menu_id, enable_vat, active FROM dishes WHERE id = ?";
} else {
    $query = "SELECT id, name, sale_price, cost_price, enable_vat, active FROM dishes WHERE id = ?";
}

$stmt = $mysqli->prepare($query);
$stmt->bind_param('i', $dishId);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $dish = $result->fetch_assoc();
    echo json_encode([
        'status' => 1,
        'dish' => $dish
    ]);
} else {
    echo json_encode(['status' => 0, 'message' => 'კერძი ვერ მოიძებნა']);
}

$stmt->close();
?>