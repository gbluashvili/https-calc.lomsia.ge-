<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../config/db.php';

error_log("=== SALE PROCESS STARTED ===");
error_log("POST data: " . print_r($_POST, true));

// ვალიდაცია
$dish_id = isset($_POST['dish_id']) ? (int)$_POST['dish_id'] : 0;
$quantity = isset($_POST['quantity']) ? (int)$_POST['quantity'] : 1;
$dish_name = isset($_POST['dish_name']) ? trim($_POST['dish_name']) : '';
$unit_price = isset($_POST['unit_price']) ? (float)$_POST['unit_price'] : 0;
$total_price = isset($_POST['total_price']) ? (float)$_POST['total_price'] : 0;

if ($dish_id <= 0 || $quantity <= 0 || $unit_price <= 0) {
    echo json_encode([
        'status' => 0,
        'message' => 'არასწორი მონაცემები'
    ]);
    exit();
}

// ტრანზაქციის დაწყება
$mysqli->begin_transaction();

try {
    // 1. შევამოწმოთ მარაგი
    $check_sql = "SELECT 
                    dc.product_id,
                    dc.quantity as required_per_unit,
                    p.name as product_name,
                    p.quantity as current_stock
                  FROM dish_calc dc
                  JOIN products p ON dc.product_id = p.id
                  WHERE dc.dish_id = ?";
    
    $check_stmt = $mysqli->prepare($check_sql);
    $check_stmt->bind_param("i", $dish_id);
    $check_stmt->execute();
    $check_result = $check_stmt->get_result();
    
    $low_stock_items = [];
    
    while ($row = $check_result->fetch_assoc()) {
        $required = (float)$row['required_per_unit'] * $quantity;
        $available = (float)$row['current_stock'];
        
        if ($available < $required) {
            $low_stock_items[] = [
                'product_id' => $row['product_id'],
                'product_name' => $row['product_name'],
                'required' => $required,
                'available' => $available
            ];
        }
    }
    
    $check_stmt->close();
    
    if (!empty($low_stock_items)) {
        echo json_encode([
            'status' => 0,
            'message' => 'არასაკმარისი მარაგი',
            'low_stock_items' => $low_stock_items
        ]);
        exit();
    }
    
    // 2. გამოვთვალოთ ღირებულება (სწორად VAT-ით)
    $cost_sql = "SELECT 
                    SUM(p.price * dc.quantity * ?) as total_raw_cost,
                    SUM(
                        CASE 
                            WHEN p.has_vat = 0 THEN p.price * dc.quantity * ?
                            ELSE (p.price * dc.quantity * ?) / 1.18
                        END
                    ) as cost_excluding_vat
                 FROM dish_calc dc
                 JOIN products p ON dc.product_id = p.id
                 WHERE dc.dish_id = ?";
    
    $cost_stmt = $mysqli->prepare($cost_sql);
    $cost_stmt->bind_param("dddi", $quantity, $quantity, $quantity, $dish_id);
    $cost_stmt->execute();
    $cost_result = $cost_stmt->get_result();
    $cost_data = $cost_result->fetch_assoc();
    $cost_stmt->close();
    
    $total_raw_cost = (float)($cost_data['total_raw_cost'] ?? 0);
    $cost_excluding_vat = (float)($cost_data['cost_excluding_vat'] ?? 0);
    $cost_with_vat = $total_raw_cost;
    
    // 3. განვაახლოთ მარაგი
    $update_sql = "UPDATE products p
                   JOIN dish_calc dc ON p.id = dc.product_id
                   SET p.quantity = p.quantity - (dc.quantity * ?)
                   WHERE dc.dish_id = ?";
    
    $update_stmt = $mysqli->prepare($update_sql);
    $update_stmt->bind_param("di", $quantity, $dish_id);
    $update_stmt->execute();
    
    if ($update_stmt->affected_rows === -1) {
        throw new Exception('მარაგის განახლება ვერ მოხერხდა');
    }
    
    $update_stmt->close();
    
    // 4. დავამატოთ გაყიდვა sales ცხრილში
    $net_amount = $total_price / 1.18;
    $vat_amount = $total_price * 0.18;
    $profit = $net_amount - $cost_excluding_vat;
    $margin_percent = $cost_excluding_vat > 0 ? ($profit / $cost_excluding_vat) * 100 : 0;
    
    $sale_sql = "INSERT INTO sales 
                 (dish_id, dish_name, quantity, net_amount, vat_amount, total_amount, 
                  sale_price, total_price, cost_with_vat, cost_excluding_vat, 
                  profit, margin_percent, total_with_vat, 
                  unit_cost_with_vat, unit_cost_excluding_vat, unit_profit) 
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    
    $sale_stmt = $mysqli->prepare($sale_sql);
    
    // პარამეტრები
    $total_amount = $cost_with_vat;
    $sale_price = $unit_price;
    $total_with_vat = $total_price;
    $unit_cost_with_vat = $quantity > 0 ? $cost_with_vat / $quantity : 0;
    $unit_cost_excluding_vat = $quantity > 0 ? $cost_excluding_vat / $quantity : 0;
    $unit_profit = $quantity > 0 ? $profit / $quantity : 0;
    
    $sale_stmt->bind_param(
        "isiidddddddddddd",
        $dish_id,
        $dish_name,
        $quantity,
        $net_amount,
        $vat_amount,
        $total_amount,
        $sale_price,
        $total_price,
        $cost_with_vat,
        $cost_excluding_vat,
        $profit,
        $margin_percent,
        $total_with_vat,
        $unit_cost_with_vat,
        $unit_cost_excluding_vat,
        $unit_profit
    );
    
    $sale_stmt->execute();
    $sale_id = $mysqli->insert_id;
    $sale_stmt->close();
    
    // 5. დავამატოთ dish_sales ცხრილშიც
    $dish_sale_sql = "INSERT INTO dish_sales (dish_id, dish_name, quantity, unit_price, total_price) 
                      VALUES (?, ?, ?, ?, ?)";
    
    $dish_sale_stmt = $mysqli->prepare($dish_sale_sql);
    $dish_sale_stmt->bind_param("isidd", $dish_id, $dish_name, $quantity, $unit_price, $total_price);
    $dish_sale_stmt->execute();
    $dish_sale_stmt->close();
    
    // ტრანზაქციის დასრულება
    $mysqli->commit();
    
    echo json_encode([
        'status' => 1,
        'message' => 'გაყიდვა წარმატებით დასრულდა',
        'sale_id' => $sale_id,
        'details' => [
            'cost' => [
                'cost_with_vat' => $cost_with_vat,
                'cost_excluding_vat' => $cost_excluding_vat
            ],
            'sale' => [
                'total_with_vat' => $total_price,
                'net_amount' => $net_amount,
                'vat_amount' => $vat_amount,
                'profit' => $profit,
                'margin_percent' => $margin_percent
            ]
        ]
    ]);
    
} catch (Exception $e) {
    $mysqli->rollback();
    error_log('Sale error: ' . $e->getMessage());
    
    echo json_encode([
        'status' => 0,
        'message' => 'გაყიდვის შეცდომა: ' . $e->getMessage()
    ]);
}

$mysqli->close();
?>