<?php
require_once __DIR__ . '/../config/db.php';

header('Content-Type: application/json');

if (!isset($_POST['id'])) {
    echo json_encode(['status' => 0, 'message' => 'ID არ არის მითითებული']);
    exit;
}

$id = intval($_POST['id']);

try {
    $stmt = $pdo->prepare("DELETE FROM dish_calc WHERE id = ?");
    $stmt->execute([$id]);
    
    if ($stmt->rowCount() > 0) {
        echo json_encode(['status' => 1, 'message' => 'ინგრედიენტი წაიშალა']);
    } else {
        echo json_encode(['status' => 0, 'message' => 'ჩანაწერი არ მოიძებნა']);
    }
    
} catch (PDOException $e) {
    echo json_encode(['status' => 0, 'message' => 'ბაზის შეცდომა: ' . $e->getMessage()]);
}
?>