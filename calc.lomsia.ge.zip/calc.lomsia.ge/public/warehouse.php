<?php
// მაგალითად: /home/mvpuufsr/calc/calc.lomsia.ge/public/warehouse.php
session_start();
require_once __DIR__ . '/../config/db.php';

// ავტორიზაციის შემოწმება
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

// წვდომის შემოწმება
require_once __DIR__ . '/../includes/auth_check.php';

// ავტომატურად შეამოწმეთ წვდომა
checkAccessAndRedirect($conn);
?>

<!-- დანარჩენი HTML/PHP კოდი -->
<?php

// ბაზასთან დაკავშირების შემოწმება
if (!$mysqli) {
    die("ბაზასთან დაკავშირება ვერ მოხერხდა: " . ($mysqli->connect_error ?? "Unknown error"));
}

// პროდუქტის მონაცემები ბაზიდან
$products = [];
$result = $mysqli->query("SELECT * FROM products ORDER BY id ASC");
if ($result) {
    $products = $result->fetch_all(MYSQLI_ASSOC);
    $result->free();
} else {
    echo "<div class='alert alert-danger'>შეცდომა მონაცემების მიღებისას: " . $mysqli->error . "</div>";
}

// კრიტიკული ნაშთი
$low_stock = array_filter($products, function($p) {
    return isset($p['quantity'], $p['min_quantity']) && 
           (float)$p['quantity'] <= (float)$p['min_quantity'] && 
           (float)$p['min_quantity'] > 0;
});

// მიღების/ჩამოწერის ფორმის ჩვენება
$show_purchase = isset($_GET['action']) && $_GET['action'] == 'purchase';
$show_waste = isset($_GET['action']) && $_GET['action'] == 'waste';
?>
<!DOCTYPE html>
<html lang="ka">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>საწყობის მართვა</title>
<?php 
    include '../includes/header.php';?>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css">
<script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet"/>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<link rel="stylesheet" href="../css/style.css">
</head>
<body>

<div class="container">
    <div class="tab-container">
        <div class="tab-buttons">
            <button class="btn btn-green" onclick="showProductForm()">+ ახალი პროდუქტი</button>
            <button class="btn btn-blue" onclick="$('#purchaseFormDiv').toggle(); $('.form-container').not('#purchaseFormDiv').hide();">📥 მიღება</button>
            <button class="btn btn-red" onclick="$('#wasteFormDiv').toggle(); $('.form-container').not('#wasteFormDiv').hide();">🗑️ ჩამოწერა</button>
            <a href="sales_history.php" class="btn btn-orange">📈 გაყიდვების ისტორია</a>
            <a href="index.php" class="btn btn-gray">← უკან</a>
        </div>
    </div>

    <?php if(!empty($low_stock)): ?>
    <div class="alert-box">
        <strong>⚠️ კრიტიკული ნაშთი:</strong> 
        <?= htmlspecialchars(implode(', ', array_map(function($p) {
            return $p['name'] . " (" . $p['quantity'] . " " . $p['unit'] . ")";
        }, $low_stock))) ?>
    </div>
    <?php endif; ?>

    <!-- პროდუქტის დამატების/რედაქტირების ფორმა -->
    <div id="productFormDiv" class="form-container" style="display: <?= $show_purchase || $show_waste ? 'none' : 'block' ?>; border-top:5px solid #00c292;">
        <h3 id="productFormTitle">📦 პროდუქტის მართვა</h3>
        <div class="form-body">
            <div class="pur-grid">
                <div class="form-group">
                    <label>დასახელება:</label>
                    <input type="text" id="new_p_name" autocomplete="off" placeholder="დაიწყეთ აკრეფა პროდუქტის სახელისთვის...">
                    <div id="productSuggestions" class="search-suggestions"></div>
                </div>
                <div class="form-group">
                    <label>ერთეული:</label>
                    <select id="new_p_unit">
                        <option value="კგ">კგ</option>
                        <option value="გრ">გრ</option>
                        <option value="ლიტრი">ლიტრი</option>
                        <option value="ცალი">ცალი</option>
                        <option value="მეტრი">მეტრი</option>
                        <option value="ტონა">ტონა</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>ნაშთი:</label>
                    <input type="number" id="new_p_qty" step="0.001" min="0" value="0">
                    <span id="qty_unit_display" class="unit-display">კგ</span>
                </div>
                <div class="form-group">
                    <label>თვითღირებულება:</label>
                    <input type="number" id="new_p_price" step="0.01" min="0" value="0">
                </div>
                <div class="form-group">
                    <label>მინ. ზღვარი:</label>
                    <input type="number" id="new_p_limit" step="0.001" min="0" value="1">
                </div>
                <div class="form-group">
                    <label><input type="checkbox" id="new_p_vat"> ფასი VAT-ით (18%)</label>
                </div>
            </div>
            <button class="btn btn-blue" id="saveNewProduct">✅ შენახვა</button>
            <button class="btn btn-gray" onclick="$('#productFormDiv').hide()">✖️ გაუქმება</button>
        </div>
    </div>

    <!-- 📥 მიღების ფორმა -->
    <div id="purchaseFormDiv" class="form-container" style="display: <?= $show_purchase ? 'block' : 'none' ?>; border-top:5px solid #28a745;">
        <h3>📥 პროდუქტის მიღება</h3>
        <div class="form-body">
            <div class="pur-grid">
                <div class="form-group">
                    <label>პროდუქტი:</label>
                    <select id="pur_product_id" class="select2">
                        <option value="0">-- აირჩიე პროდუქტი --</option>
                        <?php foreach($products as $p): 
                            $vat = ($p['vat_status'] == 'დღგ-თი' || $p['vat_rate'] > 0) ? 1 : 0;
                        ?>
                        <option value="<?= htmlspecialchars($p['id']) ?>" 
                                data-unit="<?= htmlspecialchars($p['unit']) ?>" 
                                data-vat="<?= $vat ?>">
                            <?= htmlspecialchars($p['name']) ?> (<?= htmlspecialchars($p['quantity']) ?> <?= htmlspecialchars($p['unit']) ?>)
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>რაოდენობა (დამატება ნაშთში):</label>
                    <input type="number" id="pur_qty_pack" step="0.001" min="0.001" value="0" required>
                    <span id="unit_display" style="margin-left:5px; color:#666;">კგ</span>
                </div>
                <div class="form-group">
                    <label>ფასი (ჯამი):</label>
                    <input type="number" id="pur_total_amount" step="0.01" min="0" value="0" required>
                </div>
                <div class="form-group">
                    <label><input type="checkbox" id="pur_vat"> ფასი VAT-ით (18%)</label>
                </div>
                <div class="form-group">
                    <label>მომწოდებელი:</label>
                    <input type="text" id="pur_supplier" placeholder="მომწოდებლის სახელი">
                </div>
                <div class="form-group">
                    <label>შენიშვნა:</label>
                    <input type="text" id="pur_notes" placeholder="დამატებითი ინფორმაცია">
                </div>
            </div>
            <button class="btn btn-green" id="savePurchase">✅ მიღების შენახვა</button>
            <button class="btn btn-gray" onclick="$('#purchaseFormDiv').hide()">✖️ გაუქმება</button>
        </div>
    </div>

    <!-- 🗑️ ჩამოწერის ფორმა -->
    <div id="wasteFormDiv" class="form-container" style="display: <?= $show_waste ? 'block' : 'none' ?>; border-top:5px solid #dc3545;">
        <h3>🗑️ პროდუქტის ჩამოწერა</h3>
        <div class="form-body">
            <div class="pur-grid">
                <div class="form-group">
                    <label>პროდუქტი:</label>
                    <select id="waste_product_id" class="select2">
                        <option value="0">-- აირჩიე პროდუქტი --</option>
                        <?php foreach($products as $p): ?>
                        <option value="<?= htmlspecialchars($p['id']) ?>" 
                                data-unit="<?= htmlspecialchars($p['unit']) ?>" 
                                data-current="<?= htmlspecialchars($p['quantity']) ?>">
                            <?= htmlspecialchars($p['name']) ?> (<?= htmlspecialchars($p['quantity']) ?> <?= htmlspecialchars($p['unit']) ?>)
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>რაოდენობა (ნაშთიდან გამოკლება):</label>
                    <input type="number" id="waste_qty" step="0.001" min="0.001" value="0" required>
                    <span id="waste_unit_display" style="margin-left:5px; color:#666;">კგ</span>
                    <small class="text-muted">მაქსიმალური: <span id="max_waste_qty">0</span></small>
                </div>
                <div class="form-group">
                    <label>მიზეზი:</label>
                    <select id="waste_reason">
                        <option value="დაზიანება">დაზიანება</option>
                        <option value="ვადის გასვლა">ვადის გასვლა</option>
                        <option value="დანაკარგი">დანაკარგი</option>
                        <option value="სხვა">სხვა</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>დამატებითი ინფორმაცია:</label>
                    <input type="text" id="waste_notes" placeholder="დამატებითი ინფორმაცია">
                </div>
            </div>
            <button class="btn btn-red" id="saveWaste">✅ ჩამოწერის შენახვა</button>
            <button class="btn btn-gray" onclick="$('#wasteFormDiv').hide()">✖️ გაუქმება</button>
        </div>
    </div>

    <div class="table-container">
        <h2>📦 საწყობში არსებული პროდუქტები</h2>
        <table id="productTable" class="display compact">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>სახელი</th>
                    <th>ნაშთი</th>
                    <th>ზღვარი</th>
                    <th>ერთ.</th>
                    <th>ფასი</th>
                    <th>VAT</th>
                    <th>მოქმედება</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach($products as $p): 
                $vat = ($p['vat_status'] == 'დღგ-თი' || $p['vat_rate'] > 0) ? 1 : 0;
            ?>
                <tr data-id="<?= htmlspecialchars($p['id']) ?>" 
                    data-vat="<?= $vat ?>"
                    data-name="<?= htmlspecialchars($p['name']) ?>"
                    data-unit="<?= htmlspecialchars($p['unit']) ?>"
                    data-quantity="<?= htmlspecialchars($p['quantity']) ?>"
                    data-price="<?= htmlspecialchars($p['price']) ?>"
                    data-min_limit="<?= htmlspecialchars($p['min_quantity'] ?? 0) ?>">
                    <td><?= htmlspecialchars($p['id']) ?></td>
                    <td><?= htmlspecialchars($p['name']) ?></td>
                    <td><?= number_format((float)$p['quantity'], 3, '.', '') ?></td>
                    <td><?= number_format((float)($p['min_quantity'] ?? 0), 3, '.', '') ?></td>
                    <td><?= htmlspecialchars($p['unit']) ?></td>
                    <td><?= number_format((float)$p['price'], 2, '.', '') ?></td>
                    <td><input type="checkbox" disabled <?= $vat ? 'checked' : '' ?>></td>
                    <td>
    <button class="btn btn-cyan editProduct" data-id="<?= htmlspecialchars($p['id']) ?>">რედაქტირება</button>
    <button class="btn btn-red deleteProduct" data-id="<?= htmlspecialchars($p['id']) ?>">წაშლა</button>
</td>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
const products_js = <?= json_encode($products) ?>;
let selectedProduct = null;

function showProductForm(product=null){
    $('#productFormTitle').text('📦 ახალი პროდუქტი');
    $('#new_p_name').val('');
    $('#new_p_qty').val('0');
    $('#new_p_price').val('0');
    $('#new_p_limit').val('1');
    $('#new_p_unit').val('კგ');
    $('#qty_unit_display').text('კგ');
    $('#new_p_vat').prop('checked', false);
    
    // ყველა ფორმის ჩვენება/დამალვა
    $('#productFormDiv').show();
    $('#purchaseFormDiv').hide();
    $('#wasteFormDiv').hide();
    selectedProduct = null;

    if(product){
        $('#productFormTitle').text('📦 პროდუქტის რედაქტირება: ' + product.name);
        $('#new_p_name').val(product.name);
        $('#new_p_unit').val(product.unit).trigger('change');
        $('#new_p_qty').val(product.quantity);
        $('#new_p_price').val(product.price);
        $('#new_p_limit').val(product.min_quantity || 0);
        $('#new_p_vat').prop('checked', (product.vat_status == 'დღგ-თი' || product.vat_rate > 0 || product.has_vat == 1) ? true : false);
        selectedProduct = product.id;
        
        // უზრუნველვყოთ, რომ ერთეულის დისფლეიც განახლდება
        setTimeout(() => {
            $('#qty_unit_display').text(product.unit || 'კგ');
        }, 100);
    }
}

$(document).ready(function(){
    console.log('Products loaded:', products_js.length);
    
    // ინიციალიზაცია
    $('#qty_unit_display').text($('#new_p_unit').val());
    
    // Select2 ინიციალიზაცია
    try {
        $('.select2').select2({
            width: '100%'
        });
    } catch(e) {
        console.log('Select2 error:', e);
    }
    
    // DataTable ინიციალიზაცია - ზრდადობის მიხედვით
    try {
        $('#productTable').DataTable({
    "pageLength": 25,
    "language": {
        "url": "//cdn.datatables.net/plug-ins/1.11.5/i18n/ka.json"
    },
    "order": [[0, "asc"]], // ID ზრდადობით (0 არის პირველი სვეტი)
    "columnDefs": [
        { "orderable": false, "targets": [7] }
    ]
});
    } catch(e) {
        console.log('DataTable error:', e);
    }

    // ერთეულის ცვლილება პროდუქტის ფორმაში
    $('#new_p_unit').on('change', function(){
        $('#qty_unit_display').text($(this).val());
    });

    // ერთეულის ცვლილება მიღების ფორმაში
    $('#pur_product_id').on('change', function(){
        const selected = $(this).find('option:selected');
        const unit = selected.data('unit') || 'კგ';
        const vat = selected.data('vat') || 0;
        $('#unit_display').text(unit);
        $('#pur_vat').prop('checked', vat == 1);
    });

    // ერთეულის ცვლილება ჩამოწერის ფორმაში
    $('#waste_product_id').on('change', function(){
        const selected = $(this).find('option:selected');
        const unit = selected.data('unit') || 'კგ';
        const currentQty = parseFloat(selected.data('current')) || 0;
        $('#waste_unit_display').text(unit);
        $('#max_waste_qty').text(currentQty.toFixed(3));
        $('#waste_qty').attr('max', currentQty).val(Math.min(currentQty, parseFloat($('#waste_qty').val()) || 0));
    });

    // "ახალი პროდუქტი" ღილაკის ფუნქცია
    $(document).on('click', '.btn-green:contains("+ ახალი პროდუქტი")', function(){
        console.log('ახალი პროდუქტი ღილაკზე დაჭერა');
        showProductForm();
    });

    // ძებნის სისტემა - განახლებული ვერსია
    $('#new_p_name').on('input', function() {
        let term = $(this).val().toLowerCase();
        let suggestions = $('#productSuggestions');
        if(term.length < 2){ 
            suggestions.hide().empty(); 
            return; 
        }
        
        // დავალაგოთ პროდუქტები ზრდადობის მიხედვით
        let filtered = products_js.filter(p => p.name.toLowerCase().includes(term));
        filtered.sort((a, b) => a.name.localeCompare(b.name, 'ka'));
        
        if(filtered.length > 0){
            let html = '<ul>';
            filtered.forEach(p => {
                let vatStatus = (p.vat_status == 'დღგ-თი' || p.vat_rate > 0 || p.has_vat == 1) ? 1 : 0;
                html += `<li data-id="${p.id}" 
                           data-name="${p.name}" 
                           data-unit="${p.unit}" 
                           data-qty="${p.quantity}" 
                           data-price="${p.price}" 
                           data-limit="${p.min_quantity || 0}" 
                           data-vat="${vatStatus}">
                           ${p.name} (${p.quantity} ${p.unit})
                        </li>`;
            });
            html += '</ul>';
            suggestions.html(html).show();
        } else {
            suggestions.hide().empty();
        }
    });

    // სუგესციების დაკლიკება
    $(document).on('click', '#productSuggestions li', function(){
        const el = $(this);
        const product = products_js.find(p => p.id == el.data('id'));
        if (product) {
            showProductForm(product);
        }
        $('#productSuggestions').hide().empty();
    });

    // რედაქტირების ღილაკი - სწორი ვერსია
    $(document).on('click', '.editProduct', function(){
        console.log('რედაქტირების ღილაკზე დაჭერა');
        const tr = $(this).closest('tr');
        const id = tr.data('id');
        console.log('მოძებნილი ID:', id);
        console.log('ყველა პროდუქტი:', products_js);
        
        const product = products_js.find(p => p.id == id);
        console.log('ნაპოვნი პროდუქტი:', product);
        
        if (product) {
            showProductForm(product);
        } else {
            alert('პროდუქტი ვერ მოიძებნა!');
        }
    });

    // ახალი პროდუქტის შენახვა
    $('#saveNewProduct').on('click', function(){
        console.log('პროდუქტის შენახვა ღილაკზე დაჭერა');
        
        const productData = {
            id: selectedProduct || 0,
            name: $('#new_p_name').val().trim(),
            unit: $('#new_p_unit').val(),
            quantity: parseFloat($('#new_p_qty').val()) || 0,
            price: parseFloat($('#new_p_price').val()) || 0,
            min_limit: parseFloat($('#new_p_limit').val()) || 0,
            vat: $('#new_p_vat').is(':checked') ? 1 : 0
        };

        console.log('მონაცემები:', productData);

        if (!productData.name) {
            alert('გთხოვთ შეავსოთ პროდუქტის სახელი');
            return;
        }

        // დავამატოთ loading ინდიკატორი
        const saveBtn = $(this);
        const originalText = saveBtn.text();
        saveBtn.text('შენახვა...').prop('disabled', true);

        $.ajax({
            url: 'save_product.php',
            type: 'POST',
            data: productData,
            dataType: 'json',
            timeout: 10000,
            success: function(response) {
                console.log('პასუხი:', response);
                saveBtn.text(originalText).prop('disabled', false);
                
                if (response.success) {
                    alert(response.message);
                    // გადაამისამართებს იმავე გვერდზე მონაცემების განახლებისთვის
                    window.location.href = window.location.pathname + '?success=1';
                } else {
                    alert('შეცდომა: ' + response.message);
                }
            },
            error: function(xhr, status, error) {
                console.error('AJAX შეცდომა:', status, error);
                console.error('Response:', xhr.responseText);
                saveBtn.text(originalText).prop('disabled', false);
                alert('სერვერთან დაკავშირების შეცდომა: ' + error + '\nსტატუსი: ' + status);
            }
        });
    });

    // მიღების შენახვა
    $('#savePurchase').on('click', function(){
        const productId = $('#pur_product_id').val();
        const qty = parseFloat($('#pur_qty_pack').val()) || 0;
        const totalAmount = parseFloat($('#pur_total_amount').val()) || 0;
        const supplier = $('#pur_supplier').val().trim();
        const notes = $('#pur_notes').val().trim();
        const vat = $('#pur_vat').is(':checked') ? 1 : 0;

        // ვალიდაცია
        if (productId == 0) {
            alert('გთხოვთ აირჩიოთ პროდუქტი');
            return;
        }
        if (qty <= 0) {
            alert('გთხოვთ შეიყვანოთ დადებითი რაოდენობა');
            return;
        }
        if (totalAmount <= 0) {
            alert('გთხოვთ შეიყვანოთ დადებითი ფასი');
            return;
        }

        // AJAX მოთხოვნა
        $.ajax({
            url: 'save_purchase.php',
            type: 'POST',
            data: {
                product_id: productId,
                quantity: qty,
                total_amount: totalAmount,
                supplier: supplier,
                notes: notes,
                vat: vat
            },
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    alert(response.message);
                    location.reload();
                } else {
                    alert('შეცდომა: ' + response.message);
                }
            },
            error: function(xhr, status, error) {
                console.error('AJAX შეცდომა:', xhr.responseText);
                alert('სერვერთან დაკავშირების შეცდომა: ' + error);
            }
        });
    });

    // ჩამოწერის შენახვა
    $('#saveWaste').on('click', function(){
        const productId = $('#waste_product_id').val();
        const qty = parseFloat($('#waste_qty').val()) || 0;
        const reason = $('#waste_reason').val();
        const notes = $('#waste_notes').val().trim();
        const maxQty = parseFloat($('#max_waste_qty').text()) || 0;

        // ვალიდაცია
        if (productId == 0) {
            alert('გთხოვთ აირჩიოთ პროდუქტი');
            return;
        }
        if (qty <= 0) {
            alert('გთხოვთ შეიყვანოთ დადებითი რაოდენობა');
            return;
        }
        if (qty > maxQty) {
            alert('ჩამოსაწერი რაოდენობა აღემატება ნაშთს!');
            return;
        }

        // AJAX მოთხოვნა
        $.ajax({
            url: 'save_waste.php',
            type: 'POST',
            data: {
                product_id: productId,
                quantity: qty,
                reason: reason,
                notes: notes
            },
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    alert(response.message);
                    location.reload();
                } else {
                    alert('შეცდომა: ' + response.message);
                }
            },
            error: function(xhr, status, error) {
                console.error('AJAX შეცდომა:', xhr.responseText);
                alert('სერვერთან დაკავშირების შეცდომა: ' + error);
            }
        });
    });

    // პროდუქტის წაშლა
    $(document).on('click', '.deleteProduct', function(){
        const tr = $(this).closest('tr');
        const productId = tr.data('id');
        const productName = tr.data('name');

        if (!confirm('დარწმუნებული ხართ, რომ გსურთ პროდუქტის "' + productName + '" წაშლა?')) {
            return;
        }

        $.ajax({
            url: 'delete_product.php',
            type: 'POST',
            data: { id: productId },
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    alert(response.message);
                    location.reload();
                } else {
                    alert('შეცდომა: ' + response.message);
                }
            },
            error: function(xhr, status, error) {
                console.error('AJAX შეცდომა:', xhr.responseText);
                alert('სერვერთან დაკავშირების შეცდომა: ' + error);
            }
        });
    });

    // სუგესციების დამალვა ფოკუსის დაკარგვისას
    $(document).on('click', function(e) {
        if (!$(e.target).closest('#productSuggestions').length && 
            !$(e.target).is('#new_p_name')) {
            $('#productSuggestions').hide().empty();
        }
    });
    
    // თუ სესიიდან მოვიდა წარმატებული შეტყობინება
    if(window.location.search.includes('success=1')) {
        alert('პროდუქტი წარმატებით შეინახა!');
        // წავშალოთ პარამეტრი URL-დან
        window.history.replaceState({}, document.title, window.location.pathname);
    }
});
</script>
<?php include __DIR__ . '/../includes/footer.php'; ?>
</body>
</html>