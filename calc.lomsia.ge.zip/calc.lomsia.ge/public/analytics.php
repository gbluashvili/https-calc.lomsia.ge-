<?php
// analytics.php - ეს უნდა იყოს ძალიან პირველი ხაზი
// Output buffering ჩართვა სესიის პრობლემების თავიდან ასაცილებლად
ob_start();

// სესიის დაწყება
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../config/db.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);

// თარიღების დიაპაზონის განსაზღვრა
$date_from = $_GET['from'] ?? date('Y-m-d', strtotime('-7 days'));
$date_to   = $_GET['to'] ?? date('Y-m-d');

// 1. ფინანსური შეჯამება - გამოვიყენოთ სწორი ველები sales ცხრილიდან
$stats_query = $mysqli->prepare("
    SELECT 
        COALESCE(SUM(total_with_vat), 0) as revenue, -- მთლიანი შემოსავალი დღგ-ით
        COALESCE(SUM(cost_with_vat), 0) as cost_with_vat, -- თვითღირებულება დღგ-ით
        COALESCE(SUM(cost_excluding_vat), 0) as cost_excl_vat, -- თვითღირებულება დღგ-ს გარეშე
        COALESCE(SUM(profit), 0) as profit, -- მოგება
        COALESCE(SUM(total_price), 0) as total_price, -- alternative revenue field
        COUNT(*) as sale_count
    FROM sales
    WHERE DATE(sale_date) BETWEEN ? AND ?
");

$stats_query->bind_param("ss", $date_from, $date_to);
$stats_query->execute();
$stats = $stats_query->get_result()->fetch_assoc();

// სწორი ველების გამოყენება
$revenue = $stats['revenue'] ?? $stats['total_price'] ?? 0; // total_with_vat ან total_price
$cost_with_vat = $stats['cost_with_vat'] ?? 0;
$cost_excl_vat = $stats['cost_excl_vat'] ?? 0;
$profit = $stats['profit'] ?? 0;
$sale_count = $stats['sale_count'] ?? 0;

// თუ revenue ნულია, ვცადოთ სხვა ვარიანტი
if ($revenue == 0) {
    // net_amount + vat_amount = total_amount (დღგ-ით)
    $revenue_alt_query = $mysqli->prepare("
        SELECT COALESCE(SUM(net_amount + vat_amount), 0) as total_revenue
        FROM sales
        WHERE DATE(sale_date) BETWEEN ? AND ?
    ");
    $revenue_alt_query->bind_param("ss", $date_from, $date_to);
    $revenue_alt_query->execute();
    $revenue_alt = $revenue_alt_query->get_result()->fetch_assoc();
    $revenue = $revenue_alt['total_revenue'] ?? 0;
}

// თუ cost_with_vat ნულია, ვცადოთ total_amount ველი (როგორც ჩანს, მასში ინახება თვითღირებულება)
if ($cost_with_vat == 0) {
    $cost_alt_query = $mysqli->prepare("
        SELECT COALESCE(SUM(total_amount), 0) as total_cost
        FROM sales
        WHERE DATE(sale_date) BETWEEN ? AND ?
    ");
    $cost_alt_query->bind_param("ss", $date_from, $date_to);
    $cost_alt_query->execute();
    $cost_alt = $cost_alt_query->get_result()->fetch_assoc();
    $cost_with_vat = $cost_alt['total_cost'] ?? 0;
}

// თუ profit ნულია, გამოვთვალოთ ხელით
if ($profit == 0 && $revenue > 0) {
    $profit = $revenue - $cost_with_vat;
}

$margin_percent = $revenue > 0 ? round(($profit / $revenue) * 100, 2) : 0;

// 2. გაყიდვების დინამიკა (გრაფიკისთვის) - გამოვიყენოთ სწორი ველები
$sales_q = $mysqli->prepare("
    SELECT DATE(sale_date) as date, 
           COALESCE(SUM(total_with_vat), 0) as total_revenue,
           COALESCE(SUM(cost_with_vat), 0) as total_cost,
           COALESCE(SUM(total_amount), 0) as alt_cost,
           COALESCE(SUM(profit), 0) as profit,
           COUNT(*) as sale_count
    FROM sales
    WHERE DATE(sale_date) BETWEEN ? AND ?
    GROUP BY DATE(sale_date)
    ORDER BY date ASC
");
$sales_q->bind_param("ss", $date_from, $date_to);
$sales_q->execute();
$sales_data = $sales_q->get_result()->fetch_all(MYSQLI_ASSOC);

// 3. პოპულარული კერძები და მათი მომგებიანობა
$dishes_q = $mysqli->prepare("
    SELECT 
        COALESCE(d.name, s.dish_name) as dish_name,
        SUM(s.quantity) as qty,
        COALESCE(SUM(s.total_with_vat), SUM(s.total_price), SUM(s.net_amount + s.vat_amount), 0) as revenue,
        COALESCE(SUM(s.cost_with_vat), SUM(s.total_amount), 0) as cost,
        COALESCE(SUM(s.profit), 0) as profit,
        CASE 
            WHEN COALESCE(SUM(s.total_with_vat), SUM(s.total_price), SUM(s.net_amount + s.vat_amount), 0) > 0 
            THEN ROUND(
                (COALESCE(SUM(s.profit), 0) / 
                 COALESCE(SUM(s.total_with_vat), SUM(s.total_price), SUM(s.net_amount + s.vat_amount), 1)
                ) * 100, 2
            )
            ELSE 0 
        END as margin_percent
    FROM sales s
    LEFT JOIN dishes d ON s.dish_id = d.id
    WHERE DATE(s.sale_date) BETWEEN ? AND ?
    GROUP BY COALESCE(d.name, s.dish_name)
    ORDER BY revenue DESC 
    LIMIT 5
");
$dishes_q->bind_param("ss", $date_from, $date_to);
$dishes_q->execute();
$top_dishes = $dishes_q->get_result()->fetch_all(MYSQLI_ASSOC);

// 4. დანაკარგები - waste_history ცხრილიდან
$waste_exists = $mysqli->query("SHOW TABLES LIKE 'waste_history'")->num_rows > 0;
$waste_stats = ['total_loss' => 0, 'waste_count' => 0];
$waste_reasons = [];
$waste_details = [];

if ($waste_exists) {
    $waste_value_q = $mysqli->prepare("
        SELECT 
            COALESCE(SUM(total_loss), 0) as total_loss,
            COUNT(*) as waste_count
        FROM waste_history
        WHERE DATE(waste_date) BETWEEN ? AND ?
    ");
    $waste_value_q->bind_param("ss", $date_from, $date_to);
    $waste_value_q->execute();
    $waste_stats = $waste_value_q->get_result()->fetch_assoc();
    
    // დანაკარგების მიზეზები waste_history-დან
    $waste_q = $mysqli->prepare("
        SELECT reason, SUM(quantity) as qty 
        FROM waste_history 
        WHERE DATE(waste_date) BETWEEN ? AND ?
        GROUP BY reason
    ");
    $waste_q->bind_param("ss", $date_from, $date_to);
    $waste_q->execute();
    $waste_reasons = $waste_q->get_result()->fetch_all(MYSQLI_ASSOC);
    
    // დეტალური დანაკარგების ინფორმაცია
    $waste_details_q = $mysqli->prepare("
        SELECT 
            wh.id,
            wh.product_id,
            p.name as product_name,
            wh.quantity,
            NULL as unit_price, -- ამ ველის დამატება სტრუქტურისთვის
            wh.total_loss,
            wh.reason,
            DATE(wh.waste_date) as waste_date,
            wh.notes
        FROM waste_history wh
        LEFT JOIN products p ON wh.product_id = p.id
        WHERE DATE(wh.waste_date) BETWEEN ? AND ?
        ORDER BY wh.waste_date DESC
        LIMIT 10
    ");
    $waste_details_q->bind_param("ss", $date_from, $date_to);
    $waste_details_q->execute();
    $waste_details = $waste_details_q->get_result()->fetch_all(MYSQLI_ASSOC);
}

$page_title = "ბიზნეს ანალიტიკა";
include '../includes/header.php';
?>

<div class="filter-bar" style="margin-top: 20px;">
    <form method="GET" style="display: flex; align-items: center; gap: 15px; flex-wrap: wrap;">
        <div style="display: flex; align-items: center; gap: 5px;">
            <label style="font-weight: 600;">დან:</label>
            <input type="date" name="from" value="<?= $date_from ?>" style="padding: 8px; border: 2px solid #e0e0e0; border-radius: 8px;">
        </div>
        <div style="display: flex; align-items: center; gap: 5px;">
            <label style="font-weight: 600;">მდე:</label>
            <input type="date" name="to" value="<?= $date_to ?>" style="padding: 8px; border: 2px solid #e0e0e0; border-radius: 8px;">
        </div>
        <button type="submit" class="btn btn-green" style="padding: 8px 15px;">გაფილტვრა</button>
        <a href="analytics.php" class="btn btn-gray" style="padding: 8px 15px;">გასუფთავება</a>
    </form>
</div>

<div class="stat-cards" style="margin: 20px 0; display: grid; grid-template-columns: repeat(4, 1fr); gap: 15px;">
    <div class="stat-card" style="border-color: #007bff; background: linear-gradient(135deg, #f8f9fa, #e3f2fd);">
        <h4>შემოსავალი</h4>
        <div class="stat-value" style="color: #007bff; font-size: 1.8rem;"><?= number_format($revenue, 2) ?> ₾</div>
        <small>გაყიდვები: <?= $sale_count ?> ტრანზაქცია</small>
    </div>
    
    <div class="stat-card" style="border-color: #dc3545; background: linear-gradient(135deg, #f8f9fa, #ffebee);">
        <h4>დანახარჯები</h4>
        <div class="stat-value" style="color: #dc3545; font-size: 1.8rem;"><?= number_format($cost_with_vat, 2) ?> ₾</div>
        <small>დღგ-ს ჩათვლით</small>
    </div>
    
    <div class="stat-card" style="border-color: #28a745; background: linear-gradient(135deg, #f8f9fa, #e8f5e9);">
        <h4>წმინდა მოგება</h4>
        <div class="stat-value" style="color: #28a745; font-size: 1.8rem;"><?= number_format($profit, 2) ?> ₾</div>
        <small>მარჟა: <?= $margin_percent ?>%</small>
    </div>
    
    <div class="stat-card" style="border-color: #ffc107; background: linear-gradient(135deg, #f8f9fa, #fff8e1);">
        <h4>დანაკარგები</h4>
        <div class="stat-value" style="color: #ffc107; font-size: 1.8rem;"><?= number_format($waste_stats['total_loss'] ?? 0, 2) ?> ₾</div>
        <small><?= $waste_stats['waste_count'] ?? 0 ?> ჩანაწერი</small>
    </div>
</div>

<div class="grid" style="display: grid; grid-template-columns: 2fr 1fr; gap: 20px; margin-top: 30px;">
    <div class="card">
        <h3 style="margin-top: 0; padding-bottom: 15px; border-bottom: 2px solid #f0f0f0;">
            📈 გაყიდვების დინამიკა
        </h3>
        <div style="height: 300px;">
            <canvas id="salesChart"></canvas>
        </div>
    </div>
    
    <div style="display: flex; flex-direction: column; gap: 20px;">
        <div class="card">
            <h3 style="margin-top: 0; padding-bottom: 15px; border-bottom: 2px solid #f0f0f0;">
                🏆 ტოპ 5 გაყიდვადი კერძი
            </h3>
            <?php if (!empty($top_dishes)): ?>
            <div style="overflow-x: auto;">
                <table style="width: 100%; border-collapse: collapse;">
                    <thead>
                        <tr style="background-color: #f8f9fa;">
                            <th style="padding: 10px; text-align: left; border-bottom: 1px solid #dee2e6;">კერძი</th>
                            <th style="padding: 10px; text-align: center; border-bottom: 1px solid #dee2e6;">რაოდ.</th>
                            <th style="padding: 10px; text-align: right; border-bottom: 1px solid #dee2e6;">შემოსავალი</th>
                            <th style="padding: 10px; text-align: right; border-bottom: 1px solid #dee2e6;">მოგება</th>
                            <th style="padding: 10px; text-align: center; border-bottom: 1px solid #dee2e6;">მარჟა</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($top_dishes as $dish): ?>
                        <tr style="border-bottom: 1px solid #f0f0f0;">
                            <td style="padding: 10px;"><?= htmlspecialchars($dish['dish_name']) ?></td>
                            <td style="padding: 10px; text-align: center;"><?= $dish['qty'] ?></td>
                            <td style="padding: 10px; text-align: right; font-weight: 600;"><?= number_format($dish['revenue'], 2) ?> ₾</td>
                            <td style="padding: 10px; text-align: right; color: <?= $dish['profit'] >= 0 ? '#28a745' : '#dc3545' ?>;">
                                <?= number_format($dish['profit'], 2) ?> ₾
                            </td>
                            <td style="padding: 10px; text-align: center; color: <?= $dish['margin_percent'] >= 0 ? '#28a745' : '#dc3545' ?>;">
                                <?= $dish['margin_percent'] ?>%
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php else: ?>
            <div style="text-align: center; padding: 40px; color: #6c757d;">
                <p>გაყიდვები არ მოიძებნა არჩეულ პერიოდში</p>
            </div>
            <?php endif; ?>
        </div>
        
        <div class="card">
            <h3 style="margin-top: 0; padding-bottom: 15px; border-bottom: 2px solid #f0f0f0;">
                🗑️ დანაკარგების ანალიზი
            </h3>
            <?php if ($waste_exists && (!empty($waste_reasons) || !empty($waste_details))): ?>
            <div style="margin-bottom: 20px;">
                <h4 style="color: #6c757d; margin-bottom: 10px;">დანაკარგები მიზეზების მიხედვით</h4>
                <?php if (!empty($waste_reasons)): ?>
                <div style="height: 200px;">
                    <canvas id="wasteChart"></canvas>
                </div>
                <?php else: ?>
                <div style="text-align: center; padding: 20px; color: #6c757d;">
                    <p>დანაკარგების მიზეზები არ მოიძებნა</p>
                </div>
                <?php endif; ?>
            </div>
            
            <?php if (!empty($waste_details)): ?>
            <div style="overflow-x: auto;">
                <h4 style="color: #6c757d; margin-bottom: 10px;">დანაკარგებული პროდუქტები</h4>
                <table style="width: 100%; border-collapse: collapse;">
                    <thead>
                        <tr style="background-color: #f8f9fa;">
                            <th style="padding: 10px; text-align: left; border-bottom: 1px solid #dee2e6;">პროდუქტი</th>
                            <th style="padding: 10px; text-align: center; border-bottom: 1px solid #dee2e6;">რაოდენობა</th>
                            <th style="padding: 10px; text-align: center; border-bottom: 1px solid #dee2e6;">ერთეულის ფასი</th>
                            <th style="padding: 10px; text-align: right; border-bottom: 1px solid #dee2e6;">სულ ღირებულება</th>
                            <th style="padding: 10px; text-align: left; border-bottom: 1px solid #dee2e6;">მიზეზი</th>
                            <th style="padding: 10px; text-align: left; border-bottom: 1px solid #dee2e6;">თარიღი</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($waste_details as $waste_item): ?>
                        <tr style="border-bottom: 1px solid #f0f0f0;">
                            <td style="padding: 10px;">
                                <?= htmlspecialchars($waste_item['product_name'] ?? 'ID: ' . ($waste_item['product_id'] ?? '')) ?>
                                <?php if (!empty($waste_item['notes'])): ?>
                                <br><small style="color: #6c757d;"><?= htmlspecialchars($waste_item['notes']) ?></small>
                                <?php endif; ?>
                            </td>
                            <td style="padding: 10px; text-align: center;"><?= number_format($waste_item['quantity'], 3) ?></td>
                            <td style="padding: 10px; text-align: center;">
                                <?php 
                                // გამოვთვალოთ ერთეულის ფასი total_loss და quantity-დან
                                $unit_price = isset($waste_item['quantity']) && $waste_item['quantity'] > 0 ? 
                                    $waste_item['total_loss'] / $waste_item['quantity'] : 0;
                                echo number_format($unit_price, 2) . ' ₾';
                                ?>
                            </td>
                            <td style="padding: 10px; text-align: right; color: #dc3545; font-weight: 600;">
                                <?= number_format($waste_item['total_loss'], 2) ?> ₾
                            </td>
                            <td style="padding: 10px;">
                                <span style="display: inline-block; padding: 3px 8px; border-radius: 4px; 
                                      background-color: 
                                        <?= $waste_item['reason'] == 'დაზიანება' ? '#f8d7da' : 
                                           ($waste_item['reason'] == 'ვადაგასული' ? '#fff3cd' : 
                                           ($waste_item['reason'] == 'დაფუჭება' ? '#e2e3e5' : 
                                           ($waste_item['reason'] == 'სხვა' ? '#d1ecf1' : '#f8f9fa'))) ?>;">
                                    <?= htmlspecialchars($waste_item['reason'] ?? 'არ არის მითითებული') ?>
                                </span>
                            </td>
                            <td style="padding: 10px;"><?= $waste_item['waste_date'] ?? '' ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                    <tfoot>
                        <tr style="background-color: #f8f9fa; font-weight: 600;">
                            <td colspan="3" style="padding: 10px; text-align: right;">ჯამური დანაკარგი:</td>
                            <td style="padding: 10px; text-align: right; color: #dc3545;">
                                <?= number_format($waste_stats['total_loss'], 2) ?> ₾
                            </td>
                            <td colspan="2" style="padding: 10px; text-align: center;">
                                <?= $waste_stats['waste_count'] ?? 0 ?> ჩანაწერი
                            </td>
                        </tr>
                    </tfoot>
                </table>
            </div>
            
            <div style="margin-top: 20px; padding: 15px; background-color: #f8f9fa; border-radius: 8px;">
                <h4 style="color: #6c757d; margin-bottom: 10px;">დანაკარგების რეკომენდაციები</h4>
                <?php
                $waste_percentage = $revenue > 0 ? ($waste_stats['total_loss'] / $revenue) * 100 : 0;
                if ($waste_percentage > 5): ?>
                    <p style="color: #dc3545; margin: 0;">⚠️ <strong>მაღალი დანაკარგები!</strong> დანაკარგები შეადგენს <?= round($waste_percentage, 2) ?>% შემოსავლის. 
                    გადახედეთ შენახვის პირობებს და სტანდარტებს.</p>
                <?php elseif ($waste_percentage > 2): ?>
                    <p style="color: #ffc107; margin: 0;">⚠️ <strong>გასაუმჯობესებელია.</strong> დანაკარგები შეადგენს <?= round($waste_percentage, 2) ?>% შემოსავლის. 
                    მონიტორინგი საჭიროა.</p>
                <?php else: ?>
                    <p style="color: #28a745; margin: 0;">✅ <strong>კარგი კონტროლი.</strong> დანაკარგები შეადგენს მხოლოდ <?= round($waste_percentage, 2) ?>% შემოსავლის.</p>
                <?php endif; ?>
                
                <?php if (!empty($waste_reasons) && $waste_exists): ?>
                    <p style="margin: 10px 0 0 0; color: #6c757d;">
                        <strong>ყველაზე გავრცელებული მიზეზები:</strong> 
                        <?php 
                        $top_reasons = array_slice($waste_reasons, 0, 2);
                        $reason_text = [];
                        foreach ($top_reasons as $reason) {
                            $reason_text[] = htmlspecialchars($reason['reason']) . ' (' . number_format($reason['qty'], 3) . ' ერთეული)';
                        }
                        echo implode(', ', $reason_text);
                        ?>
                    </p>
                <?php endif; ?>
            </div>
            
            <?php else: ?>
            <div style="text-align: center; padding: 40px; color: #6c757d;">
                <div style="font-size: 48px; margin-bottom: 20px;">🗑️</div>
                <p style="font-size: 1.1rem; margin-bottom: 10px;">დანაკარგები არ მოიძებნა არჩეულ პერიოდში</p>
                <p style="color: #6c757d; font-size: 0.9rem;">არჩეულ დროის ინტერვალში დანაკარგების ჩანაწერები არ არსებობს</p>
            </div>
            <?php endif; ?>
            
            <?php else: ?>
            <div style="text-align: center; padding: 40px; color: #6c757d;">
                <div style="font-size: 48px; margin-bottom: 20px;">🗑️</div>
                <p style="font-size: 1.1rem; margin-bottom: 10px;">დანაკარგები არ მოიძებნა არჩეულ პერიოდში</p>
                <p style="color: #6c757d; font-size: 0.9rem;">ანალიზისთვის აუცილებელია დანაკარგების ჩანაწერები</p>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- დამატებითი ანალიტიკა -->
<div class="card" style="margin-top: 30px;">
    <h3 style="margin-top: 0; padding-bottom: 15px; border-bottom: 2px solid #f0f0f0;">
        📊 დეტალური ანალიტიკა
    </h3>
    
    <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; margin-top: 20px;">
        <div>
            <h4 style="color: #6c757d; margin-bottom: 10px;">საშუალო მაჩვენებლები</h4>
            <div style="background: #f8f9fa; padding: 15px; border-radius: 8px;">
                <?php
                $days_count = max(1, (strtotime($date_to) - strtotime($date_from)) / (60*60*24) + 1);
                $avg_revenue = $revenue / $days_count;
                $avg_profit = $profit / $days_count;
                $avg_daily_sales = $sale_count / $days_count;
                $avg_transaction_value = $sale_count > 0 ? $revenue / $sale_count : 0;
                ?>
                <div style="margin-bottom: 10px;">
                    <span style="color: #6c757d;">საშუალო დღიური შემოსავალი:</span><br>
                    <strong style="font-size: 1.2rem;"><?= number_format($avg_revenue, 2) ?> ₾</strong>
                </div>
                <div style="margin-bottom: 10px;">
                    <span style="color: #6c757d;">საშუალო დღიური მოგება:</span><br>
                    <strong style="font-size: 1.2rem; color: #28a745;"><?= number_format($avg_profit, 2) ?> ₾</strong>
                </div>
                <div style="margin-bottom: 10px;">
                    <span style="color: #6c757d;">საშუალო გაყიდვის ღირებულება:</span><br>
                    <strong style="font-size: 1.2rem;"><?= number_format($avg_transaction_value, 2) ?> ₾</strong>
                </div>
            </div>
        </div>
        
        <div>
            <h4 style="color: #6c757d; margin-bottom: 10px;">მომგებიანობის მაჩვენებლები</h4>
            <div style="background: #f8f9fa; padding: 15px; border-radius: 8px;">
                <div style="margin-bottom: 10px;">
                    <span style="color: #6c757d;">მთლიანი მარჟა:</span><br>
                    <strong style="font-size: 1.2rem; color: <?= $margin_percent >= 0 ? '#28a745' : '#dc3545' ?>;">
                        <?= $margin_percent ?>%
                    </strong>
                </div>
                <div style="margin-bottom: 10px;">
                    <span style="color: #6c757d;">დანახარჯების წილი:</span><br>
                    <strong style="font-size: 1.2rem;">
                        <?= $revenue > 0 ? number_format(($cost_with_vat / $revenue) * 100, 2) : 0 ?>%
                    </strong>
                </div>
                <div>
                    <span style="color: #6c757d;">მოგების მაჩვენებელი:</span><br>
                    <strong style="font-size: 1.2rem; color: <?= $profit >= 0 ? '#28a745' : '#dc3545' ?>;">
                        <?= number_format($profit, 2) ?> ₾
                    </strong>
                </div>
            </div>
        </div>
        
        <div>
            <h4 style="color: #6c757d; margin-bottom: 10px;">რეკომენდაციები</h4>
            <div style="background: #f8f9fa; padding: 15px; border-radius: 8px;">
                <?php if ($margin_percent > 30): ?>
                <p style="color: #28a745; margin: 0;">✅ შესანიშნავი მომგებიანობა! განაგრძეთ ამ კურსით.</p>
                <?php elseif ($margin_percent > 20): ?>
                <p style="color: #28a745; margin: 0;">✅ კარგი მომგებიანობა. ფოკუსი შეინარჩუნეთ ხარისხზე.</p>
                <?php elseif ($margin_percent > 15): ?>
                <p style="color: #ffc107; margin: 0;">⚠️ კარგი მომგებიანობა, განიხილეთ ფასების განახლება.</p>
                <?php elseif ($margin_percent > 5): ?>
                <p style="color: #ffc107; margin: 0;">⚠️ დაბალი მომგებიანობა. შეამცირეთ დანახარჯები.</p>
                <?php elseif ($margin_percent > 0): ?>
                <p style="color: #dc3545; margin: 0;">🔴 ძალიან დაბალი მომგებიანობა. გადახედეთ ბიზნეს მოდელს.</p>
                <?php else: ?>
                <p style="color: #dc3545; margin: 0;">❌ ზარალის ზონა. სასწრაფოდ გადახედეთ ბიზნეს მოდელს.</p>
                <?php endif; ?>
                
                <?php if ($waste_stats['total_loss'] > ($revenue * 0.05) && $revenue > 0): ?>
                <p style="color: #dc3545; margin: 10px 0 0 0;">⚠️ დანაკარგები მაღალია (<?= round(($waste_stats['total_loss'] / $revenue) * 100, 2) ?>%). შეამცირეთ ნარჩენები.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // გაყიდვების დინამიკის გრაფიკი
    const salesCtx = document.getElementById('salesChart')?.getContext('2d');
    if (salesCtx) {
        const salesData = <?= json_encode($sales_data) ?>;
        
        // შევქმნათ დღეების მასივი
        const dateLabels = [];
        const revenueData = [];
        const costDataArray = [];
        const profitDataArray = [];
        
        // დღეების მიხედვით მონაცემების დალაგება
        salesData.forEach(item => {
            dateLabels.push(item.date);
            revenueData.push(parseFloat(item.total_revenue) || 0);
            
            // სწორი ხარჯის ველის გამოყენება
            const cost = parseFloat(item.total_cost) || parseFloat(item.alt_cost) || 0;
            costDataArray.push(cost);
            
            profitDataArray.push(parseFloat(item.profit) || 0);
        });
        
        new Chart(salesCtx, {
            type: 'bar',
            data: {
                labels: dateLabels,
                datasets: [
                    {
                        label: 'შემოსავალი (₾)',
                        data: revenueData,
                        backgroundColor: 'rgba(0, 123, 255, 0.7)',
                        borderColor: '#007bff',
                        borderWidth: 1,
                        yAxisID: 'y'
                    },
                    {
                        label: 'დანახარჯები (₾)',
                        data: costDataArray,
                        backgroundColor: 'rgba(220, 53, 69, 0.7)',
                        borderColor: '#dc3545',
                        borderWidth: 1,
                        yAxisID: 'y'
                    },
                    {
                        label: 'მოგება (₾)',
                        data: profitDataArray,
                        type: 'line',
                        borderColor: '#28a745',
                        backgroundColor: 'rgba(40, 167, 69, 0.1)',
                        borderWidth: 3,
                        fill: true,
                        tension: 0.3,
                        yAxisID: 'y'
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                interaction: {
                    mode: 'index',
                    intersect: false,
                },
                plugins: {
                    legend: {
                        display: true,
                        position: 'top'
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return `${context.dataset.label}: ${context.raw.toFixed(2)} ₾`;
                            }
                        }
                    }
                },
                scales: {
                    y: {
                        type: 'linear',
                        display: true,
                        position: 'left',
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return value.toFixed(2) + ' ₾';
                            }
                        }
                    },
                    x: {
                        ticks: {
                            maxTicksLimit: 10
                        }
                    }
                }
            }
        });
    }
    
    // დანაკარგების გრაფიკი
    const wasteCtx = document.getElementById('wasteChart')?.getContext('2d');
    if (wasteCtx) {
        const wasteData = <?= json_encode($waste_reasons) ?>;
        
        if (wasteData.length > 0) {
            new Chart(wasteCtx, {
                type: 'pie',
                data: {
                    labels: wasteData.map(item => item.reason || 'არ არის მითითებული'),
                    datasets: [{
                        data: wasteData.map(item => parseFloat(item.qty) || 0),
                        backgroundColor: [
                            '#dc3545', // დაზიანება
                            '#ffc107', // ვადაგასული
                            '#17a2b8', // დანაკარგი
                            '#6f42c1', // სხვა
                            '#e83e8c', // დაფუჭება
                            '#28a745',  // წარმოების ნარჩენი
                            '#20c997', // შეცდომა
                            '#fd7e14'  // მიწოდების პრობლემა
                        ],
                        borderWidth: 2,
                        borderColor: '#fff'
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'bottom',
                            labels: {
                                boxWidth: 12,
                                padding: 15,
                                font: {
                                    size: 11
                                }
                            }
                        },
                        tooltip: {
                            callbacks: {
                                label: function(context) {
                                    return `${context.label}: ${context.raw} ერთეული`;
                                }
                            }
                        }
                    }
                }
            });
        }
    }
});
</script>

<style>
.stat-card {
    background: white;
    border: 2px solid;
    border-radius: 12px;
    padding: 20px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.05);
    transition: transform 0.2s, box-shadow 0.2s;
}
.stat-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 8px 20px rgba(0,0,0,0.1);
}
.stat-value {
    font-size: 1.6rem;
    font-weight: 700;
    margin: 10px 0 5px 0;
}
.card {
    background: white;
    border-radius: 12px;
    padding: 20px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.05);
}
.btn {
    padding: 8px 16px;
    border: none;
    border-radius: 6px;
    cursor: pointer;
    font-weight: 500;
    text-decoration: none;
    display: inline-block;
    text-align: center;
}
.btn-green {
    background: #10b981;
    color: white;
}
.btn-green:hover {
    background: #059669;
}
.btn-gray {
    background: #6b7280;
    color: white;
}
.btn-gray:hover {
    background: #4b5563;
}
</style>

<?php
include '../includes/footer.php';
// Output buffering დასრულება
ob_end_flush();
?>