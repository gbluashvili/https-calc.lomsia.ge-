<?php
// პირველ ხაზზე სესიის დაწყება
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../config/db.php';
require_once '../includes/functions.php';

// დროებითი: გამორთეთ CSRF შემოწმება GET მოთხოვნებისთვის
/*
if (isset($_GET['csrf_token'])) {
    if (!isset($_SESSION['csrf_token']) || $_GET['csrf_token'] !== $_SESSION['csrf_token']) {
        echo json_encode(['status' => 0, 'message' => 'Invalid CSRF token']);
        exit();
    }
}
*/

// ვალიდაცია
if (!isset($_GET['dish_id']) || !is_numeric($_GET['dish_id'])) {
    echo json_encode(['status' => 0, 'message' => 'Invalid dish ID']);
    exit();
}

$dish_id = intval($_GET['dish_id']);

try {
    $stmt = $mysqli->prepare("SELECT * FROM dishes WHERE id = ?");
    $stmt->bind_param("i", $dish_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $dish = $result->fetch_assoc();
        echo json_encode([
            'status' => 1, 
            'dish' => $dish,
            'debug' => [
                'id' => $dish['id'],
                'menu_id' => $dish['menu_id'],
                'name' => $dish['name']
            ]
        ]);
    } else {
        echo json_encode(['status' => 0, 'message' => 'Dish not found']);
    }
    
    $stmt->close();
    
} catch (Exception $e) {
    echo json_encode(['status' => 0, 'message' => 'Error: ' . $e->getMessage()]);
}
?>