<?php
require_once __DIR__ . '/../config/db.php';

header('Content-Type: application/json');

if (!$mysqli) {
    die(json_encode(['success' => false, 'message' => 'ბაზასთან დაკავშირება ვერ მოხერხდა']));
}

// მონაცემების მიღება
$id = isset($_POST['id']) ? intval($_POST['id']) : 0;
$name = trim($_POST['name'] ?? '');
$unit = $_POST['unit'] ?? 'კგ';
$quantity = floatval($_POST['quantity'] ?? 0);
$price = floatval($_POST['price'] ?? 0);
$min_limit = floatval($_POST['min_limit'] ?? 0);
$vat = isset($_POST['vat']) ? intval($_POST['vat']) : 0;

// დებაგისთვის
error_log("save_product.php - მიღებული მონაცემები: " . print_r($_POST, true));

if (empty($name)) {
    echo json_encode(['success' => false, 'message' => 'პროდუქტის სახელი ცარიელია']);
    exit;
}

try {
    // VAT სტატუსის დადგენა
    $vat_status = $vat ? 'დღგ-თი' : 'დღგ-ის გარეშე';
    $vat_rate = $vat ? 18 : 0;
    
    // შევამოწმოთ არსებობს თუ არა has_vat სვეტი
    $check_has_vat = $mysqli->query("SHOW COLUMNS FROM products LIKE 'has_vat'");
    $has_vat_column = $check_has_vat->num_rows > 0;

    if ($id > 0) {
        // რედაქტირება - შევამოწმოთ არსებობს თუ არა updated_at
        $check_updated_at = $mysqli->query("SHOW COLUMNS FROM products LIKE 'updated_at'");
        $has_updated_at = $check_updated_at->num_rows > 0;
        
        if ($has_vat_column && $has_updated_at) {
            $stmt = $mysqli->prepare("UPDATE products SET name=?, unit=?, quantity=?, price=?, min_quantity=?, vat_status=?, vat_rate=?, has_vat=?, updated_at=CURRENT_TIMESTAMP WHERE id=?");
            $stmt->bind_param("ssdddsdii", $name, $unit, $quantity, $price, $min_limit, $vat_status, $vat_rate, $vat, $id);
        } elseif ($has_vat_column) {
            $stmt = $mysqli->prepare("UPDATE products SET name=?, unit=?, quantity=?, price=?, min_quantity=?, vat_status=?, vat_rate=?, has_vat=? WHERE id=?");
            $stmt->bind_param("ssdddsdii", $name, $unit, $quantity, $price, $min_limit, $vat_status, $vat_rate, $vat, $id);
        } else {
            $stmt = $mysqli->prepare("UPDATE products SET name=?, unit=?, quantity=?, price=?, min_quantity=?, vat_status=?, vat_rate=? WHERE id=?");
            $stmt->bind_param("ssdddsdi", $name, $unit, $quantity, $price, $min_limit, $vat_status, $vat_rate, $id);
        }
        $action = "განახლება";
    } else {
        // ახალი პროდუქტი
        if ($has_vat_column) {
            $stmt = $mysqli->prepare("INSERT INTO products (name, unit, quantity, price, min_quantity, vat_status, vat_rate, has_vat) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("ssdddsdi", $name, $unit, $quantity, $price, $min_limit, $vat_status, $vat_rate, $vat);
        } else {
            $stmt = $mysqli->prepare("INSERT INTO products (name, unit, quantity, price, min_quantity, vat_status, vat_rate) VALUES (?, ?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("ssdddsd", $name, $unit, $quantity, $price, $min_limit, $vat_status, $vat_rate);
        }
        $action = "ჩასმა";
    }

    if ($stmt->execute()) {
        $response = ['success' => true, 'message' => 'პროდუქტი წარმატებით შეინახა'];
        error_log("პროდუქტი $action: $name");
    } else {
        $response = ['success' => false, 'message' => 'შეცდომა ბაზაში: ' . $stmt->error];
        error_log("შეცდომა: " . $stmt->error);
    }
    
    $stmt->close();
    echo json_encode($response);
    
} catch (Exception $e) {
    error_log("Exception: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'შეცდომა: ' . $e->getMessage()]);
}

$mysqli->close();
?>