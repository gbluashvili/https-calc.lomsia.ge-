<?php
// /home/mvpuufsr/calc/calc.lomsia.ge/public/access_denied.php
session_start();
?>
<!DOCTYPE html>
<html lang="ka">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>წვდომა შეზღუდულია</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f8f9fa; margin: 0; padding: 0; display: flex; justify-content: center; align-items: center; height: 100vh; }
        .container { text-align: center; background: white; padding: 40px; border-radius: 10px; box-shadow: 0 5px 15px rgba(0,0,0,0.1); }
        .error-icon { font-size: 80px; color: #e74c3c; margin-bottom: 20px; }
        h1 { color: #2c3e50; margin-bottom: 20px; }
        p { color: #7f8c8d; margin-bottom: 30px; }
        .btn { display: inline-block; padding: 10px 30px; background: #3498db; color: white; text-decoration: none; border-radius: 5px; font-weight: bold; }
        .btn:hover { background: #2980b9; }
        .user-info { background: #f8f9fa; padding: 10px; border-radius: 5px; margin-bottom: 20px; }
    </style>
</head>
<body>
    <div class="container">
        <div class="error-icon">🚫</div>
        <h1>წვდომა შეზღუდულია</h1>
        
        <div class="user-info">
            <p>მომხმარებელი: <strong><?php echo htmlspecialchars($_SESSION['username'] ?? 'უცნობი'); ?></strong></p>
            <p>როლი: <strong><?php echo htmlspecialchars($_SESSION['user_role'] ?? 'უცნობი'); ?></strong></p>
        </div>
        
        <p>სამწუხაროდ, თქვენ არ გაქვთ წვდომა ამ გვერდზე.</p>
        <p>გთხოვთ დაუკავშირდეთ ადმინისტრატორს თუ გჭირდებათ წვდომა.</p>
        <a href="index.php" class="btn">მთავარ გვერდზე დაბრუნება</a>
    </div>
</body>
</html>