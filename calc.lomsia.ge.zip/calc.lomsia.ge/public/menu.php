<?php
// ჩართეთ error reporting დეველოპმენტისთვის
error_reporting(E_ALL);
ini_set('display_errors', 1);

// პირველ ხაზზე სესიის დაწყება
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once dirname(__DIR__) . '/includes/auth_check.php';
require_once __DIR__ . '/../config/db.php';
require_once '../includes/functions.php';

// CSRF ტოკენის გენერაცია
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// უსაფრთხო JSON ენკოდინგის ფუნქცია
function safe_json_encode($data) {
    return json_encode($data, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP | JSON_UNESCAPED_UNICODE);
}

try {
    // კერძების მიღება prepared statement-ით
    $stmt = $mysqli->prepare("SELECT * FROM dishes ORDER BY name ASC");
    if (!$stmt) {
        throw new Exception("დაფიქსირდა SQL შეცდომა კერძების მიღებისას: " . $mysqli->error);
    }
    $stmt->execute();
    $dishes = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
    
    // პროდუქტების მიღება prepared statement-ით
    $stmt = $mysqli->prepare("SELECT * FROM products ORDER BY name ASC");
    if (!$stmt) {
        throw new Exception("დაფიქსირდა SQL შეცდომა პროდუქტების მიღებისას: " . $mysqli->error);
    }
    $stmt->execute();
    $products = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
    
    // შევამოწმოთ არის თუ არა sales ცხრილი განახლებული
    $table_check = $mysqli->query("SHOW COLUMNS FROM sales LIKE 'cost_with_vat'");
    $has_new_columns = $table_check->num_rows > 0;
    
    // ვამზადებთ დიაგნოსტიკურ ინფორმაციას
    $sales_columns = [];
    $columns_result = $mysqli->query("DESCRIBE sales");
    while ($row = $columns_result->fetch_assoc()) {
        $sales_columns[] = $row['Field'];
    }
    
} catch (Exception $e) {
    die("დაფიქსირდა შეცდომა: " . htmlspecialchars($e->getMessage()));
}
?>
<!DOCTYPE html>
<html lang="ka">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>მენიუს მართვა</title>
    <?php include '../includes/header.php'; ?>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css">
    <script type="text/javascript" src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <link rel="stylesheet" type="text/css" href="../css/style_menu.css?v=<?= filemtime('../css/style_menu.css') ?>">
</head>
<body>

<!-- სისტემის ინფორმაცია -->
<div class="system-info">
    სისტემის სტატუსი: 
    <span class="status">
        <?= $has_new_columns ? '✅ განახლებულია (ხელმისაწვდომია დეტალური ანალიზი)' : '⚠️ საჭიროა ბაზის განახლება' ?>
    </span>
    <?php if (!$has_new_columns): ?>
    <div style="margin-top: 5px;">
        საჭიროა გაუშვათ SQL ბრძანებები sales ცხრილის გასაფართოებლად დეტალური ინფორმაციის შესანახად.
    </div>
    <?php endif; ?>
</div>

<div class="action-buttons">
    <button class="btn btn-purple" onclick="showDishForm()">+ ახალი კერძი</button>
    <a href="index.php" class="btn btn-gray">← უკან</a>
</div>

<!-- კერძის დამატების/რედაქტირების ფორმა -->
<div id="dishFormDiv" class="form-container" style="display: none; border-top: 5px solid #6f42c1;">
    <h3>🍳 კერძის მართვა</h3>
    <div class="form-body">
        <div class="pur-grid">
            <div class="form-group">
                <label>Menu ID:</label>
                <input type="number" id="new_menu_id" min="1" step="1" required>
                <small class="form-hint">თქვენი სისტემისთვის უნიკალური ID (მაგ: 1001, 2005)</small>
            </div>
            <div class="form-group">
                <label>კერძის დასახელება:</label>
                <input type="text" id="new_d_name" required>
            </div>
            <div class="form-group">
                <label>გასაყიდი ფასი (₾):</label>
                <input type="number" id="new_d_price" step="0.01" min="0.01" required>
                <small class="form-hint">მინიმუმ 0.01, მაგალითად: 16.00 ან 9.50</small>
            </div>
        </div>
        <div class="form-group full-width">
            <label>
                <input type="checkbox" id="new_d_active" checked>
                აქტიური კერძი
            </label>
            <label style="margin-left: 20px;">
                <input type="checkbox" id="new_d_enable_vat" checked>
                დღგ-ს გაანგარიშება
            </label>
        </div>
        <div class="form-buttons">
            <button class="btn btn-blue" id="saveNewDish">✅ ახალი კერძის დამატება</button>
            <button class="btn btn-gray" type="button" onclick="cancelDishForm()">✖️ გაუქმება</button>
        </div>
    </div>
</div>

<!-- გაყიდვის მოდალური ფანჯარა -->
<div id="saleModal" class="sale-modal">
    <div class="sale-modal-content">
        <div class="modal-header">
            <h3 class="modal-title">🍳 კერძის გაყიდვა</h3>
            <button class="close-modal" onclick="closeSaleModal()">&times;</button>
        </div>
        
        <div id="saleModalBody">
            <!-- მონაცემები აქ ჩაიტვირთება JavaScript-ით -->
        </div>
    </div>
</div>

<div class="table-container">
    <h2>🍳 მენიუში არსებული კერძები</h2>
    <table id="dishTable" class="display compact">
        <thead>
            <tr>
                <th>ID</th>
                <th>Menu ID</th>
                <th>კერძი</th>
                <th>ფასი</th>
                <th>მოქმედება</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach($dishes as $d): ?>
            <tr data-id="<?= htmlspecialchars($d['id'], ENT_QUOTES, 'UTF-8') ?>">
                <td><?= htmlspecialchars($d['id'], ENT_QUOTES, 'UTF-8') ?></td>
                <td><?= htmlspecialchars($d['menu_id'] ?? 'N/A', ENT_QUOTES, 'UTF-8') ?></td>
                <td class="cell-dname"><?= htmlspecialchars($d['name'], ENT_QUOTES, 'UTF-8') ?></td>
                <td class="cell-dprice"><?= number_format($d['sale_price'], 2) ?> ₾</td>
                <td>
                    <button class="btn btn-orange btn-sell-dish" 
                            data-id="<?= htmlspecialchars($d['id'], ENT_QUOTES, 'UTF-8') ?>" 
                            data-name="<?= htmlspecialchars($d['name'], ENT_QUOTES, 'UTF-8') ?>" 
                            data-price="<?= htmlspecialchars($d['sale_price'], ENT_QUOTES, 'UTF-8') ?>">
                        🛒 გაყიდვა
                    </button>
                    <button class="btn btn-purple editRecipe" data-id="<?= $d['id'] ?>">✏️ რეცეპტის რედაქ</button>
    <button class="btn btn-info viewRecipe" data-id="<?= $d['id'] ?>">📊 რეცეპტის ნახვა</button>
                    <button class="btn btn-cyan editDish">რედაქტირება</button>
                    <button class="btn btn-red deleteDish">წაშლა</button>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<script>
// უსაფრთხო ინიციალიზაცია
const products_js = <?= safe_json_encode($products) ?>;
const dishes_js = <?= safe_json_encode($dishes) ?>;
const has_new_columns = <?= $has_new_columns ? 'true' : 'false' ?>;
const sales_columns = <?= safe_json_encode($sales_columns) ?>;
const csrf_token = "<?= htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8') ?>";

// დეფოლტ ობიექტები null რეფერენსების თავიდან ასაცილებლად
let currentSaleDishId = null;
let currentSaleQuantity = 1;
let currentSalePrice = 0;
let dishIngredients = {};
let calculatedCostDetails = null;

// დოკუმენტის მზაობა
$(document).ready(function() {
    // DataTable ინიციალიზაცია
    $('#dishTable').DataTable({
        language: {
            url: '//cdn.datatables.net/plug-ins/1.11.5/i18n/ka.json'
        },
        pageLength: 25,
        responsive: true,
        order: [[0, 'asc']]
    });
    
    console.log('System Status:', {
        hasNewColumns: has_new_columns,
        salesColumns: sales_columns,
        dishesCount: dishes_js.length,
        productsCount: products_js.length
    });
});

// ========== კერძის მართვის ფუნქციონალი ==========

// ახალი კერძის დამატების ფორმის ჩვენება
function showDishForm() { 
    // ავტომატური Menu ID-ს გენერაცია რეკომენდაციისთვის
    const menuIds = dishes_js.map(d => parseInt(d.menu_id) || 0).filter(id => id > 0);
    const maxMenuId = menuIds.length > 0 ? Math.max(...menuIds) : 1000;
    const suggestedMenuId = maxMenuId + 1;
    
    // ფორმის გასუფთავება
    $('#new_menu_id').val(suggestedMenuId);
    $('#new_d_name').val('');
    $('#new_d_price').val('');
    $('#new_d_active').prop('checked', true);
    $('#new_d_enable_vat').prop('checked', true);
    
    // ღილაკის ატრიბუტების გასუფთავება
    $('#saveNewDish')
        .removeAttr('data-edit-id')
        .removeAttr('data-original-menu-id')
        .removeAttr('data-dish-id')
        .text('✅ ახალი კერძის დამატება');
    
    // ფორმის ჩვენება
    $('#dishFormDiv').slideDown();
}

// კერძის რედაქტირება
$(document).on('click', '.editDish', function() {
    const row = $(this).closest('tr');
    const dishId = row.data('id'); // ეს არის dishes ცხრილის id (AUTO_INCREMENT)
    
    console.log('Editing dish ID:', dishId);
    console.log('Row data:', row.data());
    
    // ფორმის გასუფთავება
    $('#new_menu_id').val('');
    $('#new_d_name').val('');
    $('#new_d_price').val('');
    $('#new_d_active').prop('checked', true);
    $('#new_d_enable_vat').prop('checked', true);
    
    // ღილაკის ტექსტის განახლება
    $('#saveNewDish')
        .attr('data-edit-id', dishId)
        .attr('data-dish-id', dishId) // ძალიან მნიშვნელოვანი: dish_id-ს დაყენება
        .text('💾 კერძის განახლება');
    
    // ფორმის ჩვენება
    $('#dishFormDiv').slideDown();
    
    // AJAX მოთხოვნა დეტალების მისაღებად
    $.ajax({
        url: 'ajax_get_dish_details.php',
        type: 'GET',
        data: { 
            dish_id: dishId
        },
        dataType: 'json',
        success: function(response) {
            console.log('AJAX response:', response);
            if (response.status === 1) {
                const dish = response.dish || {};
                
                // დებაგინგი
                console.log('Dish data from server:', {
                    id: dish.id,
                    menu_id: dish.menu_id,
                    name: dish.name,
                    sale_price: dish.sale_price
                });
                
                // ველების შევსება
                // გამოიყენეთ menu_id თუ არსებობს, თუ არა - id
                const displayMenuId = dish.menu_id || dish.id;
                $('#new_menu_id').val(displayMenuId);
                $('#new_d_name').val(dish.name || '');
                
                // შენახვა original menu_id-ს (menu_id ბაზიდან)
                $('#saveNewDish')
                    .attr('data-original-menu-id', dish.menu_id || dish.id);
                
                console.log('Setting attributes:', {
                    editId: dishId,
                    dishId: dishId,
                    originalMenuId: dish.menu_id || dish.id
                });
                
                // ფასის ვალიდაცია
                const price = parseFloat(dish.sale_price);
                if (!isNaN(price) && price > 0) {
                    $('#new_d_price').val(price.toFixed(2));
                } else {
                    $('#new_d_price').val('');
                }
                
                // დამატებითი პარამეტრები
                $('#new_d_active').prop('checked', dish.active == 1);
                $('#new_d_enable_vat').prop('checked', dish.enable_vat == 1);
                    
            } else {
                console.error('Could not get dish details:', response.message);
                alert('შეცდომა კერძის მონაცემების მიღებისას: ' + response.message);
                $('#dishFormDiv').slideUp();
            }
        },
        error: function(xhr, status, error) {
            console.error('AJAX Error:', error);
            
            // Fallback: მონაცემების ამოღება ცხრილიდან
            try {
                const dishName = row.find('.cell-dname').text().trim();
                const dishPriceText = row.find('.cell-dprice').text().trim();
                const dishPrice = parseFloat(dishPriceText.replace('₾', '').trim());
                
                // ცხრილიდან Menu ID-ის ამოღება
                const menuIdFromTable = row.find('td').eq(1).text().trim();
                const menuId = menuIdFromTable !== 'N/A' && menuIdFromTable !== '' ? menuIdFromTable : dishId;
                
                $('#new_menu_id').val(menuId);
                $('#new_d_name').val(dishName);
                
                if (!isNaN(dishPrice) && dishPrice > 0) {
                    $('#new_d_price').val(dishPrice.toFixed(2));
                } else {
                    $('#new_d_price').val('');
                }
                
                // შენახვა original menu_id-ს
                $('#saveNewDish')
                    .attr('data-original-menu-id', menuId);
                
                alert('ყურადღება: მხოლოდ ძირითადი მონაცემები ჩაიტვირთა. გთხოვთ დაამატოთ დამატებითი პარამეტრები ხელით.');
                
            } catch (fallbackError) {
                console.error('Fallback also failed:', fallbackError);
                alert('სერვერული შეცდომა. გთხოვთ სცადოთ მოგვიანებით.');
                $('#dishFormDiv').slideUp();
            }
        }
    });
});

// კერძის შენახვა (ახალი ან რედაქტირება)
$(document).on('click', '#saveNewDish', function() {
    const isEditMode = $(this).attr('data-edit-id');
    const originalMenuId = $(this).attr('data-original-menu-id') || null;
    const dishId = $(this).attr('data-dish-id') || null; // ეს არის dishes ცხრილის id
    
    console.log('Edit mode data:', {
        isEditMode: isEditMode,
        originalMenuId: originalMenuId,
        dishId: dishId,
        hasDishIdAttr: $(this).attr('data-dish-id') !== undefined
    });
    
    // მონაცემების აღება
    const menuIdInput = $('#new_menu_id').val();
    const nameInput = $('#new_d_name').val();
    const priceInput = $('#new_d_price').val();
    
    // ვალიდაცია
    const errors = [];
    
    // Menu ID ვალიდაცია
    const menuId = parseInt(menuIdInput);
    if (isNaN(menuId) || menuId <= 0) {
        errors.push('Menu ID უნდა იყოს დადებითი მთელი რიცხვი');
    }
    
    // სახელის ვალიდაცია
    if (!nameInput || nameInput.trim() === '') {
        errors.push('კერძის სახელი არ არის მითითებული');
    }
    
    // ფასის ვალიდაცია
    if (!priceInput || priceInput.trim() === '') {
        errors.push('გასაყიდი ფასი არ არის მითითებული');
    } else {
        const salePrice = parseFloat(priceInput.replace(',', '.'));
        if (isNaN(salePrice) || salePrice < 0.01) {
            errors.push('გასაყიდი ფასი არასწორია. უნდა იყოს მინიმუმ 0.01 ₾');
        }
    }
    
    if (errors.length > 0) {
        alert('შეცდომები:\n\n' + errors.join('\n'));
        return;
    }
    
    // მონაცემების მომზადება
    const salePrice = parseFloat(priceInput.replace(',', '.'));
    const dishData = {
        menu_id: menuId,
        name: nameInput.trim(),
        sale_price: salePrice.toFixed(2),
        active: $('#new_d_active').is(':checked') ? 1 : 0,
        enable_vat: $('#new_d_enable_vat').is(':checked') ? 1 : 0,
        csrf_token: csrf_token
    };
    
    // თუ რედაქტირების რეჟიმია
    if (isEditMode) {
        dishData.edit_mode = 1;
        dishData.original_id = parseInt(originalMenuId) || menuId;
        
        // ძალიან მნიშვნელოვანი: dish_id-ს დამატება
        if (dishId) {
            dishData.dish_id = parseInt(dishId);
        } else {
            // თუ dishId არ არის, შევეცადოთ მისი მიღება სხვა გზით
            console.error('Dish ID is missing!');
            alert('შეცდომა: კერძის ID არ მოიძებნა. გთხოვთ, განაახლოთ გვერდი და სცადოთ ხელახლა.');
            return;
        }
        
        console.log('Sending dish_id to server:', dishData.dish_id);
        
        // Menu ID-ს შეცვლის შემთხვევაში გაფრთხილება
        if (menuId != originalMenuId) {
            if (!confirm(`გსურთ Menu ID-ს შეცვლა ${originalMenuId}-დან ${menuId}-ზე?`)) {
                $('#new_menu_id').val(originalMenuId);
                return;
            }
        }
    }
    
    // ახალი დამატების შემთხვევაში Menu ID-ს შემოწმება
    if (!isEditMode) {
        const existingDish = dishes_js.find(d => parseInt(d.menu_id) == menuId);
        if (existingDish) {
            if (!confirm(`Menu ID ${menuId} უკვე გამოყენებულია კერძისთვის: "${existingDish.name}".\nგსურთ მაინც განაგრძოთ?`)) {
                return;
            }
        }
    }
    
    console.log('Sending AJAX request with data:', dishData);
    
    // AJAX მოთხოვნა
    $.ajax({
        url: 'ajax_save_dish.php',
        type: 'POST',
        data: dishData,
        dataType: 'json',
        success: function(response) {
            console.log('Server response:', response);
            if (response.status === 1) {
                alert(isEditMode ? '✅ კერძი წარმატებით განახლდა!' : '✅ კერძი წარმატებით დაემატა!');
                $('#dishFormDiv').slideUp();
                location.reload();
            } else {
                alert('❌ შეცდომა: ' + (response.message || 'ოპერაცია ვერ მოხერხდა'));
            }
        },
        error: function(xhr, status, error) {
            console.error('AJAX error:', error, xhr.responseText);
            alert('❌ სერვერული შეცდომა: ' + error);
        }
    });
});

// კერძის წაშლა
$(document).on('click', '.deleteDish', function() {
    const row = $(this).closest('tr');
    const dishId = row.data('id');
    const dishName = row.find('.cell-dname').text().trim();
    
    if (confirm(`დარწმუნებული ხართ, რომ გსურთ კერძის წაშლა: "${dishName}"?\n\nყურადღება: ამის შედეგად წაიშლება ასევე კერძის ყველა ინგრედიენტი!`)) {
        const deleteData = { 
            dish_id: dishId,
            csrf_token: csrf_token
        };
        
        $.ajax({
            url: 'ajax_delete_dish.php',
            type: 'POST',
            data: deleteData,
            dataType: 'json',
            success: function(response) {
                if (response.status === 1) {
                    alert('✅ კერძი წარმატებით წაიშალა!');
                    location.reload();
                } else {
                    alert('❌ შეცდომა: ' + (response.message || 'კერძის წაშლა ვერ მოხერხდა'));
                }
            },
            error: function(xhr, status, error) {
                console.error('AJAX error:', error);
                alert('❌ სერვერული შეცდომა: ' + error);
            }
        });
    }
});

// ფორმის გაუქმება
function cancelDishForm() {
    if (confirm('დარწმუნებული ხართ, რომ გსურთ ფორმის გაუქმება? ყველა ჩასმული მონაცემი დაიკარგება.')) {
        $('#dishFormDiv').slideUp();
    }
}

// ========== გაყიდვის ფუნქციონალი ==========

// გაყიდვის მოდალური ფანჯრის გახსნა
$(document).on('click', '.btn-sell-dish', function() {
    const dishId = $(this).data('id');
    const dishName = $(this).data('name');
    const dishPrice = $(this).data('price');
    
    currentSaleDishId = dishId;
    currentSalePrice = parseFloat(dishPrice);
    currentSaleQuantity = 1;
    calculatedCostDetails = null;
    
    // ესკეიპინგი HTML-ისთვის
    const escapedDishName = $('<div>').text(dishName).html();
    
    // მოდალური ფანჯრის შევსება
    $('#saleModalBody').html(`
        <div class="sale-form-group">
            <label>კერძი:</label>
            <input type="text" value="${escapedDishName}" disabled style="background: #f8f9fa;">
        </div>
        
        <div class="sale-form-group">
            <label>რაოდენობა:</label>
            <div class="quantity-controls">
                <button type="button" class="quantity-btn" onclick="changeSaleQuantity(-1)">-</button>
                <input type="number" id="saleQuantity" class="quantity-input" value="1" min="1" step="1" onchange="updateSaleQuantity(this.value)">
                <button type="button" class="quantity-btn" onclick="changeSaleQuantity(1)">+</button>
            </div>
        </div>
        
        <div class="sale-info-grid">
            <div class="info-item">
                <div class="info-label">ერთეულის ფასი</div>
                <div class="info-value">${currentSalePrice.toFixed(2)} ₾</div>
            </div>
            <div class="info-item">
                <div class="info-label">ჯამური ფასი</div>
                <div class="info-value" id="totalSalePrice">${currentSalePrice.toFixed(2)} ₾</div>
            </div>
            <div class="info-item">
                <div class="info-label">დღგ (18%)</div>
                <div class="info-value" id="vatAmount">${(currentSalePrice * 0.18).toFixed(2)} ₾</div>
            </div>
            <div class="info-item">
                <div class="info-label">ფასი დღგ-ს გარეშე</div>
                <div class="info-value" id="priceWithoutVat">${(currentSalePrice / 1.18).toFixed(2)} ₾</div>
            </div>
        </div>
        
        <div id="costDetailsSection" style="display: none;">
            <h4 style="margin-top: 0; color: #555; border-bottom: 1px solid #eee; padding-bottom: 8px;">💰 ღირებულების ანალიზი</h4>
            <div class="sale-details-grid" id="costDetailsGrid">
                <!-- ღირებულების დეტალები აქ გამოჩნდება -->
            </div>
        </div>
        
        <div id="stockCheckResult" class="stock-check-list" style="display: none;">
            <!-- სტოკის შემოწმების შედეგი აქ გამოჩნდება -->
        </div>
        
        <div class="insufficient-stock" id="insufficientStockWarning" style="display: none;">
            ⚠️ საკმარისი მარაგი არ არის ზოგიერთი ინგრედიენტისთვის!
        </div>
        
        <div class="modal-actions">
            <button type="button" class="btn btn-gray" onclick="closeSaleModal()">გაუქმება</button>
            <button type="button" class="btn btn-orange" id="confirmSaleBtn" onclick="confirmSale()" disabled>
                ✅ გაყიდვის დადასტურება
            </button>
        </div>
        
        <div id="saleLoading" style="text-align: center; padding: 20px; display: none;">
            <div style="color: #666; margin-bottom: 10px;" id="loadingMessage">მარაგის შემოწმება...</div>
            <div style="width: 100%; height: 4px; background: #e9ecef; border-radius: 2px; overflow: hidden;">
                <div id="progressBar" style="height: 100%; background: #007bff; width: 0%; transition: width 0.3s;"></div>
            </div>
        </div>
    `);
    
    // მოდალური ფანჯრის გამოჩენა
    $('#saleModal').fadeIn();
    
    // მარაგის შემოწმება
    checkStockAndCalculateCost(dishId, 1);
});

// გაყიდვის რაოდენობის შეცვლა
function changeSaleQuantity(change) {
    let newQuantity = currentSaleQuantity + change;
    if (newQuantity < 1) newQuantity = 1;
    
    currentSaleQuantity = newQuantity;
    $('#saleQuantity').val(newQuantity);
    updateSaleInfo();
    checkStockAndCalculateCost(currentSaleDishId, newQuantity);
}

// რაოდენობის განახლება ინფუთიდან
function updateSaleQuantity(value) {
    const quantity = parseInt(value) || 1;
    if (quantity < 1) return;
    
    currentSaleQuantity = quantity;
    updateSaleInfo();
    checkStockAndCalculateCost(currentSaleDishId, quantity);
}

// გაყიდვის ინფორმაციის განახლება
function updateSaleInfo() {
    const totalPrice = currentSalePrice * currentSaleQuantity;
    const vat = totalPrice * 0.18;
    const priceWithoutVat = totalPrice / 1.18;
    
    $('#totalSalePrice').text(totalPrice.toFixed(2) + ' ₾');
    $('#vatAmount').text(vat.toFixed(2) + ' ₾');
    $('#priceWithoutVat').text(priceWithoutVat.toFixed(2) + ' ₾');
    
    if (calculatedCostDetails) {
        updateCostDetailsDisplay();
    }
}

// მარაგის შემოწმება და ღირებულების გამოთვლა
function checkStockAndCalculateCost(dishId, quantity) {
    $('#saleLoading').show();
    $('#loadingMessage').text('მარაგის შემოწმება და ღირებულების გაანგარიშება...');
    $('#progressBar').css('width', '30%');
    
    const requestData = {
        dish_id: dishId,
        quantity: quantity,
        unit_price: currentSalePrice,
        csrf_token: csrf_token
    };
    
    $.ajax({
        url: 'ajax_check_and_calculate.php',
        type: 'POST',
        data: requestData,
        dataType: 'json',
        success: function(response) {
            console.log('AJAX response:', response);
            $('#progressBar').css('width', '100%');
            
            setTimeout(function() {
                $('#saleLoading').hide();
                $('#progressBar').css('width', '0%');
                
                if (response.status === 1 || response.status === 2) {
                    if (!response.ingredients || !Array.isArray(response.ingredients)) {
                        console.error('Invalid ingredients data:', response.ingredients);
                        $('#stockCheckResult').html(
                            `<div style="color: #dc3545; text-align: center; padding: 20px;">
                                <div>❌ შეცდომა მონაცემებში</div>
                                <div style="font-size: 12px;">ინგრედიენტების მონაცემები არ არის ხელმისაწვდომი</div>
                            </div>`
                        ).show();
                        return;
                    }
                    
                    displayStockCheckResult(response.ingredients);
                    dishIngredients[dishId] = response.ingredients;
                    
                    if (response.cost_details) {
                        calculatedCostDetails = response.cost_details;
                        updateCostDetailsDisplay();
                    }
                    
                    const hasInsufficient = response.ingredients.some(ing => {
                        return ing && typeof ing.has_enough !== 'undefined' && !ing.has_enough;
                    });
                    
                    $('#insufficientStockWarning').toggle(hasInsufficient);
                    $('#confirmSaleBtn').prop('disabled', hasInsufficient);
                    
                    if (response.status === 2 && response.message) {
                        $('#insufficientStockWarning').html(
                            `⚠️ ${response.message}<br>` +
                            (response.low_stock_products ? 
                             response.low_stock_products.map(p => 
                                 `- ${p.product_name}: საჭიროა ${p.required} ${p.unit}, არის ${p.available} ${p.unit}`
                             ).join('<br>') : '')
                        ).show();
                    }
                    
                } else {
                    let errorMsg = response.message || 'გაურკვეველი შეცდომა';
                    
                    $('#stockCheckResult').html(
                        `<div style="color: #dc3545; text-align: center; padding: 20px;">
                            <div>❌ შეცდომა</div>
                            <div style="font-size: 12px;">${errorMsg}</div>
                        </div>`
                    ).show();
                    $('#confirmSaleBtn').prop('disabled', true);
                }
            }, 300);
        },
        error: function(xhr, status, error) {
            $('#saleLoading').hide();
            console.error('AJAX Error:', status, error, xhr.responseText);
            
            $('#stockCheckResult').html(
                `<div style="color: #dc3545; text-align: center; padding: 20px;">
                    <div>❌ სერვერული შეცდომა</div>
                    <div style="font-size: 12px;">${error}</div>
                </div>`
            ).show();
            $('#confirmSaleBtn').prop('disabled', true);
        }
    });
}

// მარაგის შემოწმების შედეგის ჩვენება
function displayStockCheckResult(ingredients) {
    let html = '<h4 style="margin-top: 0; color: #555;">მარაგის შემოწმება:</h4>';
    
    ingredients.forEach(ingredient => {
        const required = parseFloat(ingredient.required) || 0;
        const available = parseFloat(ingredient.available) || 0;
        const available_percentage = required > 0 ? (available / required) * 100 : 0;
        
        let statusClass, statusText;
        
        if (available >= required) {
            statusClass = 'stock-ok';
            statusText = '✅ საკმარისია';
        } else if (available >= required * 0.5) {
            statusClass = 'stock-low';
            statusText = '⚠️ დაბალია';
        } else {
            statusClass = 'stock-critical';
            statusText = '❌ არ არის საკმარისი';
        }
        
        // ესკეიპინგი
        const productName = ingredient.product_name ? $('<div>').text(ingredient.product_name).html() : 'უსახელო პროდუქტი';
        const unit = ingredient.unit ? $('<div>').text(ingredient.unit).html() : '';
        
        html += `
            <div class="stock-item">
                <div class="stock-item-name">${productName}</div>
                <div class="stock-item-status ${statusClass}">
                    საჭიროა: ${required.toFixed(3)} ${unit}<br>
                    არსებული: ${available.toFixed(3)} ${unit}<br>
                    (${available_percentage.toFixed(1)}%) - ${statusText}
                </div>
            </div>
        `;
    });
    
    $('#stockCheckResult').html(html).show();
}

// ღირებულების დეტალების განახლება
function updateCostDetailsDisplay() {
    if (!calculatedCostDetails) return;
    
    const cost_with_vat = parseFloat(calculatedCostDetails.cost_with_vat) || 0;
    const cost_excluding_vat = parseFloat(calculatedCostDetails.cost_excluding_vat) || 0;
    const total_revenue = parseFloat(calculatedCostDetails.total_revenue) || (currentSalePrice * currentSaleQuantity);
    const net_amount = parseFloat(calculatedCostDetails.net_amount) || (total_revenue / 1.18);
    const vat_amount = parseFloat(calculatedCostDetails.vat_amount) || (total_revenue * 0.18);
    const profit = parseFloat(calculatedCostDetails.profit) || (net_amount - cost_excluding_vat);
    const margin_percent = parseFloat(calculatedCostDetails.margin_percent) || 
        (cost_excluding_vat > 0 ? (profit / cost_excluding_vat) * 100 : 0);
    
    const unit_cost_with_vat = currentSaleQuantity > 0 ? cost_with_vat / currentSaleQuantity : 0;
    const unit_cost_excluding_vat = currentSaleQuantity > 0 ? cost_excluding_vat / currentSaleQuantity : 0;
    const unit_profit = currentSaleQuantity > 0 ? profit / currentSaleQuantity : 0;
    
    let html = `
        <div class="sale-details-grid">
            <div class="sale-detail-row">
                <span>გაყიდვა (დღგ-თი):</span>
                <strong>${total_revenue.toFixed(2)} ₾</strong>
            </div>
            <div class="sale-detail-row">
                <span>გაყიდვა (Ex.VAT):</span>
                <strong>${net_amount.toFixed(2)} ₾</strong>
            </div>
            <div class="sale-detail-row">
                <span>დღგ თანხა:</span>
                <strong>${vat_amount.toFixed(2)} ₾</strong>
            </div>
            <div class="sale-detail-row">
                <span>თვითღირ. (დღგ-თი):</span>
                <strong style="color: #dc3545;">${cost_with_vat.toFixed(2)} ₾</strong>
            </div>
            <div class="sale-detail-row">
                <span>თვითღირ. (Ex.VAT):</span>
                <strong style="color: #dc3545;">${cost_excluding_vat.toFixed(2)} ₾</strong>
            </div>
            <div class="sale-detail-row">
                <span>ამონაგები:</span>
                <strong style="color: #28a745;">${profit.toFixed(2)} ₾</strong>
            </div>
            <div class="sale-detail-row">
                <span>მარჟა:</span>
                <strong style="color: #28a745;">${margin_percent.toFixed(1)}%</strong>
            </div>
            <div class="sale-detail-row">
                <span>ერთეულის მოგება:</span>
                <strong>${unit_profit.toFixed(2)} ₾</strong>
            </div>
            <div class="sale-detail-row">
                <span>ერთეულის ღირებულება:</span>
                <strong>${unit_cost_with_vat.toFixed(2)} ₾</strong>
            </div>
        </div>
    `;
    
    $('#costDetailsGrid').html(html);
    $('#costDetailsSection').show();
}

// გაყიდვის დადასტურება
function confirmSale() {
    if (!currentSaleDishId || !calculatedCostDetails) return;
    
    const dish = dishes_js.find(d => parseInt(d.id) == currentSaleDishId);
    if (!dish) return;
    
    const saleData = {
        dish_id: currentSaleDishId,
        quantity: currentSaleQuantity,
        dish_name: dish.name,
        unit_price: currentSalePrice,
        total_price: currentSalePrice * currentSaleQuantity,
        cost_with_vat: calculatedCostDetails.cost_with_vat,
        cost_excluding_vat: calculatedCostDetails.cost_excluding_vat,
        csrf_token: csrf_token
    };
    
    const confirmMessage = 
        `დაადასტურეთ ${currentSaleQuantity} ცალი "${dish.name}"-ის გაყიდვა?\n\n` +
        `ჯამური ფასი: ${saleData.total_price.toFixed(2)} ₾\n` +
        `თვითღირებულება: ${calculatedCostDetails.cost_with_vat.toFixed(2)} ₾\n` +
        `მოგება: ${calculatedCostDetails.profit.toFixed(2)} ₾\n` +
        `მარჟა: ${calculatedCostDetails.margin_percent.toFixed(1)}%`;
    
    if (confirm(confirmMessage)) {
        $('#confirmSaleBtn').prop('disabled', true).text('⏳ მიმდინარეობს გაყიდვა...');
        
        $.ajax({
            url: 'ajax_process_sale.php',
            type: 'POST',
            data: saleData,
            dataType: 'json',
            success: function(response) {
                if (response.status === 1) {
                    alert('✅ კერძი წარმატებით გაიყიდა!');
                    closeSaleModal();
                    location.reload();
                } else {
                    let errorMessage = '❌ გაყიდვის შეცდომა: ' + (response.message || 'გაურკვეველი შეცდომა');
                    if (response.low_stock_items) {
                        errorMessage += '\n\nდეფიციტური პროდუქტები:';
                        response.low_stock_items.forEach(item => {
                            errorMessage += `\n- ${item.product_name}: საჭიროა ${item.required}, არის ${item.available}`;
                        });
                    }
                    alert(errorMessage);
                    $('#confirmSaleBtn').prop('disabled', false).text('✅ გაყიდვის დადასტურება');
                }
            },
            error: function(xhr, status, error) {
                alert('❌ შეცდომა სერვერთან კავშირში: ' + error);
                $('#confirmSaleBtn').prop('disabled', false).text('✅ გაყიდვის დადასტურება');
            }
        });
    }
}

// მოდალური ფანჯრის დახურვა
function closeSaleModal() {
    if (confirm('დარწმუნებული ხართ, რომ გსურთ მოდალური ფანჯრის დახურვა? ყველა ჩასმული მონაცემი დაიკარგება.')) {
        $('#saleModal').fadeOut();
        currentSaleDishId = null;
        currentSaleQuantity = 1;
        calculatedCostDetails = null;
    }
}


// ESC კლავიშით დახურვა
$(document).on('keydown', function(e) {
    if (e.key === 'Escape') {
        closeSaleModal();
    }
});

// მოდალური ფანჯრის გარეთ დაწკაპუნება
$('#saleModal').on('click', function(e) {
    if (e.target === this) {
        closeSaleModal();
    }
});

// ============================================
    // რეცეპტის ფუნქციონალის დამატება
    // ============================================
  // ========== რეცეპტის ფუნქციონალი ==========
// ========== რეცეპტის ფუნქციონალი ==========

// რეცეპტის ნახვა
$(document).on('click', '.viewRecipe', function() {
    const dishId = $(this).data('id');
    console.log('View recipe for dish ID:', dishId);
    viewDishRecipe(dishId);
});

// რეცეპტის რედაქტირება
$(document).on('click', '.editRecipe', function() {
    const dishId = $(this).data('id');
    console.log('Edit recipe for dish ID:', dishId);
    editDishRecipe(dishId);
});

// რეცეპტის ნახვის ფუნქცია
function viewDishRecipe(dishId) {
    console.log('Loading recipe for dish:', dishId);
    
    // ჩვენების ინდიკატორი
    const loadingHtml = `
        <div id="loadingOverlay" style="position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 9999; display: flex; align-items: center; justify-content: center;">
            <div style="background: white; padding: 30px; border-radius: 10px; text-align: center;">
                <div style="margin-bottom: 15px;">იტვირთება...</div>
                <div class="spinner"></div>
            </div>
        </div>
    `;
    $('body').append(loadingHtml);
    
    $.ajax({
        url: 'ajax_get_dish_calc.php',
        type: 'GET',
        data: { dish_id: dishId },
        dataType: 'json',
        success: function(response) {
            console.log('Recipe data received:', response);
            $('#loadingOverlay').remove();
            
            if (response.status === 1) {
                createRecipeViewModal(response);
            } else {
                alert('შეცდომა: ' + (response.message || 'მონაცემები ვერ მოიძებნა'));
            }
        },
        error: function(xhr, status, error) {
            $('#loadingOverlay').remove();
            console.error('AJAX Error:', status, error, xhr.responseText);
            alert('სერვერული შეცდომა. გთხოვთ სცადოთ მოგვიანებით.');
        }
    });
}

// რეცეპტის რედაქტირების ფუნქცია
function editDishRecipe(dishId) {
    console.log('Editing recipe for dish:', dishId);
    
    // ჩვენების ინდიკატორი
    const loadingHtml = `
        <div id="loadingOverlay" style="position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 9999; display: flex; align-items: center; justify-content: center;">
            <div style="background: white; padding: 30px; border-radius: 10px; text-align: center;">
                <div style="margin-bottom: 15px;">იტვირთება...</div>
                <div class="spinner"></div>
            </div>
        </div>
    `;
    $('body').append(loadingHtml);
    
    $.ajax({
        url: 'ajax_get_dish_calc.php',
        type: 'GET',
        data: { dish_id: dishId },
        dataType: 'json',
        success: function(response) {
            console.log('Recipe data received for editing:', response);
            $('#loadingOverlay').remove();
            
            if (response.status === 1) {
                createRecipeEditModal(response, dishId);
            } else {
                alert('შეცდომა: ' + (response.message || 'მონაცემები ვერ მოიძებნა'));
            }
        },
        error: function(xhr, status, error) {
            $('#loadingOverlay').remove();
            console.error('AJAX Error:', status, error, xhr.responseText);
            alert('სერვერული შეცდომა. გთხოვთ სცადოთ მოგვიანებით.');
        }
    });
}

// რეცეპტის ნახვის მოდალი
function createRecipeViewModal(response) {
    const salePrice = parseFloat(response.dish.sale_price) || 0;
    const totalCost = parseFloat(response.summary.cost_summary.total_cost_with_vat) || 0;
    const profit = parseFloat(response.summary.profit_summary.profit_excluding_vat) || 0;
    const margin = parseFloat(response.summary.profit_summary.margin_percent_excluding_vat) || 0;
    const revenueExcludingVat = parseFloat(response.summary.revenue_summary.revenue_excluding_vat) || 0;
    const vatOnRevenue = parseFloat(response.summary.revenue_summary.vat_on_revenue) || 0;
    const costExcludingVat = parseFloat(response.summary.cost_summary.total_cost_excluding_vat) || 0;
    const profitability = parseFloat(response.summary.profit_summary.profitability) || 0;
    
    const modalHtml = `
        <div id="recipeModal" class="modal-overlay" style="position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 1000; display: flex; align-items: center; justify-content: center;">
            <div style="background: white; padding: 25px; border-radius: 12px; width: 95%; max-width: 900px; max-height: 90vh; overflow-y: auto; box-shadow: 0 5px 15px rgba(0,0,0,0.2);">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px; border-bottom: 2px solid #6f42c1; padding-bottom: 15px;">
                    <h3 style="margin: 0; color: #6f42c1;">📊 ${response.dish.name} - რეცეპტის ანალიზი</h3>
                    <button onclick="$('#recipeModal').remove()" style="background: none; border: none; font-size: 28px; cursor: pointer; color: #666; padding: 0; width: 30px; height: 30px; line-height: 30px; text-align: center;">&times;</button>
                </div>
                
                <!-- ძირითადი მეტრიკები -->
                <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 15px; margin-bottom: 25px;">
                    <div style="background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%); padding: 20px; border-radius: 10px; border-left: 5px solid #28a745;">
                        <div style="font-size: 13px; color: #666; margin-bottom: 5px;">გასაყიდი ფასი</div>
                        <div style="font-size: 24px; font-weight: bold; color: #28a745;">${salePrice.toFixed(2)} ₾</div>
                    </div>
                    <div style="background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%); padding: 20px; border-radius: 10px; border-left: 5px solid #dc3545;">
                        <div style="font-size: 13px; color: #666; margin-bottom: 5px;">თვითღირებულება</div>
                        <div style="font-size: 24px; font-weight: bold; color: #dc3545;">${totalCost.toFixed(2)} ₾</div>
                    </div>
                    <div style="background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%); padding: 20px; border-radius: 10px; border-left: 5px solid #17a2b8;">
                        <div style="font-size: 13px; color: #666; margin-bottom: 5px;">მოგება</div>
                        <div style="font-size: 24px; font-weight: bold; color: #17a2b8;">${profit.toFixed(2)} ₾</div>
                    </div>
                    <div style="background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%); padding: 20px; border-radius: 10px; border-left: 5px solid #6f42c1;">
                        <div style="font-size: 13px; color: #666; margin-bottom: 5px;">მარჟა</div>
                        <div style="font-size: 24px; font-weight: bold; color: #6f42c1;">${margin.toFixed(2)}%</div>
                    </div>
                </div>
                
                <!-- ინგრედიენტების ცხრილი -->
                <div style="margin-bottom: 25px;">
                    <h4 style="color: #495057; border-bottom: 2px solid #dee2e6; padding-bottom: 10px; margin-bottom: 15px;">
                        ინგრედიენტები (${response.items.length})
                    </h4>
                    <div style="max-height: 300px; overflow-y: auto; border: 1px solid #dee2e6; border-radius: 8px;">
                        <table style="width: 100%; border-collapse: collapse;">
                            <thead>
                                <tr style="background: #6f42c1; color: white; position: sticky; top: 0;">
                                    <th style="padding: 12px 15px; text-align: left; font-weight: 600;">ინგრედიენტი</th>
                                    <th style="padding: 12px 15px; text-align: left; font-weight: 600;">რაოდენობა</th>
                                    <th style="padding: 12px 15px; text-align: left; font-weight: 600;">ერთეულის ფასი</th>
                                    <th style="padding: 12px 15px; text-align: left; font-weight: 600;">ღირებულება</th>
                                    <th style="padding: 12px 15px; text-align: left; font-weight: 600;">%</th>
                                </tr>
                            </thead>
                            <tbody>
                                ${response.items.map(item => {
                                    const quantity = parseFloat(item.quantity) || 0;
                                    const price = parseFloat(item.price) || 0;
                                    const costWithVat = parseFloat(item.cost_details?.cost_with_vat) || 0;
                                    const costPercentage = parseFloat(item.cost_details?.cost_percentage) || 0;
                                    const percentageColor = costPercentage > 30 ? '#dc3545' : (costPercentage > 15 ? '#fd7e14' : '#28a745');
                                    
                                    return `
                                        <tr style="border-bottom: 1px solid #eee; transition: background 0.2s;">
                                            <td style="padding: 12px 15px;">${item.product_name || ''}</td>
                                            <td style="padding: 12px 15px;">${quantity.toFixed(3)} ${item.unit || ''}</td>
                                            <td style="padding: 12px 15px;">${price.toFixed(2)} ₾</td>
                                            <td style="padding: 12px 15px; font-weight: 600;">${costWithVat.toFixed(2)} ₾</td>
                                            <td style="padding: 12px 15px; font-weight: 600; color: ${percentageColor};">${costPercentage.toFixed(1)}%</td>
                                        </tr>
                                    `;
                                }).join('')}
                            </tbody>
                        </table>
                    </div>
                </div>
                
                <!-- დეტალური ანალიზი -->
                <div style="background: #f8f9fa; padding: 20px; border-radius: 10px; margin-bottom: 25px;">
                    <h5 style="margin-top: 0; color: #495057; border-bottom: 1px solid #dee2e6; padding-bottom: 10px;">📈 დეტალური ანალიზი</h5>
                    <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 15px;">
                        <div>
                            <div style="font-size: 12px; color: #666; margin-bottom: 3px;">გაყიდვა დღგ-ს გარეშე</div>
                            <div style="font-size: 16px; font-weight: 600;">${revenueExcludingVat.toFixed(2)} ₾</div>
                        </div>
                        <div>
                            <div style="font-size: 12px; color: #666; margin-bottom: 3px;">დღგ თანხა</div>
                            <div style="font-size: 16px; font-weight: 600;">${vatOnRevenue.toFixed(2)} ₾</div>
                        </div>
                        <div>
                            <div style="font-size: 12px; color: #666; margin-bottom: 3px;">თვითღირებულება დღგ-ს გარეშე</div>
                            <div style="font-size: 16px; font-weight: 600;">${costExcludingVat.toFixed(2)} ₾</div>
                        </div>
                        <div>
                            <div style="font-size: 12px; color: #666; margin-bottom: 3px;">მომგებიანობა</div>
                            <div style="font-size: 16px; font-weight: 600; color: ${profitability > 0 ? '#28a745' : '#dc3545'};">${profitability.toFixed(2)}%</div>
                        </div>
                    </div>
                </div>
                
                <div style="text-align: center;">
                    <button onclick="$('#recipeModal').remove()" style="background: #6f42c1; color: white; border: none; padding: 12px 30px; border-radius: 6px; cursor: pointer; font-size: 16px; transition: background 0.3s;">
                        დახურვა
                    </button>
                </div>
            </div>
        </div>
    `;
    
    $('#recipeModal').remove();
    $('body').append(modalHtml);
    $('#recipeModal').fadeIn();
}

// რეცეპტის რედაქტირების მოდალი (დამატებული ელემენტებით)
function createRecipeEditModal(response, dishId) {
    const dish = dishes_js.find(d => parseInt(d.id) == dishId);
    
    const modalHtml = `
        <div id="recipeEditModal" class="modal-overlay" style="position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 1000; display: flex; align-items: center; justify-content: center;">
            <div style="background: white; padding: 25px; border-radius: 12px; width: 95%; max-width: 900px; max-height: 90vh; overflow-y: auto; box-shadow: 0 5px 15px rgba(0,0,0,0.2);">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px; border-bottom: 2px solid #6f42c1; padding-bottom: 15px;">
                    <h3 style="margin: 0; color: #6f42c1;">✏️ ${dish?.name || response.dish.name} - რეცეპტის რედაქტირება</h3>
                    <button onclick="$('#recipeEditModal').remove()" style="background: none; border: none; font-size: 28px; cursor: pointer; color: #666; padding: 0; width: 30px; height: 30px; line-height: 30px; text-align: center;">&times;</button>
                </div>
                
                <!-- ახალი ინგრედიენტის დამატების ფორმა -->
                <div style="background: #f8f9fa; padding: 20px; border-radius: 10px; margin-bottom: 25px;">
                    <h4 style="margin-top: 0; color: #495057; margin-bottom: 15px;">➕ ახალი ინგრედიენტის დამატება</h4>
                    
                    <div style="display: grid; grid-template-columns: 2fr 1fr 1fr auto; gap: 12px; align-items: end;">
                        <!-- პროდუქტის არჩევა -->
                        <div>
                            <label style="display: block; font-size: 12px; color: #666; margin-bottom: 5px;">პროდუქტი</label>
                            <select id="newIngredientProduct" style="width: 100%; padding: 10px; border: 1px solid #ced4da; border-radius: 5px; font-size: 14px;">
                                <option value="">-- აირჩიეთ პროდუქტი --</option>
                                ${products_js.map(p => {
                                    const price = parseFloat(p.price) || 0;
                                    const unit = p.unit || 'ც';
                                    return `<option value="${p.id}" data-price="${price}" data-unit="${unit}">${p.name} (${price.toFixed(2)} ₾/${unit})</option>`;
                                }).join('')}
                            </select>
                        </div>
                        
                        <!-- რაოდენობა -->
                        <div>
                            <label style="display: block; font-size: 12px; color: #666; margin-bottom: 5px;">რაოდენობა</label>
                            <input type="number" id="newIngredientQuantity" step="0.001" min="0.001" placeholder="მაგ. 0.250" style="width: 100%; padding: 10px; border: 1px solid #ced4da; border-radius: 5px; font-size: 14px;">
                        </div>
                        
                        <!-- ერთეული -->
                        <div>
                            <label style="display: block; font-size: 12px; color: #666; margin-bottom: 5px;">ერთეული</label>
                            <select id="newIngredientUnit" style="width: 100%; padding: 10px; border: 1px solid #ced4da; border-radius: 5px; font-size: 14px;">
                                <option value="კგ">კგ</option>
                                <option value="გრ">გრ</option>
                                <option value="ლ">ლ</option>
                                <option value="მლ">მლ</option>
                                <option value="ც">ც</option>
                                <option value="თეთი">თეთი</option>
                                <option value="ფუთი">ფუთი</option>
                            </select>
                        </div>
                        
                        <!-- დამატების ღილაკი -->
                        <div>
                            <button onclick="addNewIngredient(${dishId})" style="background: #28a745; color: white; border: none; padding: 10px 20px; border-radius: 5px; cursor: pointer; font-size: 14px; transition: background 0.3s;">
                                დამატება
                            </button>
                        </div>
                    </div>
                </div>
                
                <!-- არსებული ინგრედიენტები -->
                <div style="margin-bottom: 25px;">
                    <h4 style="color: #495057; border-bottom: 2px solid #dee2e6; padding-bottom: 10px; margin-bottom: 15px;">
                        📋 არსებული ინგრედიენტები (${response.items.length})
                    </h4>
                    
                    ${response.items.length === 0 ? 
                        '<div style="text-align: center; padding: 30px; color: #666; background: #f8f9fa; border-radius: 8px;">ინგრედიენტები არ არის დამატებული</div>' : 
                        `<div style="max-height: 400px; overflow-y: auto; border: 1px solid #dee2e6; border-radius: 8px;">
                            ${response.items.map((item, index) => {
                                const quantity = parseFloat(item.quantity) || 0;
                                const price = parseFloat(item.price) || 0;
                                const cost = quantity * price;
                                
                                return `
                                    <div style="display: flex; justify-content: space-between; align-items: center; padding: 15px; border-bottom: 1px solid #eee; background: ${index % 2 === 0 ? '#fff' : '#f8f9fa'};" data-id="${item.id}">
                                        <div style="flex: 2;">
                                            <strong style="display: block; margin-bottom: 5px;">${item.product_name || 'უსახელო'}</strong>
                                            <small style="color: #666;">ID: ${item.id} | ერთეულის ფასი: ${price.toFixed(2)} ₾</small>
                                        </div>
                                        
                                        <div style="flex: 1; display: flex; gap: 10px; align-items: center;">
                                            <input type="number" value="${quantity}" step="0.001" min="0.001" id="qty-${item.id}" style="width: 100px; padding: 8px; border: 1px solid #ced4da; border-radius: 4px; font-size: 14px;">
                                            <span>${item.unit || ''}</span>
                                        </div>
                                        
                                        <div style="flex: 1; text-align: right; font-weight: 600; color: #dc3545;">
                                            ${cost.toFixed(2)} ₾
                                        </div>
                                        
                                        <div style="flex: 1; display: flex; gap: 8px; justify-content: flex-end;">
                                            <button onclick="updateIngredient(${item.id}, ${dishId})" style="background: #007bff; color: white; border: none; padding: 8px 15px; border-radius: 4px; cursor: pointer; font-size: 13px; transition: background 0.3s;">
                                                განახლება
                                            </button>
                                            <button onclick="removeIngredient(${item.id}, ${dishId})" style="background: #dc3545; color: white; border: none; padding: 8px 15px; border-radius: 4px; cursor: pointer; font-size: 13px; transition: background 0.3s;">
                                                წაშლა
                                            </button>
                                        </div>
                                    </div>
                                `;
                            }).join('')}
                        </div>`
                    }
                </div>
                
                <!-- მოქმედებები -->
                <div style="display: flex; justify-content: space-between; align-items: center; padding-top: 20px; border-top: 1px solid #dee2e6;">
                    <div style="color: #666; font-size: 14px;">
                        სულ ინგრედიენტები: ${response.items.length}
                    </div>
                    <div style="display: flex; gap: 10px;">
                        <button onclick="$('#recipeEditModal').remove()" style="background: #6c757d; color: white; border: none; padding: 10px 25px; border-radius: 5px; cursor: pointer; font-size: 14px;">
                            დახურვა
                        </button>
                    </div>
                </div>
            </div>
        </div>
    `;
    
    $('#recipeEditModal').remove();
    $('body').append(modalHtml);
    $('#recipeEditModal').fadeIn();
    
    // პროდუქტის არჩევისას ერთეულის ავტომატური შევსება
    $('#newIngredientProduct').change(function() {
        const selectedOption = $(this).find('option:selected');
        const unit = selectedOption.data('unit');
        if (unit) {
            $('#newIngredientUnit').val(unit);
        }
    });
}

// ინგრედიენტის დამატება
function addNewIngredient(dishId) {
    const productId = $('#newIngredientProduct').val();
    const quantity = $('#newIngredientQuantity').val();
    const unit = $('#newIngredientUnit').val();
    
    // ვალიდაცია
    if (!productId) {
        alert('გთხოვთ აირჩიოთ პროდუქტი');
        $('#newIngredientProduct').focus();
        return;
    }
    
    if (!quantity || quantity <= 0) {
        alert('გთხოვთ მიუთითოთ სწორი რაოდენობა (მინიმუმ 0.001)');
        $('#newIngredientQuantity').focus();
        return;
    }
    
    // AJAX მოთხოვნა
    $.ajax({
        url: 'ajax_save_dish_ingredient.php',
        type: 'POST',
        data: {
            action: 'add',
            dish_id: dishId,
            product_id: productId,
            quantity: quantity,
            unit: unit,
            csrf_token: csrf_token
        },
        dataType: 'json',
        success: function(response) {
            if (response.status === 1) {
                alert('✅ ინგრედიენტი წარმატებით დაემატა!');
                // განაახლე მოდალი
                editDishRecipe(dishId);
            } else {
                alert('❌ შეცდომა: ' + response.message);
            }
        },
        error: function(xhr, status, error) {
            alert('❌ სერვერული შეცდომა: ' + error);
        }
    });
}

// ინგრედიენტის განახლება
function updateIngredient(ingredientId, dishId) {
    const newQuantity = $('#qty-' + ingredientId).val();
    
    if (!newQuantity || newQuantity <= 0) {
        alert('გთხოვთ მიუთითოთ სწორი რაოდენობა');
        return;
    }
    
    if (!confirm('გსურთ ინგრედიენტის რაოდენობის განახლება?')) {
        return;
    }
    
    $.ajax({
        url: 'ajax_save_dish_ingredient.php',
        type: 'POST',
        data: {
            action: 'update',
            ingredient_id: ingredientId,
            quantity: newQuantity,
            csrf_token: csrf_token
        },
        dataType: 'json',
        success: function(response) {
            if (response.status === 1) {
                alert('✅ ინგრედიენტი განახლდა!');
                // განაახლე მოდალი
                editDishRecipe(dishId);
            } else {
                alert('❌ შეცდომა: ' + response.message);
            }
        },
        error: function(xhr, status, error) {
            alert('❌ სერვერული შეცდომა: ' + error);
        }
    });
}

// ინგრედიენტის წაშლა
function removeIngredient(ingredientId, dishId) {
    if (!confirm('დარწმუნებული ხართ, რომ გსურთ ამ ინგრედიენტის წაშლა?')) {
        return;
    }
    
    $.ajax({
        url: 'ajax_delete_dish_ingredient.php',
        type: 'POST',
        data: {
            ingredient_id: ingredientId,
            csrf_token: csrf_token
        },
        dataType: 'json',
        success: function(response) {
            if (response.status === 1) {
                alert('✅ ინგრედიენტი წაიშალა!');
                // განაახლე მოდალი
                editDishRecipe(dishId);
            } else {
                alert('❌ შეცდომა: ' + response.message);
            }
        },
        error: function(xhr, status, error) {
            alert('❌ სერვერული შეცდომა: ' + error);
        }
    });
}

// ========== დამატებითი CSS ==========
const additionalCSS = `
<style>
    .modal-overlay {
        animation: fadeIn 0.3s ease;
    }
    
    @keyframes fadeIn {
        from { opacity: 0; }
        to { opacity: 1; }
    }
    
    .spinner {
        border: 4px solid #f3f3f3;
        border-top: 4px solid #6f42c1;
        border-radius: 50%;
        width: 40px;
        height: 40px;
        animation: spin 1s linear infinite;
        margin: 0 auto;
    }
    
    @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
    }
    
    select, input[type="number"] {
        transition: border-color 0.3s, box-shadow 0.3s;
    }
    
    select:focus, input[type="number"]:focus {
        border-color: #6f42c1 !important;
        box-shadow: 0 0 0 0.2rem rgba(111, 66, 193, 0.25) !important;
        outline: none;
    }
    
    button {
        transition: all 0.3s ease;
    }
    
    button:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 8px rgba(0,0,0,0.1);
    }
</style>
`;

// დამატე CSS
$('head').append(additionalCSS);
</script>
<?php include '../includes/footer.php'; ?>
</body>
</html>