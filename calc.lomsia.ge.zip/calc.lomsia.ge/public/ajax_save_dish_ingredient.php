<?php
session_start();
require_once __DIR__ . '/../config/db.php';

header('Content-Type: application/json');

// CSRF ვალიდაცია
if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
    echo json_encode(['status' => 0, 'message' => 'Invalid CSRF token']);
    exit;
}

$action = $_POST['action'] ?? '';
$dish_id = intval($_POST['dish_id'] ?? 0);
$product_id = intval($_POST['product_id'] ?? 0);
$quantity = floatval($_POST['quantity'] ?? 0);
$unit = $_POST['unit'] ?? '';
$ingredient_id = intval($_POST['ingredient_id'] ?? 0);

try {
    if ($action === 'add') {
        // დამატება
        $stmt = $mysqli->prepare("INSERT INTO dish_calc (dish_id, product_id, quantity, unit) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("iids", $dish_id, $product_id, $quantity, $unit);
    } elseif ($action === 'update') {
        // განახლება
        $stmt = $mysqli->prepare("UPDATE dish_calc SET quantity = ? WHERE id = ?");
        $stmt->bind_param("di", $quantity, $ingredient_id);
    } else {
        throw new Exception("Invalid action");
    }
    
    if ($stmt->execute()) {
        echo json_encode(['status' => 1, 'message' => 'Operation successful']);
    } else {
        throw new Exception("Database error: " . $stmt->error);
    }
    
    $stmt->close();
} catch (Exception $e) {
    echo json_encode(['status' => 0, 'message' => $e->getMessage()]);
}