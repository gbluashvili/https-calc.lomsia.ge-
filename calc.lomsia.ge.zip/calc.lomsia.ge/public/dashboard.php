<?php
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../includes/auth/auth_functions.php';

/**
 * თუ არ არის ავტორიზებული — ლოგინზე
 */
requireLogin();

// სურვილის შემთხვევაში
$username = $_SESSION['username'] ?? '';
$role     = $_SESSION['role'] ?? '';
?>
<!DOCTYPE html>
<html lang="ka">
<head>
    <meta charset="UTF-8">
    <title>Dashboard</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #f4f6f8;
        }
        header {
            background: #0d6efd;
            color: #fff;
            padding: 15px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        header .user {
            font-size: 14px;
        }
        .container {
            padding: 20px;
        }
        .cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 20px;
        }
        .card {
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        .card h3 {
            margin-top: 0;
        }
        .card a {
            display: inline-block;
            margin-top: 10px;
            text-decoration: none;
            color: #0d6efd;
            font-weight: bold;
        }
        .logout-btn {
            background: #dc3545;
            color: #fff;
            border: none;
            padding: 8px 14px;
            border-radius: 5px;
            cursor: pointer;
        }
        .logout-btn:hover {
            background: #bb2d3b;
        }
    </style>
</head>
<body>

<header>
    <div>
        <strong>კალკულაციის სისტემა</strong>
    </div>

    <div class="user">
        მომხმარებელი: <strong><?= htmlspecialchars($username) ?></strong>
        <?php if ($role): ?>
            | როლი: <strong><?= htmlspecialchars($role) ?></strong>
        <?php endif; ?>
    </div>

    <form method="post" action="logout.php" style="margin:0;">
        <button type="submit" class="logout-btn">გამოსვლა</button>
    </form>
</header>

<div class="container">

    <h2>მართვის პანელი</h2>

    <div class="cards">

        <div class="card">
            <h3>პროდუქტები</h3>
            <p>პროდუქტების დამატება და რედაქტირება</p>
            <a href="products.php">გადასვლა →</a>
        </div>

        <div class="card">
            <h3>კერძები</h3>
            <p>კერძების კალკულაცია და რეცეპტები</p>
            <a href="dishes.php">გადასვლა →</a>
        </div>

        <div class="card">
            <h3>გაყიდვები</h3>
            <p>გაყიდული კერძების აღრიცხვა</p>
            <a href="sales.php">გადასვლა →</a>
        </div>

        <?php if (hasRole('admin')): ?>
        <div class="card">
            <h3>მომხმარებლები</h3>
            <p>მომხმარებლების მართვა</p>
            <a href="admin_users.php">გადასვლა →</a>
        </div>
        <?php endif; ?>

    </div>

</div>

</body>
</html>
