<?php
require_once __DIR__ . '/../config/db.php';

header('Content-Type: application/json');

if (!isset($_GET['search'])) {
    echo json_encode(['status' => 0, 'message' => 'ძებნის ტექსტი არ არის მითითებული']);
    exit;
}

$search = trim($_GET['search']);
$search = '%' . $search . '%';

try {
    $stmt = $pdo->prepare("
        SELECT id, name, unit, price, has_vat, stock_quantity 
        FROM products 
        WHERE name LIKE :search 
        OR id LIKE :search 
        ORDER BY name ASC 
        LIMIT 10
    ");
    $stmt->bindParam(':search', $search);
    $stmt->execute();
    
    $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode([
        'status' => 1,
        'products' => $products
    ]);
    
} catch (PDOException $e) {
    echo json_encode(['status' => 0, 'message' => 'ბაზის შეცდომა: ' . $e->getMessage()]);
}
?>