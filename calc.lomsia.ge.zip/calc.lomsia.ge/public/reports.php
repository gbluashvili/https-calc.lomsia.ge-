<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
require_once dirname(__DIR__) . '/includes/auth_check.php';
require_once __DIR__ . '/../config/db.php';

// დარწმუნდით, რომ სესია მუშაობს
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$date_from = $_GET['date_from'] ?? date('Y-m-d');
$date_to   = $_GET['date_to']   ?? date('Y-m-d');

// ვამოწმებთ ბაზასთან კავშირს
if (!$mysqli) {
    die("Database connection failed: " . mysqli_connect_error());
}

// SQL query - სწორი ველების გამოყენება
$query = "SELECT 
            s.id,
            s.dish_name,
            s.quantity,
            s.total_with_vat,      -- მთლიანი შემოსავალი დღგ-ით (net_amount + vat_amount)
            s.net_amount,          -- შემოსავალი დღგ-ს გარეშე
            s.vat_amount,          -- დღგ
            s.total_amount,        -- თვითღირებულება დღგ-ით (არეული ველი)
            s.sale_price,
            s.total_price,         -- ალტერნატიული შემოსავალი
            s.cost_with_vat,       -- თვითღირებულება დღგ-ით
            s.cost_excluding_vat,  -- თვითღირებულება დღგ-ს გარეშე
            s.profit,              -- მოგება
            s.margin_percent,      -- მარჟა პროცენტულად
            s.sale_date,
            s.unit_cost_with_vat,
            s.unit_cost_excluding_vat,
            s.unit_profit
          FROM sales s 
          WHERE DATE(s.sale_date) >= ? AND DATE(s.sale_date) <= ? 
          ORDER BY s.sale_date DESC";

$stmt = $mysqli->prepare($query);
if (!$stmt) {
    die("Prepare failed: " . $mysqli->error);
}

$stmt->bind_param("ss", $date_from, $date_to);
if (!$stmt->execute()) {
    die("Execute failed: " . $stmt->error);
}

$result = $stmt->get_result();
$sales = $result->fetch_all(MYSQLI_ASSOC);

// ნაგულისხმევი მნიშვნელობები
$total_cost_with_vat = 0;
$total_cost_excl_vat = 0;
$total_revenue = 0;
$total_profit = 0;
$total_quantity = 0;
$total_vat_amount = 0;
$margin_categories = [
    'მაღალი' => 0,   // > 30%
    'კარგი' => 0,    // 15-30%
    'დაბალი' => 0,   // 0-15%
    'ზარალი' => 0,   // < 0%
];

// სტატისტიკის გაანგარიშება
if (!empty($sales)) {
    foreach($sales as $s) {
        // გამოვთვალოთ სწორი შემოსავალი
        // 1. total_with_vat (თუ არსებობს)
        $revenue = (float)($s['total_with_vat'] ?? 0);
        
        // 2. თუ total_with_vat ცარიელია, გამოვთვალოთ net_amount + vat_amount
        if ($revenue <= 0) {
            $revenue = ((float)($s['net_amount'] ?? 0) + (float)($s['vat_amount'] ?? 0));
        }
        
        // 3. თუ მაინც ცარიელია, გამოვიყენოთ total_price
        if ($revenue <= 0) {
            $revenue = (float)($s['total_price'] ?? 0);
        }
        
        // ვატის დამატება
        $vat_amount = (float)($s['vat_amount'] ?? 0);
        $total_vat_amount += $vat_amount;
        
        // ხარჯები - უპირატესობა cost_with_vat-ს
        $cost_with_vat = (float)($s['cost_with_vat'] ?? 0);
        // თუ cost_with_vat ცარიელია, გამოვიყენოთ total_amount (რომელიც სინამდვილეში თვითღირებულებაა)
        if ($cost_with_vat <= 0) {
            $cost_with_vat = (float)($s['total_amount'] ?? 0);
        }
        
        $cost_excl_vat = (float)($s['cost_excluding_vat'] ?? 0);
        $profit = (float)($s['profit'] ?? 0);
        $margin = (float)($s['margin_percent'] ?? 0);
        $quantity = (float)($s['quantity'] ?? 0);
        $sale_price = (float)($s['sale_price'] ?? 0);
        
        // თუ profit არ არის გამოთვლილი, გამოვთვალოთ
        if ($profit <= 0 && $revenue > 0) {
            $profit = $revenue - $cost_with_vat;
        }
        
        // თუ margin არ არის გამოთვლილი, გამოვთვალოთ
        if ($margin <= 0 && $revenue > 0 && $profit > 0) {
            $margin = ($profit / $revenue) * 100;
        }
        
        $total_cost_with_vat += $cost_with_vat;
        $total_cost_excl_vat += $cost_excl_vat;
        $total_revenue += $revenue;
        $total_profit += $profit;
        $total_quantity += $quantity;
        
        // მარჟის კატეგორიები
        if ($margin > 30) {
            $margin_categories['მაღალი']++;
        } elseif ($margin >= 15) {
            $margin_categories['კარგი']++;
        } elseif ($margin >= 0) {
            $margin_categories['დაბალი']++;
        } else {
            $margin_categories['ზარალი']++;
        }
    }
    
    $avg_margin = $total_revenue > 0 ? ($total_profit / $total_revenue) * 100 : 0;
} else {
    $avg_margin = 0;
}

// უნიკალური კერძების რაოდენობა
$unique_dishes = !empty($sales) ? count(array_unique(array_column($sales, 'dish_name'))) : 0;

// ===========================================
// ჰედერის ჩასმა
// ===========================================
$page_title = "გაყიდვების რეპორტები";
ob_start(); // ბუფერის დაწყება შეცდომების თავიდან ასაცილებლად
include '../includes/header.php';
// ===========================================
?>

<!-- მთავარი კონტენტი იწყება აქ (ჰედერის შემდეგ) -->

<div class="container" style="max-width: 1400px; margin: 20px auto; background: white; padding: 25px; border-radius: 12px; box-shadow: 0 4px 20px rgba(0,0,0,0.08);">
    
    <!-- ფილტრის ფორმა -->
    <div class="filter-bar" style="background: #f8f9fa; padding: 20px; border-radius: 10px; margin-bottom: 25px;">
        <h3 style="margin-top: 0; margin-bottom: 15px; color: #333;">
            <i class="fas fa-filter"></i> ფილტრაცია პერიოდის მიხედვით
        </h3>
        <form method="GET" style="display: flex; align-items: center; gap: 15px; flex-wrap: wrap;">
            <div style="display: flex; align-items: center; gap: 8px;">
                <label style="font-weight: 600; color: #555;"><i class="far fa-calendar-alt"></i> დან:</label>
                <input type="date" name="date_from" value="<?= htmlspecialchars($date_from) ?>" 
                       style="padding: 10px 15px; border: 2px solid #ddd; border-radius: 8px; font-size: 14px; min-width: 150px;">
            </div>
            <div style="display: flex; align-items: center; gap: 8px;">
                <label style="font-weight: 600; color: #555;"><i class="far fa-calendar-alt"></i> მდე:</label>
                <input type="date" name="date_to" value="<?= htmlspecialchars($date_to) ?>" 
                       style="padding: 10px 15px; border: 2px solid #ddd; border-radius: 8px; font-size: 14px; min-width: 150px;">
            </div>
            <button type="submit" class="btn btn-blue" style="padding: 10px 20px;">
                <i class="fas fa-search"></i> გაფილტვრა
            </button>
            <a href="reports.php" class="btn btn-gray" style="padding: 10px 20px;">
                <i class="fas fa-trash-alt"></i> გასუფთავება
            </a>
            <?php if(!empty($sales)): ?>
            <a href="#" onclick="window.print()" class="btn btn-green" style="padding: 10px 20px;">
                <i class="fas fa-print"></i> ამობეჭდვა
            </a>
            <?php endif; ?>
        </form>
    </div>

    <!-- პერიოდის ინფორმაცია -->
    <div style="background: #e7f3ff; padding: 12px 20px; border-radius: 8px; margin-bottom: 25px; border-left: 4px solid #007bff;">
        <p style="margin: 0; font-weight: 600; color: #007bff;">
            <i class="fas fa-info-circle"></i> პერიოდი: 
            <?= date('d.m.Y', strtotime($date_from)) ?> - <?= date('d.m.Y', strtotime($date_to)) ?>
            <span style="float: right; font-weight: normal;">
                რეპორტი გენერირებულია: <?= date('d.m.Y H:i:s') ?>
            </span>
        </p>
    </div>

    <!-- სტატისტიკის ბარათები -->
    <div class="stat-cards" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 20px; margin-bottom: 30px;">
        <div class="stat-card" style="border-color: #17a2b8; background: white;">
            <h4 style="color: #17a2b8; font-size: 14px; margin-bottom: 10px;">
                <i class="fas fa-chart-line"></i> შემოსავალი
            </h4>
            <div class="stat-value" style="color: #17a2b8; font-size: 1.8em; font-weight: 700;">
                <?= number_format($total_revenue, 2) ?> ₾
            </div>
            <div style="margin-top: 8px; font-size: 13px; color: #666;">
                <span><i class="fas fa-percentage"></i> დღგ-ს ჩათვლით</span><br>
                <span style="color: #999;">დღგ-ს გარეშე: <?= number_format($total_revenue - $total_vat_amount, 2) ?> ₾</span>
            </div>
        </div>
        
        <div class="stat-card" style="border-color: #dc3545; background: white;">
            <h4 style="color: #dc3545; font-size: 14px; margin-bottom: 10px;">
                <i class="fas fa-money-bill-wave"></i> დანახარჯები
            </h4>
            <div class="stat-value" style="color: #dc3545; font-size: 1.8em; font-weight: 700;">
                <?= number_format($total_cost_with_vat, 2) ?> ₾
            </div>
            <div style="margin-top: 8px; font-size: 13px; color: #666;">
                <span><i class="fas fa-percentage"></i> დღგ-ს ჩათვლით</span><br>
                <span style="color: #999;">დღგ-ს გარეშე: <?= number_format($total_cost_excl_vat, 2) ?> ₾</span>
            </div>
        </div>
        
        <div class="stat-card" style="border-color: #28a745; background: white;">
            <h4 style="color: #28a745; font-size: 14px; margin-bottom: 10px;">
                <i class="fas fa-hand-holding-usd"></i> მოგება
            </h4>
            <div class="stat-value" style="color: #28a745; font-size: 1.8em; font-weight: 700;">
                <?= number_format($total_profit, 2) ?> ₾
            </div>
            <div style="margin-top: 8px; font-size: 13px; color: #666;">
                <span><i class="fas fa-percentage"></i> საშუალო მარჟა: <?= number_format($avg_margin, 2) ?>%</span><br>
                <span style="color: #28a745;">მოგება დღგ-ს გარეშე: <?= number_format($total_revenue - $total_vat_amount - $total_cost_excl_vat, 2) ?> ₾</span>
            </div>
        </div>
        
        <div class="stat-card" style="border-color: #6f42c1; background: white;">
            <h4 style="color: #6f42c1; font-size: 14px; margin-bottom: 10px;">
                <i class="fas fa-shopping-cart"></i> გაყიდვები
            </h4>
            <div class="stat-value" style="color: #6f42c1; font-size: 1.8em; font-weight: 700;">
                <?= number_format($total_quantity, 0) ?>
            </div>
            <div style="margin-top: 8px; font-size: 13px; color: #666;">
                <span><i class="fas fa-boxes"></i> <?= count($sales) ?> ტრანზაქცია</span><br>
                <span><i class="fas fa-utensils"></i> <?= $unique_dishes ?> კერძი</span>
            </div>
        </div>
    </div>

    <!-- მარჟის განაწილება -->
    <div style="background: #f8f9fa; padding: 15px; border-radius: 8px; margin-bottom: 25px; display: flex; justify-content: space-around; flex-wrap: wrap; gap: 15px;">
        <?php foreach($margin_categories as $category => $count): 
            $color = $category === 'მაღალი' ? '#28a745' :
                    ($category === 'კარგი' ? '#20c997' :
                    ($category === 'დაბალი' ? '#ffc107' :
                    ($category === 'ზარალი' ? '#dc3545' : '#6c757d')));
        ?>
        <div style="text-align: center;">
            <div style="font-size: 1.5em; font-weight: 700; color: <?= $color ?>;">
                <?= $count ?>
            </div>
            <div style="font-size: 12px; color: #666;">
                <?= $category ?> მარჟა
            </div>
        </div>
        <?php endforeach; ?>
    </div>

    <!-- ცხრილი -->
    <div class="table-container">
        <h2 style="margin-top: 0; padding-bottom: 15px; border-bottom: 2px solid #f0f0f0; color: #333; font-size: 1.5em;">
            <i class="fas fa-table"></i> გაყიდვების დეტალური რეპორტი
            <span style="float: right; font-size: 14px; font-weight: normal; color: #666;">
                სულ: <?= count($sales) ?> ჩანაწერი
            </span>
        </h2>
        
        <?php if(empty($sales)): ?>
            <div class="empty-message" style="text-align: center; padding: 60px 40px; background: #f8f9fa; border-radius: 8px; margin: 20px 0;">
                <div style="font-size: 4em; color: #ddd; margin-bottom: 20px;">
                    <i class="fas fa-chart-bar"></i>
                </div>
                <h3 style="color: #666; margin-bottom: 10px;">📭 გაყიდვების რეპორტი ცარიელია</h3>
                <p style="color: #888; max-width: 400px; margin: 0 auto 20px;">
                    არჩეულ პერიოდში არ არის გაყიდვების ჩანაწერები
                </p>
                <a href="reports.php" class="btn btn-blue" style="padding: 10px 20px;">
                    <i class="fas fa-calendar-day"></i> დღევანდელი თარიღი
                </a>
            </div>
        <?php else: ?>
            <div style="margin-bottom: 15px; display: flex; justify-content: space-between; align-items: center;">
                <div style="font-size: 14px; color: #666;">
                    <i class="fas fa-info-circle"></i> გადაადგილეთ სვეტების სათაურები სორტირებისთვის
                </div>
                <div>
                    <button onclick="exportToCSV()" class="btn btn-green" style="padding: 8px 15px; font-size: 14px; margin-left: 10px;">
                        <i class="fas fa-file-csv"></i> CSV ექსპორტი
                    </button>
                </div>
            </div>
            
            <div style="overflow-x: auto;">
                <table id="reportsTable" style="width:100%; border-collapse: collapse;">
                    <thead>
                        <tr style="background-color: #f8f9fa;">
                            <th style="padding: 12px 10px; border-bottom: 2px solid #dee2e6; cursor: pointer;" onclick="sortTable(0)">თარიღი ⇅</th>
                            <th style="padding: 12px 10px; border-bottom: 2px solid #dee2e6; cursor: pointer;" onclick="sortTable(1)">კერძი ⇅</th>
                            <th style="padding: 12px 10px; text-align: center; border-bottom: 2px solid #dee2e6; cursor: pointer;" onclick="sortTable(2)">რაოდენობა ⇅</th>
                            <th style="padding: 12px 10px; text-align: right; border-bottom: 2px solid #dee2e6; cursor: pointer;" onclick="sortTable(3)">შემოსავალი ⇅</th>
                            <th style="padding: 12px 10px; text-align: right; border-bottom: 2px solid #dee2e6; cursor: pointer;" onclick="sortTable(4)">ღირებულება ⇅</th>
                            <th style="padding: 12px 10px; text-align: right; border-bottom: 2px solid #dee2e6; cursor: pointer;" onclick="sortTable(5)">მოგება ⇅</th>
                            <th style="padding: 12px 10px; text-align: center; border-bottom: 2px solid #dee2e6; cursor: pointer;" onclick="sortTable(6)">მარჟა ⇅</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($sales as $s): 
                            // გამოვთვალოთ სწორი შემოსავალი
                            $revenue = (float)($s['total_with_vat'] ?? 0);
                            if ($revenue <= 0) {
                                $revenue = ((float)($s['net_amount'] ?? 0) + (float)($s['vat_amount'] ?? 0));
                            }
                            if ($revenue <= 0) {
                                $revenue = (float)($s['total_price'] ?? 0);
                            }
                            
                            // ვატის თანხა
                            $vat_amount = (float)($s['vat_amount'] ?? 0);
                            
                            // ხარჯები
                            $cost_with_vat = (float)($s['cost_with_vat'] ?? 0);
                            if ($cost_with_vat <= 0) {
                                $cost_with_vat = (float)($s['total_amount'] ?? 0);
                            }
                            $cost_excl_vat = (float)($s['cost_excluding_vat'] ?? 0);
                            
                            // მოგება
                            $profit = (float)($s['profit'] ?? 0);
                            if ($profit <= 0 && $revenue > 0) {
                                $profit = $revenue - $cost_with_vat;
                            }
                            
                            // მარჟა
                            $margin = (float)($s['margin_percent'] ?? 0);
                            if ($margin <= 0 && $revenue > 0 && $profit > 0) {
                                $margin = ($profit / $revenue) * 100;
                            }
                            
                            $quantity = (float)($s['quantity'] ?? 0);
                            $sale_price = (float)($s['sale_price'] ?? 0);
                            $unit_price = $quantity > 0 ? $sale_price : 0;
                            
                            // ერთეულის ხარჯები
                            $unit_cost_with_vat = (float)($s['unit_cost_with_vat'] ?? 0);
                            $unit_cost_excl_vat = (float)($s['unit_cost_excluding_vat'] ?? 0);
                            $unit_profit = (float)($s['unit_profit'] ?? 0);
                        ?>
                        <tr>
                            <td style="padding: 10px; border-bottom: 1px solid #f0f0f0;">
                                <div style="font-weight: 600;"><?= date('d.m.Y', strtotime($s['sale_date'])) ?></div>
                                <div style="font-size: 12px; color: #888;"><?= date('H:i:s', strtotime($s['sale_date'])) ?></div>
                            </td>
                            <td style="padding: 10px; border-bottom: 1px solid #f0f0f0;">
                                <strong><?= htmlspecialchars($s['dish_name']) ?></strong>
                            </td>
                            <td style="padding: 10px; text-align: center; font-weight: 600; border-bottom: 1px solid #f0f0f0;">
                                <?= number_format($quantity, 0) ?>
                                <?php if($quantity > 0 && $unit_price > 0): ?>
                                <div style="font-size: 12px; color: #666;">
                                    ერთეულის ფასი: <?= number_format($unit_price, 2) ?> ₾
                                </div>
                                <?php endif; ?>
                            </td>
                            <td style="padding: 10px; text-align: right; font-weight: 600; color: #17a2b8; border-bottom: 1px solid #f0f0f0;">
                                <div><?= number_format($revenue, 2) ?> ₾</div>
                                <div style="font-size: 12px; color: #999;">
                                    დღგ-ს გარეშე: <?= number_format($revenue - $vat_amount, 2) ?> ₾
                                </div>
                            </td>
                            <td style="padding: 10px; text-align: right; border-bottom: 1px solid #f0f0f0;">
                                <div style="color: #dc3545; font-weight: 600;">
                                    <?= number_format($cost_with_vat, 2) ?> ₾
                                </div>
                                <div style="font-size: 12px; color: #999;">
                                    დღგ-ს გარეშე: <?= number_format($cost_excl_vat, 2) ?> ₾
                                </div>
                                <?php if($quantity > 0 && $unit_cost_with_vat > 0): ?>
                                <div style="font-size: 12px; color: #999;">
                                    ერთეულის ხარჯი: <?= number_format($unit_cost_with_vat, 2) ?> ₾
                                </div>
                                <?php endif; ?>
                            </td>
                            <td style="padding: 10px; text-align: right; border-bottom: 1px solid #f0f0f0;">
                                <div style="font-weight: 700; <?= $profit >= 0 ? 'color: #28a745;' : 'color: #dc3545;' ?>">
                                    <?= number_format($profit, 2) ?> ₾
                                </div>
                                <?php if($quantity > 0): ?>
                                <div style="font-size: 12px; color: #666;">
                                    ერთეულზე: <?= $unit_profit > 0 ? number_format($unit_profit, 2) : number_format($profit / $quantity, 2) ?> ₾
                                </div>
                                <?php endif; ?>
                            </td>
                            <td style="padding: 10px; text-align: center; border-bottom: 1px solid #f0f0f0;">
                                <span style="display: inline-block; padding: 6px 12px; border-radius: 6px; font-size: 13px; font-weight: 700; 
                                    <?= $margin >= 30 ? 'background: #d4edda; color: #155724;' : 
                                       ($margin >= 15 ? 'background: #fff3cd; color: #856404;' : 
                                       ($margin >= 0 ? 'background: #ffeaa7; color: #6c5900;' : 
                                       'background: #f8d7da; color: #721c24;')) ?>">
                                    <?= number_format($margin, 1) ?>%
                                </span>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                    <tfoot style="background: #f8f9fa; font-weight: bold;">
                        <tr>
                            <td colspan="2" style="padding: 15px 10px; text-align: right; border-top: 2px solid #dee2e6;">
                                <strong>ჯამი:</strong>
                            </td>
                            <td style="padding: 15px 10px; text-align: center; border-top: 2px solid #dee2e6;">
                                <?= number_format($total_quantity, 0) ?>
                            </td>
                            <td style="padding: 15px 10px; text-align: right; border-top: 2px solid #dee2e6;">
                                <div style="color: #17a2b8;">
                                    <?= number_format($total_revenue, 2) ?> ₾
                                </div>
                                <div style="font-size: 12px; color: #999;">
                                    დღგ-ს გარეშე: <?= number_format($total_revenue - $total_vat_amount, 2) ?> ₾
                                </div>
                            </td>
                            <td style="padding: 15px 10px; text-align: right; color: #dc3545; border-top: 2px solid #dee2e6;">
                                <div><?= number_format($total_cost_with_vat, 2) ?> ₾</div>
                                <div style="font-size: 12px; color: #999;">
                                    დღგ-ს გარეშე: <?= number_format($total_cost_excl_vat, 2) ?> ₾
                                </div>
                            </td>
                            <td style="padding: 15px 10px; text-align: right; color: #28a745; border-top: 2px solid #dee2e6;">
                                <?= number_format($total_profit, 2) ?> ₾
                            </td>
                            <td style="padding: 15px 10px; text-align: center; border-top: 2px solid #dee2e6;">
                                <span style="display: inline-block; padding: 6px 12px; border-radius: 6px; font-size: 13px; font-weight: 700; 
                                    <?= $avg_margin >= 20 ? 'background: #d4edda; color: #155724;' : 
                                       ($avg_margin >= 0 ? 'background: #fff3cd; color: #856404;' : 
                                       'background: #f8d7da; color: #721c24;') ?>">
                                    <?= number_format($avg_margin, 1) ?>%
                                </span>
                            </td>
                        </tr>
                    </tfoot>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- გამარტივებული jQuery -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
<script>
$(document).ready(function() {
    // დროის შევსება
    $('input[type="date"]').each(function() {
        if (!$(this).val()) {
            $(this).val(new Date().toISOString().split('T')[0]);
        }
    });
});

// CSV ექსპორტის ფუნქცია
function exportToCSV() {
    let csv = [];
    
    // ჰედერი
    csv.push(['თარიღი', 'კერძი', 'რაოდენობა', 'შემოსავალი (დღგ-ით)', 'შემოსავალი (დღგ-ს გარეშე)', 'ღირებულება (დღგ-ით)', 'ღირებულება (დღგ-ს გარეშე)', 'მოგება', 'მარჟა %'].join(','));
    
    // მონაცემები
    <?php foreach($sales as $s): 
        $revenue = (float)($s['total_with_vat'] ?? 0);
        if ($revenue <= 0) {
            $revenue = ((float)($s['net_amount'] ?? 0) + (float)($s['vat_amount'] ?? 0));
        }
        if ($revenue <= 0) {
            $revenue = (float)($s['total_price'] ?? 0);
        }
        
        $vat_amount = (float)($s['vat_amount'] ?? 0);
        $revenue_excl_vat = $revenue - $vat_amount;
        
        $cost_with_vat = (float)($s['cost_with_vat'] ?? 0);
        if ($cost_with_vat <= 0) {
            $cost_with_vat = (float)($s['total_amount'] ?? 0);
        }
        $cost_excl_vat = (float)($s['cost_excluding_vat'] ?? 0);
        
        $profit = (float)($s['profit'] ?? 0);
        if ($profit <= 0 && $revenue > 0) {
            $profit = $revenue - $cost_with_vat;
        }
        
        $margin = (float)($s['margin_percent'] ?? 0);
        if ($margin <= 0 && $revenue > 0 && $profit > 0) {
            $margin = ($profit / $revenue) * 100;
        }
        
        $quantity = (float)($s['quantity'] ?? 0);
    ?>
    csv.push([
        '<?= date('d.m.Y H:i', strtotime($s['sale_date'])) ?>',
        '<?= addslashes($s['dish_name']) ?>',
        '<?= $quantity ?>',
        '<?= $revenue ?>',
        '<?= $revenue_excl_vat ?>',
        '<?= $cost_with_vat ?>',
        '<?= $cost_excl_vat ?>',
        '<?= $profit ?>',
        '<?= $margin ?>'
    ].join(','));
    <?php endforeach; ?>
    
    // ჯამი
    csv.push(['ჯამი', '', 
        '<?= $total_quantity ?>', 
        '<?= $total_revenue ?>',
        '<?= $total_revenue - $total_vat_amount ?>',
        '<?= $total_cost_with_vat ?>',
        '<?= $total_cost_excl_vat ?>',
        '<?= $total_profit ?>', 
        '<?= $avg_margin ?>'
    ].join(','));
    
    let csvContent = csv.join('\n');
    
    // UTF-8 BOM for Excel
    const BOM = "\uFEFF";
    csvContent = BOM + csvContent;
    
    let blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    let link = document.createElement("a");
    let url = URL.createObjectURL(blob);
    
    link.setAttribute("href", url);
    link.setAttribute("download", "გაყიდვების_რეპორტი_<?= $date_from ?>_<?= $date_to ?>.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}

// მარტივი სორტირების ფუნქცია
let sortDirection = {};
function sortTable(columnIndex) {
    const table = document.getElementById('reportsTable');
    const tbody = table.getElementsByTagName('tbody')[0];
    const rows = Array.from(tbody.getElementsByTagName('tr'));
    
    // ინიციალიზაცია ან შებრუნება მიმართულების
    if (typeof sortDirection[columnIndex] === 'undefined') {
        sortDirection[columnIndex] = true; // ზრდადობით დალაგება
    } else {
        sortDirection[columnIndex] = !sortDirection[columnIndex];
    }
    
    const isNumeric = columnIndex === 2 || columnIndex === 3 || columnIndex === 4 || columnIndex === 5 || columnIndex === 6;
    
    rows.sort((a, b) => {
        const aValue = a.cells[columnIndex].textContent.trim();
        const bValue = b.cells[columnIndex].textContent.trim();
        
        let comparison = 0;
        if (isNumeric) {
            // ამოვიღოთ რიცხვები სტრინგიდან
            const aNum = parseFloat(aValue.replace(/[^\d.-]/g, '')) || 0;
            const bNum = parseFloat(bValue.replace(/[^\d.-]/g, '')) || 0;
            comparison = aNum - bNum;
        } else {
            // თარიღების სპეციალური დამუშავება
            if (columnIndex === 0) {
                // თარიღების დამუშავება
                const aDate = new Date(aValue.split('\n')[0].split('.').reverse().join('-'));
                const bDate = new Date(bValue.split('\n')[0].split('.').reverse().join('-'));
                comparison = aDate - bDate;
            } else {
                comparison = aValue.localeCompare(bValue, 'ka');
            }
        }
        
        return sortDirection[columnIndex] ? comparison : -comparison;
    });
    
    // წაშალეთ არსებული რიგები
    while (tbody.firstChild) {
        tbody.removeChild(tbody.firstChild);
    }
    
    // დაამატეთ დალაგებული რიგები
    rows.forEach(row => tbody.appendChild(row));
}
</script>

<style>
.stat-card {
    border: 2px solid;
    border-radius: 10px;
    padding: 20px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.05);
    transition: transform 0.2s, box-shadow 0.2s;
}
.stat-card:hover {
    transform: translateY(-3px);
    box-shadow: 0 6px 15px rgba(0,0,0,0.1);
}

.btn {
    padding: 10px 20px;
    border: none;
    border-radius: 6px;
    cursor: pointer;
    font-weight: 600;
    transition: all 0.2s;
    text-decoration: none;
    display: inline-block;
}
.btn-blue {
    background: #007bff;
    color: white;
}
.btn-blue:hover {
    background: #0056b3;
}
.btn-green {
    background: #28a745;
    color: white;
}
.btn-green:hover {
    background: #1e7e34;
}
.btn-gray {
    background: #6c757d;
    color: white;
}
.btn-gray:hover {
    background: #545b62;
}

table {
    border-collapse: collapse;
    width: 100%;
}

table th {
    background-color: #f8f9fa;
    font-weight: 600;
    text-align: left;
    position: relative;
}

table th:hover {
    background-color: #e9ecef;
}

table tr:hover {
    background-color: #f8f9fa;
}

@media print {
    .filter-bar, .btn, .no-print {
        display: none !important;
    }
    
    .container {
        box-shadow: none !important;
        padding: 0 !important;
    }
    
    table {
        width: 100% !important;
        font-size: 12px !important;
    }
    
    .stat-cards {
        page-break-inside: avoid;
    }
}

/* რესპონსიულობა */
@media (max-width: 768px) {
    .container {
        padding: 15px;
    }
    
    .stat-cards {
        grid-template-columns: 1fr;
    }
    
    .filter-bar form {
        flex-direction: column;
        align-items: flex-start;
        gap: 10px;
    }
    
    .filter-bar form > div {
        width: 100%;
    }
    
    .filter-bar input {
        width: 100%;
    }
    
    table {
        font-size: 12px;
    }
    
    table th, table td {
        padding: 8px 5px;
    }
}

/* სორტირების ინდიკატორი */
table th {
    cursor: pointer;
    user-select: none;
}

table th:hover::after {
    content: ' ⇅';
    opacity: 0.5;
}
</style>

<?php
// ===========================================
// ფუტერის ჩასმა
// ===========================================
include '../includes/footer.php';
// ===========================================
?>