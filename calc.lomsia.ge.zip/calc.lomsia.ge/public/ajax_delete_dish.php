<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once '../includes/functions.php';

// CSRF ტოკენის შემოწმება
if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
    echo json_encode(['status' => 0, 'message' => 'Invalid CSRF token']);
    exit();
}

// ვალიდაცია
if (!isset($_POST['dish_id']) || !is_numeric($_POST['dish_id'])) {
    echo json_encode(['status' => 0, 'message' => 'Invalid dish ID']);
    exit();
}

$dish_id = intval($_POST['dish_id']);

try {
    $stmt = $mysqli->prepare("DELETE FROM dishes WHERE id = ?");
    $stmt->bind_param("i", $dish_id);
    
    if ($stmt->execute()) {
        echo json_encode(['status' => 1, 'message' => 'კერძი წარმატებით წაიშალა']);
    } else {
        echo json_encode(['status' => 0, 'message' => 'კერძის წაშლა ვერ მოხერხდა']);
    }
    
    $stmt->close();
    
} catch (Exception $e) {
    echo json_encode(['status' => 0, 'message' => 'შეცდომა: ' . $e->getMessage()]);
}
?>