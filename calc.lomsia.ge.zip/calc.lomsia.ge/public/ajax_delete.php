<?php
// AJAX ჩანაწერების წაშლის სკრიპტი
require_once __DIR__ . '/../config/db.php';

// დარწმუნდით, რომ სესია მუშაობს
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// მხოლოდ AJAX მოთხოვნებს ვიღებთ
if (!isset($_SERVER['HTTP_X_REQUESTED_WITH']) || strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) !== 'xmlhttprequest') {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'მხოლოდ AJAX მოთხოვნებია დაშვებული']);
    exit();
}

// მხოლოდ POST მეთოდი
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'მხოლოდ POST მეთოდია დაშვებული']);
    exit();
}

// მონაცემების მიღება
$input = json_decode(file_get_contents('php://input'), true);
$action = $input['action'] ?? '';
$ids = $input['ids'] ?? [];
$date_from = $input['date_from'] ?? '';
$date_to = $input['date_to'] ?? '';

$response = ['success' => false, 'message' => 'არასწორი მოთხოვნა'];

try {
    switch ($action) {
        case 'delete_single':
            if (!empty($input['id'])) {
                $id = (int)$input['id'];
                $delete_query = "DELETE FROM sales WHERE id = ?";
                $stmt = $mysqli->prepare($delete_query);
                $stmt->bind_param("i", $id);
                
                if ($stmt->execute()) {
                    $response = [
                        'success' => true, 
                        'message' => 'ჩანაწერი წარმატებით წაიშალა',
                        'deleted_id' => $id
                    ];
                } else {
                    $response = ['success' => false, 'message' => 'ჩანაწერის წაშლა ვერ მოხერხდა: ' . $stmt->error];
                }
            }
            break;
            
        case 'delete_multiple':
            if (!empty($ids) && is_array($ids)) {
                // ვალიდაცია - მხოლოდ რიცხვები
                $valid_ids = array_filter($ids, 'is_numeric');
                if (!empty($valid_ids)) {
                    $placeholders = implode(',', array_fill(0, count($valid_ids), '?'));
                    $delete_query = "DELETE FROM sales WHERE id IN ($placeholders)";
                    $stmt = $mysqli->prepare($delete_query);
                    
                    // Bind parameters
                    $types = str_repeat('i', count($valid_ids));
                    $stmt->bind_param($types, ...$valid_ids);
                    
                    if ($stmt->execute()) {
                        $response = [
                            'success' => true, 
                            'message' => count($valid_ids) . ' ჩანაწერი წარმატებით წაიშალა',
                            'deleted_ids' => $valid_ids
                        ];
                    } else {
                        $response = ['success' => false, 'message' => 'ჩანაწერების წაშლა ვერ მოხერხდა: ' . $stmt->error];
                    }
                }
            }
            break;
            
        case 'delete_all_period':
            if (!empty($date_from) && !empty($date_to)) {
                // ჯერ დავთვალოთ რამდენი ჩანაწერი წაშლება
                $count_query = "SELECT COUNT(*) as total FROM sales WHERE DATE(sale_date) >= ? AND DATE(sale_date) <= ?";
                $count_stmt = $mysqli->prepare($count_query);
                $count_stmt->bind_param("ss", $date_from, $date_to);
                $count_stmt->execute();
                $count_result = $count_stmt->get_result()->fetch_assoc();
                $total_records = $count_result['total'] ?? 0;
                
                if ($total_records > 0) {
                    $delete_query = "DELETE FROM sales WHERE DATE(sale_date) >= ? AND DATE(sale_date) <= ?";
                    $stmt = $mysqli->prepare($delete_query);
                    $stmt->bind_param("ss", $date_from, $date_to);
                    
                    if ($stmt->execute()) {
                        $affected_rows = $stmt->affected_rows;
                        $response = [
                            'success' => true, 
                            'message' => $affected_rows . ' ჩანაწერი წარმატებით წაიშალა არჩეული პერიოდიდან',
                            'deleted_count' => $affected_rows
                        ];
                    } else {
                        $response = ['success' => false, 'message' => 'ჩანაწერების წაშლა ვერ მოხერხდა: ' . $stmt->error];
                    }
                } else {
                    $response = ['success' => false, 'message' => 'მითითებულ პერიოდში არ არის ჩანაწერები წასაშლელად'];
                }
            }
            break;
            
        default:
            $response = ['success' => false, 'message' => 'არასწორი მოქმედება'];
    }
} catch (Exception $e) {
    $response = ['success' => false, 'message' => 'შეცდომა: ' . $e->getMessage()];
}

// JSON პასუხი
header('Content-Type: application/json');
echo json_encode($response);
exit();
?>