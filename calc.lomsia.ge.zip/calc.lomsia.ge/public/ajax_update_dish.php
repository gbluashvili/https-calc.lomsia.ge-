<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['status' => 0, 'message' => 'არასწორი მეთოდი']);
    exit;
}

$id = intval($_POST['id'] ?? 0);
$name = trim($_POST['name'] ?? '');
$sale_price = floatval($_POST['sale_price'] ?? 0);
$menu_id = isset($_POST['menu_id']) && $_POST['menu_id'] !== '' ? intval($_POST['menu_id']) : null;

// ვალიდაცია
if ($id <= 0) {
    echo json_encode(['status' => 0, 'message' => 'არასწორი ID']);
    exit;
}

if (empty($name)) {
    echo json_encode(['status' => 0, 'message' => 'კერძის დასახელება სავალდებულოა']);
    exit;
}

if ($sale_price <= 0) {
    echo json_encode(['status' => 0, 'message' => 'ფასი უნდა იყოს 0-ზე მეტი']);
    exit;
}

// SQL მოთხოვნა
$sql = "UPDATE dishes SET name = ?, sale_price = ?, menu_id = ? WHERE id = ?";
$stmt = $mysqli->prepare($sql);

if ($stmt) {
    $stmt->bind_param("sdii", $name, $sale_price, $menu_id, $id);
    
    if ($stmt->execute()) {
        echo json_encode([
            'status' => 1, 
            'message' => 'კერძი წარმატებით განახლდა'
        ]);
    } else {
        echo json_encode(['status' => 0, 'message' => 'ბაზაში განახლების შეცდომა: ' . $mysqli->error]);
    }
    
    $stmt->close();
} else {
    echo json_encode(['status' => 0, 'message' => 'SQL შეცდომა: ' . $mysqli->error]);
}

$mysqli->close();
?>