<?php
session_start();
require_once __DIR__ . '/../config/db.php';

header('Content-Type: application/json');

// CSRF ვალიდაცია
if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
    echo json_encode(['status' => 0, 'message' => 'Invalid CSRF token']);
    exit;
}

$ingredient_id = intval($_POST['ingredient_id'] ?? 0);

try {
    $stmt = $mysqli->prepare("DELETE FROM dish_calc WHERE id = ?");
    $stmt->bind_param("i", $ingredient_id);
    
    if ($stmt->execute()) {
        echo json_encode(['status' => 1, 'message' => 'Ingredient deleted']);
    } else {
        throw new Exception("Database error: " . $stmt->error);
    }
    
    $stmt->close();
} catch (Exception $e) {
    echo json_encode(['status' => 0, 'message' => $e->getMessage()]);
}