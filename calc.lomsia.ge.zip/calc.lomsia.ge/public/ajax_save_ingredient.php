<?php
require_once __DIR__ . '/../config/db.php';

header('Content-Type: application/json');

if (!isset($_POST['dish_id']) || !isset($_POST['product_id']) || !isset($_POST['quantity'])) {
    echo json_encode(['status' => 0, 'message' => 'არასაკმარისი მონაცემები']);
    exit;
}

$dish_id = intval($_POST['dish_id']);
$product_id = intval($_POST['product_id']);
$quantity = floatval($_POST['quantity']);
$unit = $_POST['unit'] ?? 'კგ';
$yield_coeff = floatval($_POST['yield_coeff'] ?? 1.00);
$has_vat = intval($_POST['has_vat'] ?? 1);

try {
    // შეამოწმე კერძის არსებობა
    $stmt = $pdo->prepare("SELECT id FROM dishes WHERE id = ?");
    $stmt->execute([$dish_id]);
    if (!$stmt->fetch()) {
        echo json_encode(['status' => 0, 'message' => 'კერძი არ მოიძებნა']);
        exit;
    }
    
    // შეამოწმე პროდუქტის არსებობა
    $stmt = $pdo->prepare("SELECT id, name FROM products WHERE id = ?");
    $stmt->execute([$product_id]);
    if (!$stmt->fetch()) {
        echo json_encode(['status' => 0, 'message' => 'პროდუქტი არ მოიძებნა']);
        exit;
    }
    
    // თუ id არის, განაახლე არსებული ჩანაწერი
    if (isset($_POST['id']) && $_POST['id'] > 0) {
        $id = intval($_POST['id']);
        
        $stmt = $pdo->prepare("
            UPDATE dish_calc 
            SET product_id = ?, quantity = ?, unit = ?, yield_coeff = ?
            WHERE id = ? AND dish_id = ?
        ");
        $stmt->execute([$product_id, $quantity, $unit, $yield_coeff, $id, $dish_id]);
        
        echo json_encode(['status' => 1, 'id' => $id, 'message' => 'ინგრედიენტი განახლდა']);
        
    } else {
        // ახალი ჩანაწერის დამატება
        $stmt = $pdo->prepare("
            INSERT INTO dish_calc (dish_id, product_id, quantity, unit, yield_coeff) 
            VALUES (?, ?, ?, ?, ?)
        ");
        $stmt->execute([$dish_id, $product_id, $quantity, $unit, $yield_coeff]);
        
        $id = $pdo->lastInsertId();
        
        echo json_encode(['status' => 1, 'id' => $id, 'message' => 'ინგრედიენტი დაემატა']);
    }
    
} catch (PDOException $e) {
    echo json_encode(['status' => 0, 'message' => 'ბაზის შეცდომა: ' . $e->getMessage()]);
}
?>