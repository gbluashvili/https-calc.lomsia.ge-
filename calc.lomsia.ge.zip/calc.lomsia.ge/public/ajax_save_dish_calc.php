<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../config/db.php';

$dish_id = intval($_POST['dish_id'] ?? 0);
$items = json_decode($_POST['items'] ?? '[]', true);

if ($dish_id <= 0) {
    echo json_encode(['status' => 0, 'message' => 'არასწორი კერძი']);
    exit;
}

// ვალიდაცია - შევამოწმოთ რომ პოსტირებული მონაცემები სწორია
if (!is_array($items)) {
    echo json_encode(['status' => 0, 'message' => 'არასწორი მონაცემები']);
    exit;
}

$mysqli->begin_transaction();
try {
    // ძველი რეცეპტის წაშლა
    $stmt = $mysqli->prepare("DELETE FROM dish_calc WHERE dish_id = ?");
    $stmt->bind_param("i", $dish_id);
    $stmt->execute();
    $stmt->close();

    // ახალი რეცეპტის ჩაწერა (has_vat არ ვინახავთ dish_calc-ში)
    $stmt = $mysqli->prepare("INSERT INTO dish_calc (dish_id, product_id, quantity, unit, yield_coeff) VALUES (?, ?, ?, ?, ?)");
    
    foreach ($items as $item) {
        // ვალიდაცია
        $product_id = intval($item['product_id'] ?? 0);
        $quantity = floatval($item['quantity'] ?? 0);
        $unit = trim($item['unit'] ?? '');
        $yield_coeff = floatval($item['yield_coeff'] ?? 1.0);
        
        if ($product_id <= 0 || $quantity <= 0) {
            throw new Exception("არასწორი მონაცემები ინგრედიენტისთვის: product_id={$product_id}, quantity={$quantity}");
        }
        
        $stmt->bind_param("iidsd", 
            $dish_id, 
            $product_id, 
            $quantity, 
            $unit, 
            $yield_coeff
        );
        $stmt->execute();
    }
    
    $stmt->close();
    
    // დამატებითი ლოგირება დებაგისთვის
    error_log("Dish {$dish_id} calculation saved with " . count($items) . " items");
    
    $mysqli->commit();
    
    echo json_encode([
        'status' => 1, 
        'message' => 'წარმატებით შეინახა',
        'debug' => [
            'dish_id' => $dish_id,
            'items_count' => count($items)
        ]
    ]);
    
} catch (Exception $e) {
    $mysqli->rollback();
    error_log("Error saving dish calc: " . $e->getMessage());
    
    echo json_encode([
        'status' => 0, 
        'message' => 'შეცდომა მონაცემების შენახვისას: ' . $e->getMessage(),
        'error_details' => $e->getMessage()
    ]);
}