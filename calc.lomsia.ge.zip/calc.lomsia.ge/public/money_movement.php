<?php
require_once dirname(__DIR__) . '/includes/auth_check.php';
// money_movement.php
header('Content-Type: text/html; charset=utf-8');

// ============== მონაცემთა ბაზის კონფიგურაცია ==============
require_once __DIR__ . '/../config/db.php';

// ============== MySQLi კავშირის გამოყენება ==============
global $mysqli, $conn;

// ვიყენებთ $conn-ს რომელიც უკვე დაკონფიგურირებულია db.php-ში
$connection = $conn;

// ============== ბაზის ცხრილების შექმნა (თუ არ არსებობს) ==============
function checkAndCreateTables($conn) {
    // შევამოწმოთ არსებობს თუ არა ცხრილები
    $tables = ['money_movement_sheets', 'money_movement_transactions'];
    $created = false;
    
    foreach ($tables as $table) {
        $result = $conn->query("SHOW TABLES LIKE '$table'");
        if ($result->num_rows == 0) {
            $created = true;
            break;
        }
    }
    
    if ($created) {
        // შევქმნათ ცხრილები
        $sql = "
        CREATE TABLE IF NOT EXISTS `money_movement_sheets` (
            `id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
            `name` VARCHAR(50) NOT NULL UNIQUE,
            `title` VARCHAR(200) NOT NULL,
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
        
        CREATE TABLE IF NOT EXISTS `money_movement_transactions` (
            `id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
            `sheet_id` INT NOT NULL,
            `transaction_date` DATE NOT NULL,
            `amount_taken` DECIMAL(10,2) DEFAULT 0.00,
            `amount_spent` DECIMAL(10,2) DEFAULT 0.00,
            `remaining` DECIMAL(10,2) DEFAULT 0.00,
            `products` TEXT,
            `description` TEXT,
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (`sheet_id`) REFERENCES `money_movement_sheets`(`id`) ON DELETE CASCADE,
            INDEX `idx_sheet_date` (`sheet_id`, `transaction_date`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
        ";
        
        try {
            // გავყოთ SQL ბრძანებები
            $sql_commands = explode(';', $sql);
            foreach ($sql_commands as $command) {
                if (trim($command) != '') {
                    $conn->query($command);
                }
            }
            
            // დავამატოთ დეფოლტ ფურცლები
            $result = $conn->query("SELECT COUNT(*) as count FROM money_movement_sheets");
            $row = $result->fetch_assoc();
            
            if ($row['count'] == 0) {
                $stmt = $conn->prepare("INSERT INTO money_movement_sheets (name, title) VALUES (?, ?), (?, ?)");
                $stmt->bind_param("ssss", $name1, $title1, $name2, $title2);
                $name1 = 'main';
                $title1 = 'ფულის მოძრაობა';
                $name2 = 'january_2026';
                $title2 = '01,2026';
                $stmt->execute();
                $stmt->close();
            }
            
            return true;
        } catch (Exception $e) {
            die("Error creating tables: " . $e->getMessage());
        }
    }
    return false;
}

// შევამოწმოთ და შევქმნათ ცხრილები
checkAndCreateTables($connection);

// ============== ფუნქციები ==============
function loadSheets($conn) {
    $sheets = [];
    $result = $conn->query("SELECT * FROM money_movement_sheets ORDER BY id");
    while ($row = $result->fetch_assoc()) {
        $sheets[$row['id']] = $row;
    }
    return $sheets;
}

function loadTransactions($conn, $sheetId) {
    $transactions = [];
    $stmt = $conn->prepare("
        SELECT t.*, s.title as sheet_title 
        FROM money_movement_transactions t
        LEFT JOIN money_movement_sheets s ON t.sheet_id = s.id
        WHERE t.sheet_id = ? 
        ORDER BY t.transaction_date, t.id
    ");
    $stmt->bind_param("i", $sheetId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    while ($row = $result->fetch_assoc()) {
        $transactions[] = $row;
    }
    $stmt->close();
    
    return $transactions;
}

function calculateRemaining($amountTaken, $amountSpent) {
    return $amountTaken - $amountSpent;
}

function getTotals($transactions) {
    $total = [
        'taken' => 0,
        'spent' => 0,
        'remaining' => 0
    ];
    
    foreach ($transactions as $t) {
        $total['taken'] += $t['amount_taken'];
        $total['spent'] += $t['amount_spent'];
        $total['remaining'] += $t['remaining'];
    }
    
    return $total;
}

// ============== ძირითადი ოპერაციები ==============
$sheets = loadSheets($connection);
$message = '';
$currentSheetId = isset($_GET['sheet']) ? intval($_GET['sheet']) : 1;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'add') {
        $sheetId = intval($_POST['sheet_id'] ?? $currentSheetId);
        $date = $_POST['date'] ?? date('Y-m-d');
        $amountTaken = floatval($_POST['amount_taken'] ?? 0);
        $amountSpent = floatval($_POST['amount_spent'] ?? 0);
        $remaining = calculateRemaining($amountTaken, $amountSpent);
        $products = $_POST['products'] ?? '';
        $description = $_POST['description'] ?? '';
        
        try {
            $stmt = $connection->prepare("
                INSERT INTO money_movement_transactions 
                (sheet_id, transaction_date, amount_taken, amount_spent, remaining, products, description) 
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ");
            $stmt->bind_param("isddsss", $sheetId, $date, $amountTaken, $amountSpent, $remaining, $products, $description);
            $stmt->execute();
            $stmt->close();
            
            $message = "✅ ტრანზაქცია წარმატებით დაემატა!";
            $currentSheetId = $sheetId; // განახლებული ფურცლის ჩვენება
        } catch (Exception $e) {
            $message = "❌ შეცდომა: " . $e->getMessage();
        }
    }
    elseif ($action === 'delete') {
        $id = intval($_POST['id'] ?? 0);
        $sheetId = intval($_POST['sheet_id'] ?? $currentSheetId);
        
        if ($id > 0) {
            try {
                $stmt = $connection->prepare("DELETE FROM money_movement_transactions WHERE id = ?");
                $stmt->bind_param("i", $id);
                $stmt->execute();
                $stmt->close();
                $message = "🗑️ ტრანზაქცია წაიშალა!";
                $currentSheetId = $sheetId;
            } catch (Exception $e) {
                $message = "❌ შეცდომა წაშლისას: " . $e->getMessage();
            }
        }
    }
    elseif ($action === 'clear') {
        $sheetId = intval($_POST['sheet_id'] ?? $currentSheetId);
        
        try {
            $stmt = $connection->prepare("DELETE FROM money_movement_transactions WHERE sheet_id = ?");
            $stmt->bind_param("i", $sheetId);
            $stmt->execute();
            $stmt->close();
            $message = "🧹 ფურცელი გასუფთავდა!";
            $currentSheetId = $sheetId;
        } catch (Exception $e) {
            $message = "❌ შეცდომა გასუფთავებისას: " . $e->getMessage();
        }
    }
    elseif ($action === 'add_sheet') {
        $name = $_POST['sheet_name'] ?? '';
        $title = $_POST['sheet_title'] ?? '';
        
        if ($name && $title) {
            try {
                $stmt = $connection->prepare("INSERT INTO money_movement_sheets (name, title) VALUES (?, ?)");
                $stmt->bind_param("ss", $name, $title);
                $stmt->execute();
                $stmt->close();
                $message = "📄 ახალი ფურცელი დაემატა: " . htmlspecialchars($title);
                $sheets = loadSheets($connection); // განაახლეთ ფურცლების სია
            } catch (Exception $e) {
                $message = "❌ შეცდომა ფურცლის დამატებისას: " . $e->getMessage();
            }
        }
    }
}

// მიმდინარე ფურცლის ტრანზაქციები
$transactions = [];
$currentSheet = null;

if (isset($sheets[$currentSheetId])) {
    $currentSheet = $sheets[$currentSheetId];
    $transactions = loadTransactions($connection, $currentSheetId);
}

$totals = getTotals($transactions);
?>

<!DOCTYPE html>
<html lang="ka">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ფულის მოძრაობა -</title>
    <?php 
    include '../includes/header.php';?>
    <style>
        * { font-family: 'DejaVu Sans', Arial, sans-serif; }
        body { background: #f5f5f5; padding: 20px; }
        .container { max-width: 1400px; margin: auto; background: white; padding: 30px; border-radius: 10px; box-shadow: 0 0 20px rgba(0,0,0,0.1); }
        h1, h2 { color: #2c3e50; margin-bottom: 20px; }
        .message { padding: 12px; margin: 15px 0; border-radius: 6px; font-weight: bold; }
        .success { background: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
        .error { background: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }
        
        .sheet-tabs { display: flex; flex-wrap: wrap; margin-bottom: 25px; border-bottom: 3px solid #3498db; }
        .sheet-tab { padding: 12px 24px; cursor: pointer; background: #ecf0f1; margin-right: 5px; margin-bottom: 5px; border-radius: 8px 8px 0 0; border: 1px solid #ddd; border-bottom: none; transition: all 0.3s; }
        .sheet-tab:hover { background: #d6eaf8; }
        .sheet-tab.active { background: #3498db; color: white; font-weight: bold; border-color: #2980b9; }
        
        .sheet-content { display: none; }
        .sheet-content.active { display: block; }
        
        .form-section { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 25px; border-radius: 10px; margin: 25px 0; }
        .form-section h3 { color: white; margin-top: 0; }
        
        .form-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; margin-bottom: 20px; }
        .form-group { display: flex; flex-direction: column; }
        .form-group label { margin-bottom: 8px; font-weight: bold; font-size: 14px; }
        .form-group input, .form-group textarea { padding: 10px; border: 2px solid rgba(255,255,255,0.3); border-radius: 5px; background: rgba(255,255,255,0.9); transition: border-color 0.3s; }
        .form-group input:focus, .form-group textarea:focus { outline: none; border-color: #2ecc71; background: white; }
        .form-group textarea { min-height: 80px; resize: vertical; }
        
        .button-group { display: flex; flex-wrap: wrap; gap: 10px; margin-top: 20px; }
        button, .button { background: #2ecc71; color: white; border: none; padding: 12px 25px; border-radius: 6px; cursor: pointer; font-size: 16px; font-weight: bold; transition: all 0.3s; text-decoration: none; display: inline-block; text-align: center; }
        button:hover, .button:hover { background: #27ae60; transform: translateY(-2px); box-shadow: 0 5px 15px rgba(0,0,0,0.2); }
        .delete-btn { background: #e74c3c; }
        .delete-btn:hover { background: #c0392b; }
        .clear-btn { background: #f39c12; }
        .clear-btn:hover { background: #d68910; }
        .add-sheet-btn { background: #9b59b6; }
        .add-sheet-btn:hover { background: #8e44ad; }
        .export-btn { background: #1abc9c; }
        .export-btn:hover { background: #16a085; }
        
        .data-table { width: 100%; border-collapse: collapse; margin: 25px 0; box-shadow: 0 0 10px rgba(0,0,0,0.1); }
        .data-table th { background: #2c3e50; color: white; padding: 15px; text-align: left; font-weight: bold; }
        .data-table td { padding: 12px 15px; border-bottom: 1px solid #eee; }
        .data-table tr:nth-child(even) { background: #f8f9fa; }
        .data-table tr:hover { background: #e8f4fc; }
        .data-table .actions { display: flex; gap: 8px; }
        .data-table .actions form { margin: 0; }
        .data-table .actions button { padding: 6px 12px; font-size: 13px; }
        
        .totals-bar { background: #34495e; color: white; padding: 20px; border-radius: 8px; margin: 25px 0; display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; }
        .total-item { text-align: center; }
        .total-label { font-size: 14px; opacity: 0.9; margin-bottom: 5px; }
        .total-value { font-size: 24px; font-weight: bold; }
        
        .add-sheet-form { background: #ecf0f1; padding: 20px; border-radius: 8px; margin: 20px 0; }
        .add-sheet-form .form-grid { grid-template-columns: repeat(2, 1fr); }
        
        .instructions { background: #f8f9fa; padding: 20px; border-radius: 8px; margin-top: 30px; border-left: 4px solid #3498db; }
        .instructions h4 { margin-top: 0; }
        .instructions ul { padding-left: 20px; }
        .instructions li { margin-bottom: 10px; line-height: 1.5; }
        
        .alert { padding: 10px; border-radius: 5px; margin: 10px 0; }
        .alert-info { background: #d1ecf1; color: #0c5460; border: 1px solid #bee5eb; }
        
        @media (max-width: 768px) {
            .form-grid { grid-template-columns: 1fr; }
            .sheet-tabs { flex-direction: column; }
            .sheet-tab { width: 100%; margin-right: 0; border-radius: 5px; margin-bottom: 5px; }
            .data-table { font-size: 14px; }
            .data-table th, .data-table td { padding: 8px; }
        }
    </style>
    <script>
        function showSheet(sheetId) {
            // ყველა კონტენტის დამალვა
            document.querySelectorAll('.sheet-content').forEach(el => {
                el.classList.remove('active');
            });
            
            // ყველა ტაბის აქტივობის მოხსნა
            document.querySelectorAll('.sheet-tab').forEach(el => {
                el.classList.remove('active');
            });
            
            // კონკრეტული ფურცლის ჩვენება
            document.getElementById('sheet-' + sheetId).classList.add('active');
            
            // URL-ის განახლება
            history.pushState(null, '', '?sheet=' + sheetId);
            
            // ფორმაში sheet_id-ის დაყენება
            document.querySelectorAll('input[name="sheet_id"]').forEach(input => {
                input.value = sheetId;
            });
        }
        
        function confirmAction(message) {
            return confirm(message);
        }
        
        // ფურცლის ჩვენება URL პარამეტრის მიხედვით
        window.onload = function() {
            const urlParams = new URLSearchParams(window.location.search);
            const sheetParam = urlParams.get('sheet');
            if (sheetParam) {
                showSheet(sheetParam);
            }
        };
        
        // ისტორიის მენეჯმენტი
        window.onpopstate = function() {
            const urlParams = new URLSearchParams(window.location.search);
            const sheetParam = urlParams.get('sheet');
            if (sheetParam) {
                showSheet(sheetParam);
            }
        };
    </script>
</head>
<body>
    <div class="container">
        <h1>💰 ფულის მოძრაობის სისტემა </h1>
        
        <?php if ($message): ?>
            <div class="message <?php echo strpos($message, '❌') !== false ? 'error' : 'success'; ?>">
                <?php echo $message; ?>
            </div>
        <?php endif; ?>
        
                <!-- ფურცლების ტაბები -->
        <div class="sheet-tabs">
            <?php foreach ($sheets as $sheet): ?>
                <div class="sheet-tab <?php echo $sheet['id'] == $currentSheetId ? 'active' : ''; ?>" 
                     onclick="showSheet(<?php echo $sheet['id']; ?>)">
                    <?php echo htmlspecialchars($sheet['title']); ?>
                </div>
            <?php endforeach; ?>
        </div>
        
        <!-- ფურცლების კონტენტი -->
        <?php foreach ($sheets as $sheet): ?>
        <div id="sheet-<?php echo $sheet['id']; ?>" class="sheet-content <?php echo $sheet['id'] == $currentSheetId ? 'active' : ''; ?>">
            <h2><?php echo htmlspecialchars($sheet['title']); ?></h2>
            
            <!-- ახალი ტრანზაქციის ფორმა -->
            <div class="form-section">
                <h3>➕ ახალი ტრანზაქციის დამატება</h3>
                <form method="POST" id="addForm-<?php echo $sheet['id']; ?>">
                    <input type="hidden" name="action" value="add">
                    <input type="hidden" name="sheet_id" value="<?php echo $sheet['id']; ?>">
                    
                    <div class="form-grid">
                        <div class="form-group">
                            <label for="date-<?php echo $sheet['id']; ?>">📅 თარიღი:</label>
                            <input type="date" id="date-<?php echo $sheet['id']; ?>" name="date" value="<?php echo date('Y-m-d'); ?>" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="amount_taken-<?php echo $sheet['id']; ?>">💰 აღებული თანხა (₾):</label>
                            <input type="number" step="0.01" id="amount_taken-<?php echo $sheet['id']; ?>" name="amount_taken" placeholder="0.00" min="0">
                        </div>
                        
                        <div class="form-group">
                            <label for="amount_spent-<?php echo $sheet['id']; ?>">💸 დახარჯული თანხა (₾):</label>
                            <input type="number" step="0.01" id="amount_spent-<?php echo $sheet['id']; ?>" name="amount_spent" placeholder="0.00" min="0">
                        </div>
                    </div>
                    
                    <div class="form-grid">
                        <div class="form-group">
                            <label for="products-<?php echo $sheet['id']; ?>">🛒 შეძენილი პროდუქცია:</label>
                            <textarea id="products-<?php echo $sheet['id']; ?>" name="products" placeholder="მაგ: პური იფქლი 57.2ლ"></textarea>
                        </div>
                        
                        <div class="form-group">
                            <label for="description-<?php echo $sheet['id']; ?>">📝 დამატებითი აღწერა:</label>
                            <textarea id="description-<?php echo $sheet['id']; ?>" name="description" placeholder="მაგ: ჩეკი #123, მიმწოდებელი: იფქლი"></textarea>
                        </div>
                    </div>
                    
                    <div class="button-group">
                        <button type="submit">💾 ტრანზაქციის დამატება</button>
                        <button type="button" onclick="document.getElementById('addForm-<?php echo $sheet['id']; ?>').reset();">🔄 ფორმის გასუფთავება</button>
                    </div>
                </form>
            </div>
            
            <!-- ტრანზაქციების ცხრილი -->
            <?php 
            $sheetTransactions = loadTransactions($connection, $sheet['id']);
            $sheetTotals = getTotals($sheetTransactions);
            ?>
            
            <?php if (count($sheetTransactions) > 0): ?>
            <div style="overflow-x: auto;">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>თარიღი</th>
                            <th>აღებული თანხა (₾)</th>
                            <th>დახარჯული თანხა (₾)</th>
                            <th>დარჩენილი თანხა (₾)</th>
                            <th>შეძენილი პროდუქცია</th>
                            <th>აღწერა</th>
                            <th>მოქმედებები</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($sheetTransactions as $index => $transaction): ?>
                        <tr>
                            <td><?php echo $index + 1; ?></td>
                            <td><?php echo htmlspecialchars($transaction['transaction_date']); ?></td>
                            <td style="color: #27ae60; font-weight: bold;">
                                <?php echo number_format($transaction['amount_taken'], 2); ?> ₾
                            </td>
                            <td style="color: #e74c3c; font-weight: bold;">
                                <?php echo number_format($transaction['amount_spent'], 2); ?> ₾
                            </td>
                            <td style="color: #3498db; font-weight: bold;">
                                <?php echo number_format($transaction['remaining'], 2); ?> ₾
                            </td>
                            <td><?php echo nl2br(htmlspecialchars($transaction['products'])); ?></td>
                            <td><?php echo nl2br(htmlspecialchars($transaction['description'])); ?></td>
                            <td class="actions">
                                <form method="POST" style="display: inline;" onsubmit="return confirmAction('დარწმუნებული ხარ რომ გინდა ამ ტრანზაქციის წაშლა?');">
                                    <input type="hidden" name="action" value="delete">
                                    <input type="hidden" name="id" value="<?php echo $transaction['id']; ?>">
                                    <input type="hidden" name="sheet_id" value="<?php echo $sheet['id']; ?>">
                                    <button type="submit" class="delete-btn">🗑️ წაშლა</button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                    <tfoot>
                        <tr style="background: #2c3e50; color: white; font-weight: bold;">
                            <td colspan="2">ჯამი:</td>
                            <td><?php echo number_format($sheetTotals['taken'], 2); ?> ₾</td>
                            <td><?php echo number_format($sheetTotals['spent'], 2); ?> ₾</td>
                            <td><?php echo number_format($sheetTotals['remaining'], 2); ?> ₾</td>
                            <td colspan="3">
                                <form method="POST" style="display: inline;" onsubmit="return confirmAction('დარწმუნებული ხარ რომ გინდა მთელი ფურცლის გასუფთავება? ეს მოქმედება შეუქცევადია!');">
                                    <input type="hidden" name="action" value="clear">
                                    <input type="hidden" name="sheet_id" value="<?php echo $sheet['id']; ?>">
                                    <button type="submit" class="clear-btn">🧹 ფურცლის გასუფთავება</button>
                                </form>
                            </td>
                        </tr>
                    </tfoot>
                </table>
            </div>
            
            <!-- ჯამური სტატისტიკა -->
            <div class="totals-bar">
                <div class="total-item">
                    <div class="total-label">მთლიანი აღებული:</div>
                    <div class="total-value"><?php echo number_format($sheetTotals['taken'], 2); ?> ₾</div>
                </div>
                <div class="total-item">
                    <div class="total-label">მთლიანი დახარჯული:</div>
                    <div class="total-value"><?php echo number_format($sheetTotals['spent'], 2); ?> ₾</div>
                </div>
                <div class="total-item">
                    <div class="total-label">მთლიანი დარჩენილი:</div>
                    <div class="total-value"><?php echo number_format($sheetTotals['remaining'], 2); ?> ₾</div>
                </div>
                <div class="total-item">
                    <div class="total-label">ტრანზაქციების რაოდენობა:</div>
                    <div class="total-value"><?php echo count($sheetTransactions); ?></div>
                </div>
            </div>
            
            <?php else: ?>
            <div style="text-align: center; padding: 40px; background: #f8f9fa; border-radius: 8px; margin: 20px 0;">
                <h3 style="color: #7f8c8d;">📭 ამ ფურცელზე ტრანზაქციები ჯერ არ არის</h3>
                <p>გთხოვთ, დაამატეთ პირველი ტრანზაქცია ზემოთ მოცემული ფორმის გამოყენებით.</p>
            </div>
            <?php endif; ?>
        </div>
        <?php endforeach; ?>
        </body>
</html>