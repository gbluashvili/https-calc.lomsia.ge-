<?php
// cleanup_connections.php - MySQL კავშირების დასაკლირებლად

require_once __DIR__ . '/../config/db.php';

// ვამოწმებთ ყველა აქტიური პროცესი
$result = $mysqli->query("SHOW PROCESSLIST");
$connections = [];

echo "<h3>Active MySQL Connections:</h3>";
echo "<table border='1' cellpadding='5'>";
echo "<tr><th>ID</th><th>User</th><th>Host</th><th>DB</th><th>Command</th><th>Time</th><th>State</th><th>Info</th></tr>";

while ($row = $result->fetch_assoc()) {
    echo "<tr>";
    echo "<td>{$row['Id']}</td>";
    echo "<td>{$row['User']}</td>";
    echo "<td>{$row['Host']}</td>";
    echo "<td>{$row['db']}</td>";
    echo "<td>{$row['Command']}</td>";
    echo "<td>{$row['Time']}</td>";
    echo "<td>{$row['State']}</td>";
    echo "<td>" . htmlspecialchars(substr($row['Info'] ?? '', 0, 100)) . "</td>";
    echo "</tr>";
    
    $connections[] = $row;
}

echo "</table>";

// კავშირების რაოდენობა
echo "<p>Total connections: " . count($connections) . "</p>";

// გაასუფთავეთ ძველი კავშირები
$kill_result = $mysqli->query("KILL CONNECTION " . $mysqli->thread_id);
echo "<p>Current connection killed: " . ($kill_result ? "Yes" : "No") . "</p>";

$mysqli->close();
?>