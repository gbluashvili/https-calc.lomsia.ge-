<?php
// /home/mvpuufsr/calc/calc.lomsia.ge/admin/login.php

// დეფოლტი შეცდომების ჩვენების ჩართვა განმავითარებისთვის
error_reporting(E_ALL);
ini_set('display_errors', 1);

// დაწყებული სესია
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ბაზასთან დაკავშირების კონფიგურაცია
require_once __DIR__ . '/../config/db.php';

// ცვლადები შეცდომებისთვის
$error = '';
$username = '';
$error_details = '';

// თუ მომხმარებელი უკვე ავტორიზებულია, გადამისამართება
if (isset($_SESSION['user_id'])) {
    if (isset($_SESSION['redirect_after_login'])) {
        $redirect = $_SESSION['redirect_after_login'];
        unset($_SESSION['redirect_after_login']);
        header("Location: $redirect");
        exit();
    } else {
        header("Location: ../public/index.php");
        exit();
    }
}

// ფორმის გაგზავნის შემოწმება
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // ველების ვალიდაცია
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $redirect = $_POST['redirect'] ?? '../public/index.php';
    
    // ველების შევსების შემოწმება
    if (empty($username) || empty($password)) {
        $error = 'empty';
    } else {
        try {
            // გამოვიყენოთ არსებული mysqli კავშირი config/db.php-დან
            global $conn;
            
            // შევამოწმოთ კავშირი
            if (!$conn || $conn->connect_error) {
                throw new Exception("ბაზასთან დაკავშირების შეცდომა");
            }
            
            // მომხმარებლის ძიება მონაცემთა ბაზაში
            $sql = "SELECT * FROM users WHERE (username = ? OR email = ?) AND is_active = 1";
            $stmt = $conn->prepare($sql);
            
            if (!$stmt) {
                throw new Exception("SQL შეცდომა: " . $conn->error);
            }
            
            $stmt->bind_param("ss", $username, $username);
            $stmt->execute();
            $result = $stmt->get_result();
            $user = $result->fetch_assoc();
            
            if ($user) {
                // შევამოწმოთ არის თუ არა ანგარიში დროებით დაბლოკილი
                if ($user['lock_until'] && strtotime($user['lock_until']) > time()) {
                    $error = 'locked';
                    $error_details = 'თქვენი ანგარიში დროებით დაბლოკილია. სცადეთ მოგვიანებით.';
                } else {
                    // პაროლის შემოწმება
                    if (password_verify($password, $user['password_hash'])) {
                        // წარმატებული ავტორიზაცია - განვაახლოთ ბაზა
                        $update_sql = "UPDATE users SET 
                                      last_login = NOW(),
                                      failed_login_attempts = 0,
                                      lock_until = NULL
                                      WHERE id = ?";
                        $update_stmt = $conn->prepare($update_sql);
                        $update_stmt->bind_param("i", $user['id']);
                        $update_stmt->execute();
                        
                        // სესიის ცვლადების დაყენება
                        $_SESSION['user_id'] = $user['id'];
                        $_SESSION['username'] = $user['username'];
                        $_SESSION['full_name'] = $user['full_name'];
                        $_SESSION['email'] = $user['email'];
                        $_SESSION['phone'] = $user['phone'];
                        $_SESSION['user_role'] = $user['role'];
                        $_SESSION['role_id'] = $user['role_id'];
                        $_SESSION['is_active'] = $user['is_active'];
                        $_SESSION['login_time'] = time();
                        
                        // გადამისამართება
                        if (!empty($redirect) && $redirect != 'admin/login.php') {
                            header("Location: $redirect");
                            exit();
                        } elseif (isset($_SESSION['redirect_after_login'])) {
                            $redirect_url = $_SESSION['redirect_after_login'];
                            unset($_SESSION['redirect_after_login']);
                            header("Location: $redirect_url");
                            exit();
                        } else {
                            header("Location: ../public/index.php");
                            exit();
                        }
                    } else {
                        // არასწორი პაროლი - გავზარდოთ შეცდომების რაოდენობა
                        $failed_attempts = $user['failed_login_attempts'] + 1;
                        $lock_until = null;
                        
                        // თუ 5-ზე მეტი შეცდომაა, დავბლოკოთ 15 წუთით
                        if ($failed_attempts >= 5) {
                            $lock_until = date('Y-m-d H:i:s', time() + (15 * 60)); // 15 წუთი
                        }
                        
                        $update_sql = "UPDATE users SET 
                                      failed_login_attempts = ?,
                                      lock_until = ?
                                      WHERE id = ?";
                        $update_stmt = $conn->prepare($update_sql);
                        $update_stmt->bind_param("isi", $failed_attempts, $lock_until, $user['id']);
                        $update_stmt->execute();
                        
                        if ($lock_until) {
                            $error = 'locked';
                            $error_details = 'ბევრი უწარმატებელი მცდელობა. ანგარიში დაბლოკილია 15 წუთის განმავლობაში.';
                        } else {
                            $remaining_attempts = 5 - $failed_attempts;
                            $error = 'invalid';
                            $error_details = "არასწორი პაროლი. დარჩენილი მცდელობები: $remaining_attempts";
                        }
                    }
                }
            } else {
                // მომხმარებელი არ მოიძებნა
                $error = 'invalid';
                $error_details = 'მომხმარებელი არ მოიძებნა ან ანგარიში არააქტიურია';
            }
            
            // დაკავშირების დახურვა
            if (isset($stmt)) $stmt->close();
            
        } catch (Exception $e) {
            // დაფიქსირდა შეცდომა ბაზასთან დაკავშირებისას
            $error = 'database';
            $error_details = 'ბაზასთან დაკავშირების შეცდომა. გთხოვთ დაუკავშირდეთ ადმინისტრატორს.';
            
            // შეცდომის ლოგირება
            error_log("Database Connection Error in login.php: " . $e->getMessage());
            
            // დემო მონაცემები განვითარებისთვის
            if ($username === 'demo' && $password === 'demo123') {
                $_SESSION['user_id'] = 999;
                $_SESSION['username'] = 'demo';
                $_SESSION['full_name'] = 'Demo User';
                $_SESSION['email'] = 'demo@example.com';
                $_SESSION['user_role'] = 'admin';
                $_SESSION['login_time'] = time();
                
                header("Location: ../public/index.php");
                exit();
            }
        }
    }
}

// თუ არის GET პარამეტრები შეცდომის შესახებ
if (isset($_GET['error'])) {
    $error = $_GET['error'];
    if ($error == 'session_expired') {
        $error_details = 'თქვენი სესია ვადაგასულია. გთხოვთ გაიაროთ ავტორიზაცია ხელახლა.';
    }
}
?>
<!DOCTYPE html>
<html lang="ka">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ავტორიზაცია - Restaurant CMS</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            padding: 20px;
        }
        
        .login-container {
            width: 100%;
            max-width: 450px;
        }
        
        .login-box {
            background: rgba(255, 255, 255, 0.98);
            border-radius: 20px;
            padding: 40px;
            box-shadow: 0 25px 50px rgba(0, 0, 0, 0.3);
            animation: slideIn 0.5s ease;
            border: 1px solid rgba(255, 255, 255, 0.2);
        }
        
        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateY(-30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .logo {
            text-align: center;
            margin-bottom: 30px;
        }
        
        .logo h1 {
            color: #4c51bf;
            font-size: 2.2rem;
            margin-bottom: 10px;
        }
        
        .logo p {
            color: #718096;
            font-size: 1.1rem;
        }
        
        .form-group {
            margin-bottom: 25px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #2d3748;
            font-weight: 600;
            font-size: 0.95rem;
        }
        
        .form-control {
            width: 100%;
            padding: 14px 18px;
            border: 2px solid #e2e8f0;
            border-radius: 10px;
            font-size: 1rem;
            transition: all 0.3s;
            background: #f7fafc;
        }
        
        .form-control:focus {
            outline: none;
            border-color: #4c51bf;
            background: white;
            box-shadow: 0 0 0 3px rgba(76, 81, 191, 0.1);
        }
        
        .btn-login {
            width: 100%;
            background: linear-gradient(to right, #4c51bf, #2d3748);
            color: white;
            border: none;
            padding: 16px;
            border-radius: 10px;
            font-size: 1.1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            margin-top: 10px;
        }
        
        .btn-login:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(76, 81, 191, 0.3);
        }
        
        .btn-login:disabled {
            opacity: 0.6;
            cursor: not-allowed;
        }
        
        .alert {
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 25px;
            font-weight: 500;
            text-align: center;
        }
        
        .alert-error {
            background: #fed7d7;
            color: #742a2a;
            border: 1px solid #fc8181;
        }
        
        .alert-warning {
            background: #feebc8;
            color: #744210;
            border: 1px solid #f6ad55;
        }
        
        .alert-success {
            background: #c6f6d5;
            color: #22543d;
            border: 1px solid #9ae6b4;
        }
        
        .alert-info {
            background: #bee3f8;
            color: #2c5282;
            border: 1px solid #63b3ed;
        }
        
        .password-container {
            position: relative;
        }
        
        .toggle-password {
            position: absolute;
            right: 15px;
            top: 50%;
            transform: translateY(-50%);
            background: none;
            border: none;
            color: #718096;
            cursor: pointer;
            font-size: 1.2rem;
            padding: 5px;
        }
        
        .debug-info {
            background: #2d3748;
            color: #e2e8f0;
            padding: 15px;
            border-radius: 10px;
            margin-top: 20px;
            font-size: 12px;
            font-family: monospace;
            display: none; /* დამალეთ პროდაქციაში */
        }
        
        .debug-toggle {
            text-align: center;
            margin-top: 10px;
        }
        
        .debug-toggle button {
            background: #718096;
            color: white;
            border: none;
            padding: 5px 10px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 11px;
        }
        
        .login-footer {
            text-align: center;
            margin-top: 25px;
            padding-top: 20px;
            border-top: 1px solid #e2e8f0;
            color: #718096;
            font-size: 0.9rem;
        }
        
        .demo-note {
            background: #e2e8f0;
            color: #4a5568;
            padding: 10px;
            border-radius: 8px;
            margin-top: 15px;
            font-size: 13px;
            text-align: center;
        }
        
        .db-connection-test {
            margin-top: 20px;
            padding: 15px;
            background: #f7fafc;
            border-radius: 10px;
            border: 1px solid #e2e8f0;
        }
        
        .db-connection-test h4 {
            margin-bottom: 10px;
            color: #4a5568;
        }
        
        @media (max-width: 480px) {
            .login-box {
                padding: 30px 25px;
            }
            
            .logo h1 {
                font-size: 1.8rem;
            }
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-box">
            <div class="logo">
                <h1>Restaurant CMS</h1>
                <p>გთხოვთ შეხვიდეთ სისტემაში</p>
            </div>
            
            <?php
            // შეცდომის შეტყობინების ჩვენება
            if ($error) {
                $error_messages = [
                    'invalid' => '❌ არასწორი მომხმარებელი ან პაროლი',
                    'empty' => '⚠️ გთხოვთ შეავსოთ ყველა ველი',
                    'locked' => '🔒 ანგარიში დროებით დაბლოკილია',
                    'database' => '⚙️ ბაზასთან დაკავშირების შეცდომა',
                    'system' => '🛠️ სისტემური შეცდომა',
                    'session_expired' => '⏰ სესიის ვადა გაუვიდა'
                ];
                
                $alert_class = 'alert-error';
                if ($error == 'locked') $alert_class = 'alert-warning';
                if ($error == 'session_expired') $alert_class = 'alert-warning';
                
                echo '<div class="alert ' . $alert_class . '">';
                if (isset($error_messages[$error])) {
                    echo htmlspecialchars($error_messages[$error]);
                } else {
                    echo 'დაფიქსირდა შეცდომა';
                }
                
                if ($error_details) {
                    echo '<br><small>' . htmlspecialchars($error_details) . '</small>';
                }
                echo '</div>';
            }
            
            // წარმატებული გამოსვლის შეტყობინება
            if (isset($_GET['logout'])) {
                echo '<div class="alert-success">✅ წარმატებით გამოხვედით სისტემიდან.</div>';
            }
            ?>
            
            <form method="POST" action="" id="loginForm" onsubmit="return validateForm()">
                <input type="hidden" name="redirect" value="<?php echo htmlspecialchars($_GET['redirect'] ?? ($_SERVER['REQUEST_URI'] ?? '../public/index.php')); ?>">
                
                <div class="form-group">
                    <label for="username">მომხმარებლის სახელი ან ელ-ფოსტა</label>
                    <input type="text" id="username" name="username" class="form-control" 
                           value="<?php echo htmlspecialchars($username); ?>" required autofocus
                           placeholder="შეიყვანეთ მომხმარებელი ან ელ-ფოსტა">
                </div>
                
                <div class="form-group">
                    <label for="password">პაროლი</label>
                    <div class="password-container">
                        <input type="password" id="password" name="password" class="form-control" required
                               placeholder="შეიყვანეთ პაროლი">
                        <button type="button" class="toggle-password" onclick="togglePasswordVisibility()">
                            👁️
                        </button>
                    </div>
                </div>
                
                <button type="submit" class="btn-login" id="submitBtn">შესვლა</button>
            </form>
            
            <div class="demo-note">
                <p><strong>ტესტირებისთვის:</strong> სცადეთ მომხმარებელი: <strong>IT</strong></p>
                <p>ბაზაში არსებული მომხმარებლის პაროლით</p>
            </div>
            
            <div class="db-connection-test">
                <h4>დაკავშირების ინფორმაცია:</h4>
                <p>Host: <?php echo isset($DB_HOST) ? $DB_HOST : 'Not defined'; ?></p>
                <p>Database: <?php echo isset($DB_NAME) ? $DB_NAME : 'Not defined'; ?></p>
                <p>User: <?php echo isset($DB_USER) ? $DB_USER : 'Not defined'; ?></p>
                <p>Connection Status: <?php echo isset($conn) && !$conn->connect_error ? 'Connected' : 'Not connected'; ?></p>
            </div>
            
            <div class="debug-toggle">
                <button onclick="toggleDebug()">დებაგის ინფორმაცია</button>
            </div>
            
            <div class="debug-info" id="debugInfo">
                <strong>სერვერის ინფორმაცია:</strong><br>
                PHP Version: <?php echo phpversion(); ?><br>
                Session Status: <?php echo session_status(); ?><br>
                POST Data: <?php echo json_encode($_POST); ?><br>
                GET Data: <?php echo json_encode($_GET); ?><br>
                Error: <?php echo $error; ?><br>
                Error Details: <?php echo $error_details; ?><br>
                Username from POST: <?php echo htmlspecialchars($username ?? ''); ?>
            </div>
            
            <div class="login-footer">
                © Restaurant CMS | განვითარების რეჟიმი
            </div>
        </div>
    </div>
    
    <script>
        // პაროლის ხილვადობის ჩამრთველი
        function togglePasswordVisibility() {
            const passwordInput = document.getElementById('password');
            const toggleButton = document.querySelector('.toggle-password');
            
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                toggleButton.textContent = '🙈';
            } else {
                passwordInput.type = 'password';
                toggleButton.textContent = '👁️';
            }
        }
        
        // დებაგის ინფორმაციის ჩვენება/დამალვა
        function toggleDebug() {
            const debugInfo = document.getElementById('debugInfo');
            if (debugInfo.style.display === 'none' || debugInfo.style.display === '') {
                debugInfo.style.display = 'block';
            } else {
                debugInfo.style.display = 'none';
            }
        }
        
        // ფორმის ვალიდაცია
        function validateForm() {
            const username = document.getElementById('username').value.trim();
            const password = document.getElementById('password').value;
            const submitBtn = document.getElementById('submitBtn');
            
            if (!username || !password) {
                alert('გთხოვთ შეავსოთ ყველა ველი');
                return false;
            }
            
            // დისეიბლი გახადე ღილაკი ფორმის გაგზავნის დროს
            submitBtn.disabled = true;
            submitBtn.innerHTML = 'მიმდინარეობს შესვლა...';
            
            return true;
        }
        
        // Enter ღილაკის მხარდაჭერა
        document.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                const focused = document.activeElement;
                if (focused.tagName === 'INPUT' && focused.type !== 'button') {
                    validateForm() && document.getElementById('loginForm').submit();
                }
            }
        });
        
        // ფოკუსი მომხმარებლის ველზე
        window.onload = function() {
            document.getElementById('username').focus();
            
            // თუ არის შეცდომა, ვაჩვენოთ დებაგი
            <?php if ($error) { ?>
                document.getElementById('debugInfo').style.display = 'block';
            <?php } ?>
        };
        
        // ავტომატური პაროლის ჩვენების გამორთვა
        let passwordVisible = false;
        function autoHidePassword() {
            if (passwordVisible) {
                const passwordInput = document.getElementById('password');
                if (passwordInput && passwordInput.type === 'text') {
                    passwordInput.type = 'password';
                    const toggleButton = document.querySelector('.toggle-password');
                    if (toggleButton) {
                        toggleButton.textContent = '👁️';
                        passwordVisible = false;
                    }
                }
            }
        }
        
        // მონიტორინგი პაროლის ველისთვის
        document.getElementById('password')?.addEventListener('input', function() {
            if (this.type === 'text') {
                passwordVisible = true;
                // გამორთე ავტომატური დამალვა 10 წამში
                setTimeout(autoHidePassword, 10000);
            }
        });
    </script>
    
    <?php
    // დამატებითი დებაგინგი
    if (isset($_POST['username'])) {
        error_log("Login attempt for user: " . $_POST['username']);
    }
    ?>
</body>
</html>