<?php
require_once __DIR__ . '/../config/db.php';

header('Content-Type: application/json');

if (!$mysqli) {
    die(json_encode(['success' => false, 'message' => 'ბაზასთან დაკავშირება ვერ მოხერხდა']));
}

// მონაცემების მიღება
$product_id = intval($_POST['product_id'] ?? 0);
$quantity = floatval($_POST['quantity'] ?? 0);
$total_amount = floatval($_POST['total_amount'] ?? 0);
$supplier = trim($_POST['supplier'] ?? '');
$notes = trim($_POST['notes'] ?? '');
$vat = isset($_POST['vat']) ? intval($_POST['vat']) : 0;

if ($product_id <= 0) {
    echo json_encode(['success' => false, 'message' => 'არასწორი პროდუქტი']);
    exit;
}

if ($quantity <= 0) {
    echo json_encode(['success' => false, 'message' => 'არასწორი რაოდენობა']);
    exit;
}

if ($total_amount <= 0) {
    echo json_encode(['success' => false, 'message' => 'არასწორი ფასი']);
    exit;
}

try {
    // ტრანზაქციის დაწყება
    $mysqli->begin_transaction();

    // 1. პროდუქტის ნაშთის განახლება
    $stmt1 = $mysqli->prepare("UPDATE products SET quantity = quantity + ? WHERE id = ?");
    $stmt1->bind_param("di", $quantity, $product_id);
    $stmt1->execute();
    
    if ($stmt1->affected_rows <= 0) {
        throw new Exception("პროდუქტი ვერ მოიძებნა");
    }
    $stmt1->close();

    // 2. მიღების ისტორიაში ჩაწერა
    $unit_price = $total_amount / $quantity;
    $vat_rate = $vat ? 18 : 0;
    $vat_amount = $vat ? ($total_amount * 0.18) : 0;
    
    $stmt2 = $mysqli->prepare("INSERT INTO purchase_history (product_id, quantity, unit_price, total_amount, supplier, notes, vat_rate, vat_amount, purchase_date) VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())");
    $stmt2->bind_param("idddssdd", $product_id, $quantity, $unit_price, $total_amount, $supplier, $notes, $vat_rate, $vat_amount);
    $stmt2->execute();
    $stmt2->close();

    // 3. VAT სტატუსის განახლება პროდუქტში
    if ($vat) {
        $stmt3 = $mysqli->prepare("UPDATE products SET vat_status = 'დღგ-თი', vat_rate = ? WHERE id = ?");
        $stmt3->bind_param("di", $vat_rate, $product_id);
        $stmt3->execute();
        $stmt3->close();
    }

    $mysqli->commit();
    echo json_encode(['success' => true, 'message' => 'მიღება წარმატებით დარეგისტრირდა']);
    
} catch (Exception $e) {
    $mysqli->rollback();
    echo json_encode(['success' => false, 'message' => 'შეცდომა: ' . $e->getMessage()]);
}
?>