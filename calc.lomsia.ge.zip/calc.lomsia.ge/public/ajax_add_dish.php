<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['status' => 0, 'message' => 'არასწორი მეთოდი']);
    exit;
}

$name = trim($_POST['name'] ?? '');
$sale_price = floatval($_POST['sale_price'] ?? 0);
$menu_id = isset($_POST['menu_id']) && $_POST['menu_id'] !== '' ? intval($_POST['menu_id']) : null;

// ვალიდაცია
if (empty($name)) {
    echo json_encode(['status' => 0, 'message' => 'კერძის დასახელება სავალდებულოა']);
    exit;
}

if ($sale_price <= 0) {
    echo json_encode(['status' => 0, 'message' => 'ფასი უნდა იყოს 0-ზე მეტი']);
    exit;
}

$sql = "INSERT INTO dishes (name, sale_price, menu_id, created_at) VALUES (?, ?, ?, NOW())";
$stmt = $mysqli->prepare($sql);

if ($stmt) {
    $stmt->bind_param("sdi", $name, $sale_price, $menu_id);
    
    if ($stmt->execute()) {
        echo json_encode([
            'status' => 1, 
            'message' => 'კერძი წარმატებით დაემატა',
            'id' => $mysqli->insert_id
        ]);
    } else {
        echo json_encode(['status' => 0, 'message' => 'ბაზაში შენახვის შეცდომა: ' . $mysqli->error]);
    }
    
    $stmt->close();
} else {
    echo json_encode(['status' => 0, 'message' => 'SQL შეცდომა: ' . $mysqli->error]);
}

$mysqli->close();
?>
