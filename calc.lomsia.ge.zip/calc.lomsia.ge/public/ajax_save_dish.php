<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once '../includes/functions.php';

// დროებითი: გამორთეთ CSRF
// if (!isset($_POST['csrf_token']) || !isset($_SESSION['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
//     echo json_encode(['status' => 0, 'message' => 'Invalid CSRF token']);
//     exit();
// }

// დებაგინგი: ნახეთ რა მონაცემები მოდის
error_log("POST data received: " . print_r($_POST, true));

// ვალიდაცია
if (!isset($_POST['menu_id']) || empty($_POST['menu_id'])) {
    echo json_encode(['status' => 0, 'message' => 'Menu ID არ არის მითითებული']);
    exit();
}

if (!isset($_POST['name']) || empty(trim($_POST['name']))) {
    echo json_encode(['status' => 0, 'message' => 'კერძის სახელი არ არის მითითებული']);
    exit();
}

if (!isset($_POST['sale_price']) || !is_numeric($_POST['sale_price'])) {
    echo json_encode(['status' => 0, 'message' => 'არასწორი ფასი']);
    exit();
}

$menu_id = intval($_POST['menu_id']);
$name = trim($_POST['name']);
$sale_price = floatval($_POST['sale_price']);
$active = isset($_POST['active']) ? intval($_POST['active']) : 1;
$enable_vat = isset($_POST['enable_vat']) ? intval($_POST['enable_vat']) : 1;
$is_edit_mode = isset($_POST['edit_mode']) ? intval($_POST['edit_mode']) : 0;
$original_menu_id = isset($_POST['original_id']) ? intval($_POST['original_id']) : 0;
$dish_id = isset($_POST['dish_id']) ? intval($_POST['dish_id']) : 0;

// დებაგინგი
error_log("Parsed data: edit_mode=$is_edit_mode, dish_id=$dish_id, original_id=$original_menu_id");

try {
    $mysqli->begin_transaction();
    
    // თუ რედაქტირების რეჟიმია
    if ($is_edit_mode) {
        // დებაგინგი
        error_log("Edit mode activated. Dish ID from POST: $dish_id");
        
        if ($dish_id <= 0) {
            echo json_encode(['status' => 0, 'message' => 'Invalid dish ID: ' . $dish_id]);
            exit();
        }
        
        // ვერიფიკაცია: შევამოწმოთ რომ კერძი არსებობს
        $stmt = $mysqli->prepare("SELECT id, menu_id, name FROM dishes WHERE id = ?");
        $stmt->bind_param("i", $dish_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $dish = $result->fetch_assoc();
        $stmt->close();
        
        if (!$dish) {
            echo json_encode([
                'status' => 0, 
                'message' => 'კერძი ვერ მოიძებნა ID: ' . $dish_id,
                'debug' => ['received_dish_id' => $dish_id, 'post_data' => $_POST]
            ]);
            exit();
        }
        
        error_log("Found dish: ID=" . $dish['id'] . ", Menu ID=" . $dish['menu_id'] . ", Name=" . $dish['name']);
        
        $current_menu_id = $dish['menu_id'];
        
        // შევამოწმოთ არის თუ არა ახალი menu_id უკვე გამოყენებული (სხვა კერძისთვის)
        if ($menu_id != $current_menu_id) {
            $stmt = $mysqli->prepare("SELECT COUNT(*) as count FROM dishes WHERE menu_id = ? AND id != ?");
            $stmt->bind_param("ii", $menu_id, $dish_id);
            $stmt->execute();
            $result = $stmt->get_result()->fetch_assoc();
            $stmt->close();
            
            if ($result['count'] > 0) {
                echo json_encode(['status' => 0, 'message' => "Menu ID $menu_id უკვე გამოყენებულია სხვა კერძისთვის"]);
                exit();
            }
        }
        
        // განვაახლოთ კერძი
        $stmt = $mysqli->prepare("
            UPDATE dishes 
            SET name = ?, sale_price = ?, active = ?, enable_vat = ?, menu_id = ?
            WHERE id = ?
        ");
        $stmt->bind_param("sdiiii", $name, $sale_price, $active, $enable_vat, $menu_id, $dish_id);
        
        if ($stmt->execute()) {
            error_log("Dish updated successfully. ID: $dish_id, New Menu ID: $menu_id");
        } else {
            error_log("Update failed: " . $stmt->error);
        }
        
        $stmt->close();
        
    } else {
        // ახალი დამატება
        // შევამოწმოთ არის თუ არა menu_id უკვე გამოყენებული
        $stmt = $mysqli->prepare("SELECT COUNT(*) as count FROM dishes WHERE menu_id = ?");
        $stmt->bind_param("i", $menu_id);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        
        if ($result['count'] > 0) {
            echo json_encode(['status' => 0, 'message' => "Menu ID $menu_id უკვე გამოყენებულია. გთხოვთ აირჩიოთ სხვა ID."]);
            exit();
        }
        
        // ჩავსვათ ახალი ჩანაწერი
        $stmt = $mysqli->prepare("
            INSERT INTO dishes (name, sale_price, active, enable_vat, menu_id, created_at)
            VALUES (?, ?, ?, ?, ?, NOW())
        ");
        $stmt->bind_param("sdiii", $name, $sale_price, $active, $enable_vat, $menu_id);
        $stmt->execute();
        
        $dish_id = $stmt->insert_id;
        $stmt->close();
        
        error_log("New dish created. ID: $dish_id, Menu ID: $menu_id");
    }
    
    $mysqli->commit();
    echo json_encode([
        'status' => 1, 
        'message' => $is_edit_mode ? '✅ კერძი წარმატებით განახლდა!' : '✅ კერძი წარმატებით დაემატა!',
        'dish_id' => $dish_id
    ]);
    
} catch (Exception $e) {
    $mysqli->rollback();
    error_log("Error in ajax_save_dish.php: " . $e->getMessage());
    echo json_encode(['status' => 0, 'message' => 'შეცდომა: ' . $e->getMessage()]);
}
?>