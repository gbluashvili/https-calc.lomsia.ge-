<?php
// ajax_get_recipe.php
require_once __DIR__ . '/../config/db.php';
require_once '../includes/functions.php';

header('Content-Type: application/json');

if (!isset($_GET['dish_id']) || !is_numeric($_GET['dish_id'])) {
    echo json_encode(['status' => 0, 'message' => 'არასწორი კერძის ID']);
    exit;
}

$dish_id = intval($_GET['dish_id']);

try {
    // მიიღე კერძის დეტალები
    $stmt = $mysqli->prepare("SELECT * FROM dishes WHERE id = ?");
    $stmt->bind_param("i", $dish_id);
    $stmt->execute();
    $dish = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    
    if (!$dish) {
        echo json_encode(['status' => 0, 'message' => 'კერძი არ მოიძებნა']);
        exit;
    }
    
    // მიიღე რეცეპტის ინგრედიენტები
    // თქვენი ბაზის სტრუქტურის მიხედვით შეცვალეთ ეს query
    $stmt = $mysqli->prepare("
        SELECT dr.*, p.name as product_name, p.unit, p.default_yield
        FROM dish_recipes dr
        LEFT JOIN products p ON dr.product_id = p.id
        WHERE dr.dish_id = ?
        ORDER BY dr.id
    ");
    $stmt->bind_param("i", $dish_id);
    $stmt->execute();
    $ingredients = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
    
    echo json_encode([
        'status' => 1,
        'dish' => $dish,
        'ingredients' => $ingredients
    ]);
    
} catch (Exception $e) {
    echo json_encode(['status' => 0, 'message' => 'სერვერული შეცდომა: ' . $e->getMessage()]);
}