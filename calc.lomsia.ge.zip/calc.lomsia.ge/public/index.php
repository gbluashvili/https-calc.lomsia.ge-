<?php
// მაგალითად: /home/mvpuufsr/calc/calc.lomsia.ge/public/index.php
session_start();
require_once __DIR__ . '/../config/db.php';

// ავტორიზაციის შემოწმება
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

// წვდომის შემოწმება
require_once __DIR__ . '/../includes/auth_check.php';

// ავტომატურად შეამოწმეთ წვდომა
checkAccessAndRedirect($conn);
?>

<?php
// მონაცემების მიღება
$products = $mysqli->query("SELECT * FROM products ORDER BY name ASC")->fetch_all(MYSQLI_ASSOC);
$dishes   = $mysqli->query("SELECT * FROM dishes ORDER BY name ASC")->fetch_all(MYSQLI_ASSOC);

// კრიტიკული ნაშთი - min_quantity-ს გამოყენებით
$low_stock = $mysqli->query("
    SELECT id, name, unit, quantity, min_quantity, price 
    FROM products 
    WHERE CAST(min_quantity AS DECIMAL(10,3)) > 0 
    AND CAST(quantity AS DECIMAL(10,3)) <= CAST(min_quantity AS DECIMAL(10,3))
    ORDER BY name ASC
")->fetch_all(MYSQLI_ASSOC);

// სტატისტიკა
$total_products = count($products);
$total_dishes = count($dishes);

// ინვენტარის ღირებულება
$total_value = 0;
foreach ($products as $product) {
    $price = floatval($product['price']);
    $quantity = floatval($product['quantity']);
    $total_value += $price * $quantity;
}

$critical_items = count($low_stock);

// DEBUG: რამდენი პროდუქტი აქვს min_quantity > 0
$result = $mysqli->query("SELECT COUNT(*) as cnt FROM products WHERE min_quantity > 0");
$row = $result->fetch_assoc();
$products_with_min_quantity = $row['cnt'];
?>

<!DOCTYPE html>
<html lang="ka">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Restaurant CMS - მთავარი</title>
    <?php include '../includes/header.php';?>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link rel="stylesheet" href="../css/style.css">
    <style>
        .dashboard {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            margin: 20px 0;
        }
        
        .stat-card {
            background: white;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            border-top: 4px solid;
        }
        
        .stat-card h3 {
            margin-top: 0;
            color: #333;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
        
        .stat-value {
            font-size: 2em;
            font-weight: bold;
            margin: 10px 0;
        }
        
        .view-details-btn {
            background: #6c757d;
            color: white;
            border: none;
            padding: 6px 12px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 0.9em;
            transition: background 0.3s;
        }
        
        .view-details-btn:hover {
            background: #5a6268;
        }
        
        .banner-container {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 40px 20px;
            border-radius: 10px;
            margin: 20px 0;
            text-align: center;
        }
        
        .banner-container h1 {
            margin: 0;
            font-size: 2.5em;
        }
        
        .banner-container p {
            font-size: 1.2em;
            opacity: 0.9;
        }
        
        .nav-menu {
            background: white;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin: 20px 0;
        }
        
        .nav-menu h2 {
            margin-top: 0;
            color: #333;
            border-bottom: 2px solid #f0f0f0;
            padding-bottom: 10px;
        }
        
        .nav-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-top: 20px;
        }
        
        .nav-item {
            background: #f8f9fa;
            border-radius: 8px;
            padding: 20px;
            text-align: center;
            transition: transform 0.3s, box-shadow 0.3s;
            text-decoration: none;
            color: #333;
        }
        
        .nav-item:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        
        .nav-item .icon {
            font-size: 2em;
            margin-bottom: 10px;
            display: block;
        }
        
        .alert-box {
            background: #fff3cd;
            border: 1px solid #ffeaa7;
            border-radius: 8px;
            padding: 15px;
            margin: 20px 0;
        }
        
        .alert-box.critical {
            background: #f8d7da;
            border-color: #f5c6cb;
            color: #721c24;
        }
        
        .low-stock-list {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
            margin-top: 10px;
        }
        
        .low-stock-item {
            background: rgba(255,255,255,0.9);
            padding: 5px 12px;
            border-radius: 15px;
            font-size: 0.9em;
        }
        
        .details-panel {
            display: none;
            background: #f8f9fa;
            border-radius: 8px;
            padding: 20px;
            margin-top: 15px;
            border-left: 4px solid #ff6b6b;
            max-height: 400px;
            overflow-y: auto;
        }
        
        .details-panel h4 {
            margin-top: 0;
            color: #721c24;
            border-bottom: 2px solid #f1aeb5;
            padding-bottom: 10px;
        }
        
        .low-stock-table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .low-stock-table th {
            background: #f8d7da;
            color: #721c24;
            padding: 12px;
            text-align: left;
            font-weight: 600;
        }
        
        .low-stock-table td {
            padding: 10px 12px;
            border-bottom: 1px solid #f1aeb5;
        }
        
        .low-stock-table tr:hover {
            background: #fff3cd;
        }
        
        .quantity-cell {
            text-align: center;
            font-weight: bold;
        }
        
        .quantity-low {
            color: #dc3545;
        }
        
        .quantity-very-low {
            color: #dc3545;
            font-weight: bold;
            background: #f8d7da;
            padding: 2px 8px;
            border-radius: 4px;
        }
        
        .stat-info {
            font-size: 0.9em;
            color: #6c757d;
            margin-top: 5px;
        }
        
        .low-stock-summary {
            background: #fff3cd;
            border: 1px solid #ffeaa7;
            border-radius: 8px;
            padding: 15px;
            margin: 20px 0;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .summary-info {
            flex: 1;
        }
        
        .summary-actions {
            display: flex;
            gap: 10px;
        }
        
        .action-btn {
            padding: 8px 16px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 5px;
        }
        
        .action-btn.view {
            background: #0dcaf0;
            color: white;
        }
        
        .action-btn.view:hover {
            background: #0bb5d9;
        }
        
        .action-btn.order {
            background: #198754;
            color: white;
        }
        
        .action-btn.order:hover {
            background: #157347;
        }
        
        .product-count {
            font-size: 1.2em;
            font-weight: bold;
            color: #721c24;
        }
        
        .toggle-all-btn {
            background: transparent;
            border: none;
            color: #0d6efd;
            cursor: pointer;
            font-size: 0.9em;
            padding: 5px 0;
            display: flex;
            align-items: center;
            gap: 5px;
        }
        
        .toggle-all-btn:hover {
            text-decoration: underline;
        }
        
        @media (max-width: 768px) {
            .low-stock-summary {
                flex-direction: column;
                gap: 15px;
            }
            
            .summary-actions {
                width: 100%;
                justify-content: center;
            }
            
            .details-panel {
                max-height: 300px;
            }
        }
        
        .debug-info {
            background: #e9ecef;
            padding: 10px;
            border-radius: 5px;
            margin: 10px 0;
            font-size: 0.9em;
            color: #666;
        }
    </style>
</head>
<body>

<?php include '../includes/navbar.php'; ?>

<div class="container">
    <div class="banner-container">
        <h1>კეთილი იყოს თქვენი მობრძანება!</h1>
        <p>მართეთ თქვენი რესტორნის ყველა ასპექტი ერთი ადგილიდან</p>
    </div>

    <!-- DEBUG ინფორმაცია -->
    <?php if(false): // დამალეთ საჭიროებისამებრ ?>
    <div class="debug-info">
        <strong>Debug ინფორმაცია:</strong><br>
        - მთლიანი პროდუქტები: <?= $total_products ?><br>
        - კრიტიკული პროდუქტები: <?= $critical_items ?><br>
        - პროდუქტები min_quantity > 0: <?= $products_with_min_quantity ?><br>
        - SQL მოთხოვნა: WHERE min_quantity > 0 AND quantity <= min_quantity
    </div>
    <?php endif; ?>

    <?php if(!empty($low_stock)): ?>
    <div class="low-stock-summary">
        <div class="summary-info">
            <h3 style="margin: 0 0 10px 0; color: #721c24;">
                ⚠️ კრიტიკული ნაშთი: <span class="product-count"><?= $critical_items ?></span> პროდუქტი
            </h3>
            <p style="margin: 0; color: #666;">
                <?= $products_with_min_quantity ?> პროდუქტს აქვს mმითითებული, 
                მათგან <?= $critical_items ?> მარაგშია მინიმალური ზღვრის ქვემოთ.
            </p>
        </div>
        <div class="summary-actions">
            <button class="action-btn view" onclick="toggleAllDetails()">
                <span>👁️</span> პროდუქტების ნახვა
            </button>
            <button class="action-btn order" onclick="window.location.href='warehouse.php?action=purchase'">
                <span>📥</span> შეკვეთა
            </button>
        </div>
    </div>
    <?php else: ?>
    <div class="alert-box">
        <strong>✅ ყველაფერი რიგზეა!</strong> 
        <p>ყველა პროდუქტი მინიმალურ ზღვარზე მაღლა ან ტოლია.</p>
        <?php if($products_with_min_quantity == 0): ?>
            <p><small>მინიშნება: არც ერთ პროდუქტს არ აქვს min_quantity მითითებული.</small></p>
        <?php endif; ?>
    </div>
    <?php endif; ?>

    <div class="dashboard">
        <div class="stat-card" style="border-color: #00c292;">
            <h3><span>📦</span> პროდუქტები</h3>
            <div class="stat-value"><?= $total_products ?></div>
            <p>საწყობში არსებული პროდუქტები</p>
        </div>
        
        <div class="stat-card" style="border-color: #6f42c1;">
            <h3><span>🍳</span> კერძები</h3>
            <div class="stat-value"><?= $total_dishes ?></div>
            <p>მენიუში არსებული კერძები</p>
        </div>
        
        <div class="stat-card" style="border-color: #28a745;">
            <h3><span>💰</span> ინვენტარის ღირებულება</h3>
            <div class="stat-value"><?= number_format($total_value, 2) ?> ₾</div>
            <p>მთლიანი თვითღირებულება</p>
        </div>
        
        <div class="stat-card" style="border-color: <?= $critical_items > 0 ? '#ff6b6b' : '#28a745' ?>;">
            <h3>
                <span><?= $critical_items > 0 ? '⚠️' : '✅' ?></span> 
                კრიტიკული ნაშთი
                <?php if($critical_items > 0): ?>
                    <button class="view-details-btn" onclick="toggleDetails('criticalDetails')">
                        დეტალები
                    </button>
                <?php endif; ?>
            </h3>
            <div class="stat-value"><?= $critical_items ?></div>
            <p>პროდუქტი მინიმალურ ზღვარს ქვემოთ</p>
            <div class="stat-info">
                <?= $products_with_min_quantity ?> პროდუქტს აქვს მითითებული მინიმალური ზრვარი
            </div>
            
            <?php if($critical_items > 0): ?>
            <div class="details-panel" id="criticalDetails">
                <h4>კრიტიკული ნაშთის დეტალები</h4>
                <table class="low-stock-table">
                    <thead>
                        <tr>
                            <th>პროდუქტი</th>
                            <th>მარაგი</th>
                            <th>მინ. ზღვარი</th>
                            <th>დეფიციტი</th>
                            <th>ფასი</th>
                            <th>მოქმედება</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $total_deficit_value = 0;
                        foreach($low_stock as $product): 
                            $quantity = floatval($product['quantity']);
                            $min_quantity = floatval($product['min_quantity']);
                            $price = floatval($product['price']);
                            $deficit = $min_quantity - $quantity;
                            $deficit_value = $deficit * $price;
                            $total_deficit_value += $deficit_value;
                            
                            // კატეგორიზაცია
                            $quantity_class = '';
                            if ($quantity == 0) {
                                $quantity_class = 'quantity-very-low';
                            } elseif ($quantity < ($min_quantity * 0.3)) {
                                $quantity_class = 'quantity-low';
                            }
                        ?>
                        <tr>
                            <td>
                                <strong><?= htmlspecialchars($product['name']) ?></strong>
                                <div style="font-size: 0.9em; color: #666;">
                                    <?= htmlspecialchars($product['unit']) ?>
                                </div>
                            </td>
                            <td class="quantity-cell <?= $quantity_class ?>">
                                <?= number_format($quantity, 3) ?>
                            </td>
                            <td class="quantity-cell">
                                <?= number_format($min_quantity, 3) ?>
                            </td>
                            <td class="quantity-cell" style="color: #dc3545;">
                                <?= number_format($deficit, 3) ?>
                            </td>
                            <td style="text-align: right;">
                                <?= number_format($price, 2) ?> ₾
                            </td>
                            <td>
                                <button class="view-details-btn" style="padding: 4px 8px; font-size: 0.8em;"
                                        onclick="orderProduct(<?= $product['id'] ?>, '<?= htmlspecialchars($product['name']) ?>')">
                                    შეკვეთა
                                </button>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                    <tfoot>
                        <tr style="background: #f8f9fa;">
                            <td colspan="4" style="text-align: right; font-weight: bold;">
                                მთლიანი დეფიციტის ღირებულება:
                            </td>
                            <td style="text-align: right; font-weight: bold; color: #dc3545;">
                                <?= number_format($total_deficit_value, 2) ?> ₾
                            </td>
                            <td></td>
                        </tr>
                    </tfoot>
                </table>
                
                <?php if(count($low_stock) > 10): ?>
                <div style="text-align: center; margin-top: 15px;">
                    <button class="toggle-all-btn" onclick="toggleAllRows()">
                        <span>📋</span> ყველა მწკრივის ჩვენება/დამალვა
                    </button>
                </div>
                <?php endif; ?>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <div class="nav-menu">
        <h2>სწრაფი ნავიგაცია</h2>
        <div class="nav-grid">
            <a href="warehouse.php" class="nav-item">
                <div class="icon">📦</div>
                <strong>საწყობის მართვა</strong>
                <p>პროდუქტების ნახვა, დამატება, რედაქტირება</p>
            </a>
            
            <a href="menu.php" class="nav-item">
                <div class="icon">🍳</div>
                <strong>მენიუს მართვა</strong>
                <p>კერძების და რეცეპტების მართვა</p>
            </a>
            
            <a href="warehouse.php?action=purchase" class="nav-item">
                <div class="icon">📥</div>
                <strong>პროდუქტის მიღება</strong>
                <p>ახალი პროდუქტების შეტანა საწყობში</p>
            </a>
            
            <a href="warehouse.php?action=waste" class="nav-item">
                <div class="icon">🗑️</div>
                <strong>პროდუქტის ჩამოწერა</strong>
                <p>ნარჩენების ან დაზიანებული პროდუქტის ჩამოწერა</p>
            </a>
            
            <a href="warehouse.php?action=set_min_quantity" class="nav-item">
                <div class="icon">🎯</div>
                <strong>კონფიგურაცია</strong>
                <p>დააყენეთ მინიმალური ზღვრები პროდუქტებისთვის</p>
            </a>
        </div>
    </div>
    
    <!-- თუ min_quantity არ არის მითითებული -->
    <?php if($products_with_min_quantity == 0): ?>
    <div class="alert-box">
        <strong>💡 რეკომენდაცია:</strong> 
        <p>კრიტიკული ნაშთის სისტემის სწორად მუშაობისთვის, გთხოვთ დააყენოთ <code>min_quantity</code> 
        პროდუქტებისთვის. ეს შეგიძლიათ გააკეთოთ:</p>
        <ol>
            <li>თითოეული პროდუქტის რედაქტირებისას</li>
            <li><a href="warehouse.php?action=set_min_quantity">კონფიგურაციის გვერდზე</a></li>
            <li>ახალი პროდუქტის დამატების დროს</li>
        </ol>
    </div>
    <?php endif; ?>
</div>

<?php include '../includes/footer.php';?>

<script>
// ფუნქციები დეტალების სანახავად
function toggleDetails(panelId) {
    var panel = document.getElementById(panelId);
    var allPanels = document.querySelectorAll('.details-panel');
    var allButtons = document.querySelectorAll('.view-details-btn');
    
    // დავხუროთ სხვა პანელები
    allPanels.forEach(function(p) {
        if (p.id !== panelId) {
            p.style.display = 'none';
        }
    });
    
    // ღილაკების ტექსტის განახლება
    allButtons.forEach(function(btn) {
        if (btn.getAttribute('onclick') === "toggleDetails('" + panelId + "')") {
            if (panel.style.display === 'block') {
                btn.textContent = 'დეტალები';
            } else {
                btn.textContent = 'დამალვა';
            }
        } else {
            btn.textContent = 'დეტალები';
        }
    });
    
    // ამ პანელის გამოჩენა/დამალვა
    if (panel.style.display === 'block') {
        panel.style.display = 'none';
    } else {
        panel.style.display = 'block';
        // სქროლირება პანელისკენ
        panel.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }
}

function toggleAllDetails() {
    var panel = document.getElementById('criticalDetails');
    var button = document.querySelector('.view-details-btn');
    
    if (panel.style.display === 'block') {
        panel.style.display = 'none';
        if (button) button.textContent = 'დეტალები';
    } else {
        panel.style.display = 'block';
        if (button) button.textContent = 'დამალვა';
        // სქროლირება პანელისკენ
        panel.scrollIntoView({ behavior: 'smooth' });
    }
}

function toggleAllRows() {
    var table = document.querySelector('.low-stock-table');
    var tbody = table.querySelector('tbody');
    var rows = tbody.querySelectorAll('tr');
    var toggleBtn = document.querySelector('.toggle-all-btn');
    
    var isHidden = rows[0].style.display === 'none';
    
    rows.forEach(function(row, index) {
        if (index >= 10) { // პირველი 10 ყოველთვის ხილული
            if (isHidden) {
                row.style.display = 'table-row';
            } else {
                row.style.display = 'none';
            }
        }
    });
    
    if (isHidden) {
        toggleBtn.innerHTML = '<span>📋</span> ყველა მწკრივის დამალვა';
    } else {
        toggleBtn.innerHTML = '<span>📋</span> ყველა მწკრივის ჩვენება';
    }
}

function orderProduct(productId, productName) {
    if (confirm('გსურთ შეუკვეთოთ პროდუქტი: ' + productName + '?')) {
        window.location.href = 'warehouse.php?action=purchase&product_id=' + productId;
    }
}

// გვერდის ჩატვირთვისას, თუ არის კრიტიკული პროდუქტები, ვაჩვენოთ პირველი 10
$(document).ready(function() {
    <?php if($critical_items > 10): ?>
    // დავამალოთ დამატებითი მწკრივები
    var rows = document.querySelectorAll('.low-stock-table tbody tr');
    rows.forEach(function(row, index) {
        if (index >= 10) {
            row.style.display = 'none';
        }
    });
    <?php endif; ?>
    
    // ანიმაცია სტატისტიკისთვის
    $('.stat-value').each(function() {
        var $this = $(this);
        var countTo = parseFloat($this.text().replace(/[^\d.-]/g, ''));
        
        if (!isNaN(countTo)) {
            $({ countNum: 0 }).animate({
                countNum: countTo
            }, {
                duration: 1000,
                easing: 'swing',
                step: function() {
                    if (countTo % 1 === 0) {
                        $this.text(Math.floor(this.countNum));
                    } else {
                        $this.text(this.countNum.toFixed(2));
                    }
                }
            });
        }
    });
    
    // კრიტიკული ნაშთის ანიმაცია
    <?php if($critical_items > 0): ?>
    setInterval(function() {
        $('.low-stock-summary').css('box-shadow', 
            $('.low-stock-summary').css('box-shadow') === 'none' ? 
            '0 0 15px rgba(220, 53, 69, 0.3)' : 'none');
    }, 1000);
    <?php endif; ?>
});
</script>

<style>
.pulse {
    animation: pulse 1s infinite;
}

@keyframes pulse {
    0% { box-shadow: 0 0 0 0 rgba(220, 53, 69, 0.7); }
    70% { box-shadow: 0 0 0 10px rgba(220, 53, 69, 0); }
    100% { box-shadow: 0 0 0 0 rgba(220, 53, 69, 0); }
}
</style>

</body>
</html>