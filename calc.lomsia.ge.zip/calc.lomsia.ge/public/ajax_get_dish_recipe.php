<?php
// /home/mvpuufsr/calc/calc.lomsia.ge/public/ajax_get_dish_recipe.php

header('Content-Type: application/json');
require_once __DIR__ . '/../config/db.php';

$dish_id = isset($_GET['dish_id']) ? intval($_GET['dish_id']) : 0;

if ($dish_id <= 0) {
    echo json_encode(['status' => 0, 'message' => 'არასწორი კერძის ID']);
    exit;
}

try {
    // 1. კერძის მონაცემები
    $stmt = $mysqli->prepare("SELECT * FROM dishes WHERE id = ?");
    $stmt->bind_param("i", $dish_id);
    $stmt->execute();
    $dish_result = $stmt->get_result();
    
    if ($dish_result->num_rows === 0) {
        echo json_encode(['status' => 0, 'message' => 'კერძი არ მოიძებნა']);
        exit;
    }
    
    $dish = $dish_result->fetch_assoc();
    $stmt->close();
    
    // 2. ინგრედიენტების მოძებნა dish_calc ცხრილიდან
    $ingredients = [];
    $total_cost = 0;
    
    // ვამოწმებთ არის თუ არა dish_calc ცხრილი
    $check_table = $mysqli->query("SHOW TABLES LIKE 'dish_calc'");
    if ($check_table->num_rows > 0) {
        $query = "SELECT dc.*, p.name as product_name, p.unit, p.price 
                  FROM dish_calc dc 
                  LEFT JOIN products p ON dc.product_id = p.id 
                  WHERE dc.dish_id = ?";
        
        $stmt = $mysqli->prepare($query);
        $stmt->bind_param('i', $dish_id);
        $stmt->execute();
        $ingredients_result = $stmt->get_result();
        
        while ($row = $ingredients_result->fetch_assoc()) {
            $quantity = floatval($row['quantity']) || 0;
            $price = floatval($row['price']) || 0;
            $cost = $quantity * $price;
            
            $ingredients[] = [
                'id' => $row['id'],
                'product_id' => $row['product_id'],
                'product_name' => $row['product_name'] ?: 'უსახელო ინგრედიენტი',
                'quantity' => $quantity,
                'unit' => $row['unit'] ?: '',
                'price' => $price,
                'cost' => $cost,
                'cost_percentage' => 0 // ქვემოთ გამოვთვლით
            ];
            
            $total_cost += $cost;
        }
        $stmt->close();
    }
    
    // გამოვთვალოთ პროცენტები
    if ($total_cost > 0) {
        foreach ($ingredients as &$ingredient) {
            $ingredient['cost_percentage'] = ($ingredient['cost'] / $total_cost) * 100;
        }
    }
    
    // 3. დეტალური ინფორმაცია
    $sale_price = floatval($dish['sale_price']) || 0;
    $cost_price = floatval($dish['cost_price']) || 0;
    $profit = $sale_price - $total_cost;
    $margin = $sale_price > 0 ? ($profit / $sale_price) * 100 : 0;
    
    // 4. დაბრუნებული პასუხი
    echo json_encode([
        'status' => 1,
        'message' => 'წარმატებით',
        'dish' => [
            'id' => intval($dish['id']),
            'name' => $dish['name'],
            'sale_price' => $sale_price,
            'cost_price' => $cost_price,
            'description' => $dish['description'] ?? '',
            'active' => $dish['active'] ?? 1,
            'enable_vat' => $dish['enable_vat'] ?? 1
        ],
        'ingredients' => $ingredients,
        'total_cost' => $total_cost,
        'profit' => $profit,
        'margin_percent' => $margin,
        'summary' => [
            'ingredient_count' => count($ingredients),
            'has_ingredients' => count($ingredients) > 0,
            'total_cost_with_vat' => $total_cost,
            'total_cost_excluding_vat' => $total_cost / 1.18 // დაშვება
        ]
    ]);
    
} catch (Exception $e) {
    echo json_encode([
        'status' => 0,
        'message' => 'Server error: ' . $e->getMessage(),
        'error' => $e->getMessage(),
        'trace' => $e->getTraceAsString()
    ]);
}
?>