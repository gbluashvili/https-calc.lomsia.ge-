<?php
require_once __DIR__ . '/../config/db.php';

header('Content-Type: application/json');

if (!$mysqli) {
    die(json_encode(['success' => false, 'message' => 'ბაზასთან დაკავშირება ვერ მოხერხდა']));
}

// მონაცემების მიღება
$product_id = intval($_POST['product_id'] ?? 0);
$quantity = floatval($_POST['quantity'] ?? 0);
$reason = trim($_POST['reason'] ?? '');
$notes = trim($_POST['notes'] ?? '');

if ($product_id <= 0) {
    echo json_encode(['success' => false, 'message' => 'არასწორი პროდუქტი']);
    exit;
}

if ($quantity <= 0) {
    echo json_encode(['success' => false, 'message' => 'არასწორი რაოდენობა']);
    exit;
}

try {
    // ტრანზაქციის დაწყება
    $mysqli->begin_transaction();

    // 1. ნაშთის შემოწმება
    $stmt_check = $mysqli->prepare("SELECT quantity, price FROM products WHERE id = ?");
    $stmt_check->bind_param("i", $product_id);
    $stmt_check->execute();
    $result = $stmt_check->get_result();
    $product = $result->fetch_assoc();
    $stmt_check->close();

    if (!$product) {
        throw new Exception("პროდუქტი ვერ მოიძებნა");
    }

    if ($product['quantity'] < $quantity) {
        throw new Exception("ნაშთში არ არის საკმარისი რაოდენობა");
    }

    // 2. ნაშთის განახლება
    $stmt_update = $mysqli->prepare("UPDATE products SET quantity = quantity - ? WHERE id = ?");
    $stmt_update->bind_param("di", $quantity, $product_id);
    $stmt_update->execute();
    $stmt_update->close();

    // 3. ჩამოწერის ისტორიაში ჩაწერა
    $total_loss = $quantity * $product['price'];
    
    $stmt_history = $mysqli->prepare("INSERT INTO waste_history (product_id, quantity, reason, notes, total_loss, waste_date) VALUES (?, ?, ?, ?, ?, NOW())");
    $stmt_history->bind_param("idssd", $product_id, $quantity, $reason, $notes, $total_loss);
    $stmt_history->execute();
    $stmt_history->close();

    $mysqli->commit();
    echo json_encode(['success' => true, 'message' => 'ჩამოწერა წარმატებით დარეგისტრირდა']);
    
} catch (Exception $e) {
    $mysqli->rollback();
    echo json_encode(['success' => false, 'message' => 'შეცდომა: ' . $e->getMessage()]);
}
?>