<?php
require_once __DIR__ . '/../config/db.php';

header('Content-Type: text/html; charset=utf-8');

if (!$mysqli) {
    die("ბაზასთან დაკავშირება ვერ მოხერხდა: " . ($mysqli->connect_error ?? "Unknown error"));
}

// CSV ფაილის გზა
$csv_file = 'products.csv';
$results = [
    'added' => 0,
    'updated' => 0,
    'errors' => 0,
    'messages' => []
];

// შევამოწმოთ, რომ CSV ფაილი არსებობს
if (!file_exists($csv_file)) {
    die("CSV ფაილი არ მოიძებნა: $csv_file");
}

// ჯერ შევამოწმოთ ცხრილის სტრუქტურა
$table_check = $mysqli->query("SHOW COLUMNS FROM products LIKE 'updated_at'");
$has_updated_at = $table_check->num_rows > 0;

// CSV ფაილის წაკითხვა
$handle = fopen($csv_file, 'r');
if ($handle === false) {
    die("CSV ფაილის გახსნა ვერ მოხერხდა: $csv_file");
}

// სვეტების სათაურები
$headers = fgetcsv($handle, 1000, ',');
echo "<h3>CSV სვეტები: " . implode(', ', $headers) . "</h3>";

// დავიწყოთ ტრანზაქცია
$mysqli->begin_transaction();

try {
    $line_number = 1;
    
    // ყოველი ხაზის დამუშავება
    while (($data = fgetcsv($handle, 1000, ',')) !== false) {
        $line_number++;
        
        // შევამოწმოთ, რომ მონაცემები არსებობს
        if (count($data) < 3) {
            $results['errors']++;
            $results['messages'][] = "ხაზი $line_number: არასაკმარისი მონაცემები - გამოტოვება";
            continue;
        }
        
        // მონაცემების მიღება
        $name = trim($data[0] ?? '');
        $price = trim($data[1] ?? '0');
        $hez_vat = trim($data[2] ?? '0');
        $quantity = trim($data[3] ?? '100');
        
        // ვალიდაცია
        if (empty($name)) {
            $results['errors']++;
            $results['messages'][] = "ხაზი $line_number: პროდუქტის სახელი ცარიელია - გამოტოვება";
            continue;
        }
        
        // ფასის დამუშავება (რამდენიმე მნიშვნელობის შემთხვევაში)
        if (strpos($price, '-') !== false) {
            $price_parts = explode('-', $price);
            $price = trim($price_parts[0]);
        }
        $price = floatval(str_replace(',', '.', $price));
        
        // რაოდენობის დამუშავება
        $quantity = floatval(str_replace(',', '.', $quantity));
        
        // VAT-ის დამუშავება
        $has_vat = (int)$hez_vat;
        $vat_status = $has_vat ? 'დღგ-თი' : 'დღგ-ის გარეშე';
        $vat_rate = $has_vat ? 18.00 : 0.00;
        
        // ერთეულის განსაზღვრა პროდუქტის სახელიდან
        $unit = 'კგ'; // ნაგულისხმევი ერთეული
        
        // ერთეულის ამოცნობა სახელიდან
        if (preg_match('/(\d+(?:[.,]\d+)?)\s*(კგ|გრ|ლ|ლიტრი|მლ|გ|ცალი|ც)/iu', $name, $matches)) {
            $unit_mapping = [
                'კგ' => 'კგ',
                'გრ' => 'გრ',
                'გ' => 'გრ',
                'ლ' => 'ლიტრი',
                'ლიტრი' => 'ლიტრი',
                'მლ' => 'ლიტრი',
                'ცალი' => 'ცალი',
                'ც' => 'ცალი'
            ];
            
            $found_unit = $matches[2];
            $unit = isset($unit_mapping[$found_unit]) ? $unit_mapping[$found_unit] : 'კგ';
            
            // თუ მითითებულია გრამებში, მაგრამ ერთეულია კგ, გადავიყვანოთ
            if (($found_unit == 'გრ' || $found_unit == 'გ') && $unit == 'კგ') {
                $quantity_value = floatval(str_replace(',', '.', $matches[1]));
                $quantity = $quantity_value * $quantity / 1000; // გადაყვანა კგ-ში
            }
        }
        
        // ვნახოთ, პროდუქტი უკვე არსებობს თუ არა
        $stmt_check = $mysqli->prepare("SELECT id FROM products WHERE name = ?");
        $stmt_check->bind_param("s", $name);
        $stmt_check->execute();
        $result = $stmt_check->get_result();
        $existing = $result->fetch_assoc();
        $stmt_check->close();
        
        if ($existing) {
            // განახლება - ავტომატურად განვსაზღვროთ updated_at-ის არსებობა
            $product_id = $existing['id'];
            
            if ($has_updated_at) {
                $stmt = $mysqli->prepare("UPDATE products SET 
                    price = ?, 
                    quantity = ?, 
                    vat_status = ?, 
                    vat_rate = ?, 
                    unit = ?,
                    has_vat = ?,
                    updated_at = CURRENT_TIMESTAMP
                    WHERE id = ?");
                $stmt->bind_param("ddsssdi", $price, $quantity, $vat_status, $vat_rate, $unit, $has_vat, $product_id);
            } else {
                $stmt = $mysqli->prepare("UPDATE products SET 
                    price = ?, 
                    quantity = ?, 
                    vat_status = ?, 
                    vat_rate = ?, 
                    unit = ?,
                    has_vat = ?
                    WHERE id = ?");
                $stmt->bind_param("ddsssdi", $price, $quantity, $vat_status, $vat_rate, $unit, $has_vat, $product_id);
            }
            $action = "განახლება";
        } else {
            // ახალი პროდუქტი
            $stmt = $mysqli->prepare("INSERT INTO products 
                (name, price, quantity, vat_status, vat_rate, unit, has_vat, min_quantity) 
                VALUES (?, ?, ?, ?, ?, ?, ?, 1.000)");
            $stmt->bind_param("sddsssi", $name, $price, $quantity, $vat_status, $vat_rate, $unit, $has_vat);
            $action = "დამატება";
        }
        
        if ($stmt->execute()) {
            if ($action == "დამატება") {
                $results['added']++;
            } else {
                $results['updated']++;
            }
            
            $results['messages'][] = "ხაზი $line_number: $name - $action წარმატებით ($price ლარი, $quantity $unit, VAT: $vat_status)";
        } else {
            $results['errors']++;
            $results['messages'][] = "ხაზი $line_number: $name - შეცდომა: " . $stmt->error;
        }
        $stmt->close();
    }
    
    // ტრანზაქციის დასრულება
    $mysqli->commit();
    fclose($handle);
    
} catch (Exception $e) {
    // ტრანზაქციის გაუქმება შეცდომის შემთხვევაში
    $mysqli->rollback();
    fclose($handle);
    die("შეცდომა იმპორტის დროს: " . $e->getMessage());
}

// შედეგების ჩვენება
?>
<!DOCTYPE html>
<html lang="ka">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CSV იმპორტის შედეგები</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }
        .container { max-width: 1200px; margin: 0 auto; background: white; padding: 20px; border-radius: 10px; box-shadow: 0 0 10px rgba(0,0,0,0.1); }
        .summary { background: #f8f9fa; padding: 20px; border-radius: 5px; margin-bottom: 20px; }
        .summary h3 { color: #333; margin-top: 0; }
        .result-item { margin: 5px 0; padding: 3px 0; }
        .success { color: #28a745; }
        .error { color: #dc3545; }
        .info { color: #007bff; }
        .message-box { 
            max-height: 400px; 
            overflow-y: auto; 
            border: 1px solid #ddd; 
            padding: 15px; 
            border-radius: 5px;
            background: #f8f9fa;
            font-family: 'Consolas', monospace;
            font-size: 12px;
            line-height: 1.4;
        }
        .btn {
            display: inline-block;
            padding: 10px 20px;
            background: #007bff;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            margin: 5px;
            border: none;
            cursor: pointer;
        }
        .btn:hover {
            background: #0056b3;
        }
        .btn-green {
            background: #28a745;
        }
        .btn-green:hover {
            background: #218838;
        }
        .btn-orange {
            background: #ffc107;
            color: #333;
        }
        .btn-orange:hover {
            background: #e0a800;
        }
        .stats {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 10px;
            margin-bottom: 20px;
        }
        .stat-box {
            padding: 15px;
            border-radius: 5px;
            text-align: center;
            color: white;
            font-weight: bold;
        }
        .added { background: #28a745; }
        .updated { background: #ffc107; color: #333; }
        .errors { background: #dc3545; }
        .total { background: #007bff; }
        h1 { color: #333; border-bottom: 2px solid #007bff; padding-bottom: 10px; }
    </style>
</head>
<body>
    <div class="container">
        <h1>📦 პროდუქტების CSV იმპორტი</h1>
        
        <div class="stats">
            <div class="stat-box added">
                <h3>დამატებული</h3>
                <p><?= $results['added'] ?></p>
            </div>
            <div class="stat-box updated">
                <h3>განახლებული</h3>
                <p><?= $results['updated'] ?></p>
            </div>
            <div class="stat-box errors">
                <h3>შეცდომები</h3>
                <p><?= $results['errors'] ?></p>
            </div>
            <div class="stat-box total">
                <h3>სულ ხაზები</h3>
                <p><?= $line_number - 1 ?></p>
            </div>
        </div>
        
        <div class="summary">
            <h3>მოქმედებები:</h3>
            <div class="message-box">
                <?php foreach ($results['messages'] as $message): ?>
                    <div class="result-item <?= strpos($message, 'წარმატებით') !== false ? 'success' : 
                                            (strpos($message, 'შეცდომა') !== false ? 'error' : 'info') ?>">
                        <?= htmlspecialchars($message) ?>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        
        <div style="margin-top: 20px;">
            <a href="warehouse.php" class="btn">⬅️ სამაშველოს გვერდზე დაბრუნება</a>
            <a href="import_products.php" class="btn btn-green">🔄 ხელახლა გაშვება</a>
            <a href="check_products.php" class="btn btn-orange">🔍 პროდუქტების შემოწმება</a>
        </div>
        
        <div style="margin-top: 30px; background: #e9f7fe; padding: 15px; border-radius: 5px; border-left: 4px solid #007bff;">
            <h3>📋 იმპორტის ინფორმაცია:</h3>
            <ul>
                <li><strong>ფაილი:</strong> <?= basename($csv_file) ?></li>
                <li><strong>სვეტები:</strong> <?= implode(', ', $headers) ?></li>
                <li><strong>გამოვლენილი სვეტები ცხრილში:</strong> has_vat, vat_status, vat_rate</li>
                <li><strong>updated_at სვეტი:</strong> <?= $has_updated_at ? 'არსებობს' : 'არ არსებობს' ?></li>
            </ul>
        </div>
    </div>
</body>
</html>