<?php
require_once __DIR__ . '/../config/db.php';

header('Content-Type: application/json');

if (!$mysqli) {
    die(json_encode(['success' => false, 'message' => 'ბაზასთან დაკავშირება ვერ მოხერხდა']));
}

// მონაცემების მიღება
$id = intval($_POST['id'] ?? 0);

if ($id <= 0) {
    echo json_encode(['success' => false, 'message' => 'არასწორი პროდუქტი']);
    exit;
}

try {
    // პროდუქტის წაშლა
    $stmt = $mysqli->prepare("DELETE FROM products WHERE id = ?");
    $stmt->bind_param("i", $id);
    
    if ($stmt->execute()) {
        if ($stmt->affected_rows > 0) {
            echo json_encode(['success' => true, 'message' => 'პროდუქტი წარმატებით წაიშალა']);
        } else {
            echo json_encode(['success' => false, 'message' => 'პროდუქტი ვერ მოიძებნა']);
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'შეცდომა ბაზაში: ' . $stmt->error]);
    }
    $stmt->close();
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'შეცდომა: ' . $e->getMessage()]);
}
?>