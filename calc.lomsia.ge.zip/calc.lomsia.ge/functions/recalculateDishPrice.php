<?php
function recalculateDishPrice(mysqli $db, int $dish_id): void
{
    // 1️⃣ თვითღირებულება
    $stmt = $db->prepare("
        SELECT SUM(dp.quantity * p.price) AS cost
        FROM dish_products dp
        JOIN products p ON p.id = dp.product_id
        WHERE dp.dish_id = ?
    ");
    $stmt->bind_param("i", $dish_id);
    $stmt->execute();
    $cost = (float)$stmt->get_result()->fetch_assoc()['cost'];

    // 2️⃣ მარკაპის პარამეტრები
    $stmt = $db->prepare("
        SELECT price_mode, markup_percent, markup_fixed, sale_price
        FROM dishes WHERE id = ?
    ");
    $stmt->bind_param("i", $dish_id);
    $stmt->execute();
    $d = $stmt->get_result()->fetch_assoc();

    $sale = $cost;

    if ($d['price_mode'] === 'percent') {
        $sale = $cost + ($cost * $d['markup_percent'] / 100);
    }
    elseif ($d['price_mode'] === 'fixed') {
        $sale = $cost + $d['markup_fixed'];
    }
    elseif ($d['price_mode'] === 'manual') {
        return; // ხელითაა მითითებული — არ ვეხებით
    }

    // 3️⃣ შენახვა
    $stmt = $db->prepare("
        UPDATE dishes 
        SET cost_price = ?, sale_price = ?
        WHERE id = ?
    ");
    $stmt->bind_param("ddi", $cost, $sale, $dish_id);
    $stmt->execute();
}
