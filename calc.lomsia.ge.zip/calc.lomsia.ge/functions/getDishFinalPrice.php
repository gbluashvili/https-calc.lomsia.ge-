<?php
function getDishFinalPrice(mysqli $db, int $dish_id, string $category = null): array
{
    // 1️⃣ ბაზური ფასი
    $stmt = $db->prepare("SELECT sale_price, enable_vat FROM dishes WHERE id=?");
    $stmt->bind_param("i",$dish_id);
    $stmt->execute();
    $dish = $stmt->get_result()->fetch_assoc();
    $price = (float)$dish['sale_price'];

    // 2️⃣ აქტიური ფასდაკლება
    $now = date('Y-m-d H:i:s');
    $query = "SELECT discount_type, discount_value 
              FROM discounts 
              WHERE dish_id=? AND active=1 AND (start_date IS NULL OR start_date<=?) AND (end_date IS NULL OR end_date>=?)";
    if($category) $query .= " AND (category IS NULL OR category=?)";

    $stmt = $db->prepare($query);
    if($category){
        $stmt->bind_param("isss", $dish_id, $now, $now, $category);
    } else {
        $stmt->bind_param("iss", $dish_id, $now, $now);
    }
    $stmt->execute();
    $res = $stmt->get_result()->fetch_assoc();

    $discount_amount = 0;
    if($res){
        if($res['discount_type']=='percent'){
            $discount_amount = $price * $res['discount_value']/100;
        } else {
            $discount_amount = $res['discount_value'];
        }
    }

    $final_price = max(0, $price - $discount_amount);

    // 3️⃣ VAT
    $vat = $dish['enable_vat'] ? $final_price * 0.18 : 0;
    $total_price = $final_price + $vat;

    return [
        'base_price' => $price,
        'discount' => $discount_amount,
        'final_price' => $final_price,
        'vat' => $vat,
        'total_price' => $total_price
    ];
}
