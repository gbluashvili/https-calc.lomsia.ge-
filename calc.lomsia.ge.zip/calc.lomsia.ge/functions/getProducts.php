<?php
// /functions/getProducts.php

/**
 * Returns all products from the database
 *
 * @param mysqli $mysqli
 * @return array
 */
function getProducts(mysqli $mysqli): array {
    $products = [];

    $sql = "SELECT id, name, unit, quantity, price, vat_rate, min_quantity, created_at 
            FROM products 
            ORDER BY id ASC";

    if ($result = $mysqli->query($sql)) {
        while ($row = $result->fetch_assoc()) {
            $products[] = $row;
        }
        $result->free();
    }

    return $products;
}
