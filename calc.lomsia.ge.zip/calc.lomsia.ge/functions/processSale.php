<?php
function processSale(mysqli $db, int $dish_id, int $qty): array
{
    if ($qty <= 0) {
        return ['status'=>0,'message'=>'Invalid quantity'];
    }

    $db->begin_transaction();

    try {
        // 1️⃣ კერძის ფასი + VAT
        $stmt = $db->prepare("
            SELECT sale_price, enable_vat 
            FROM dishes WHERE id = ?
        ");
        $stmt->bind_param("i", $dish_id);
        $stmt->execute();
        $dish = $stmt->get_result()->fetch_assoc();

        if (!$dish) {
            throw new Exception('Dish not found');
        }

        $net = $dish['sale_price'] * $qty;
        $vat = $dish['enable_vat'] ? $net * 0.18 : 0;
        $total = $net + $vat;

        // 2️⃣ გაყიდვის ჩაწერა
        $stmt = $db->prepare("
            INSERT INTO sales 
            (dish_id, quantity, net_amount, vat_amount, total_amount)
            VALUES (?,?,?,?,?)
        ");
        $stmt->bind_param("iiddd", $dish_id, $qty, $net, $vat, $total);
        $stmt->execute();

        // 3️⃣ კერძის პროდუქტები
        $stmt = $db->prepare("
            SELECT product_id, quantity 
            FROM dish_products 
            WHERE dish_id = ?
        ");
        $stmt->bind_param("i", $dish_id);
        $stmt->execute();
        $products = $stmt->get_result();

        while ($row = $products->fetch_assoc()) {
            $consume_qty = $row['quantity'] * $qty;

            // 4️⃣ ნაშთის შემოწმება
            $stmt2 = $db->prepare("
                SELECT quantity FROM products WHERE id = ?
            ");
            $stmt2->bind_param("i", $row['product_id']);
            $stmt2->execute();
            $p = $stmt2->get_result()->fetch_assoc();

            if ($p['quantity'] < $consume_qty) {
                throw new Exception('Not enough stock for product ID '.$row['product_id']);
            }

            // 5️⃣ ნაშთის ჩამოწერა
            $stmt2 = $db->prepare("
                UPDATE products 
                SET quantity = quantity - ?
                WHERE id = ?
            ");
            $stmt2->bind_param("di", $consume_qty, $row['product_id']);
            $stmt2->execute();

            // 6️⃣ მოძრაობის ლოგი
            $stmt2 = $db->prepare("
                INSERT INTO stock_movements
                (product_id, change_qty, reason)
                VALUES (?,?,?)
            ");
            $reason = 'Dish sale #' . $dish_id;
            $neg_qty = -$consume_qty;
            $stmt2->bind_param("ids", $row['product_id'], $neg_qty, $reason);
            $stmt2->execute();
        }

        $db->commit();
        return ['status'=>1,'message'=>'Sale completed successfully'];

    } catch (Exception $e) {
        $db->rollback();
        return ['status'=>0,'message'=>$e->getMessage()];
    }
}
