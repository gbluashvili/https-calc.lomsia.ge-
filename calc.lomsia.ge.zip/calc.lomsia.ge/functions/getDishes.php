<?php
// /functions/getDishes.php

/**
 * Returns all dishes from the database
 *
 * @param mysqli $mysqli
 * @return array
 */
function getDishes(mysqli $mysqli): array {
    $dishes = [];

    $sql = "SELECT id, name, sale_price, enable_vat, active, created_at 
            FROM dishes 
            ORDER BY id ASC";

    if ($result = $mysqli->query($sql)) {
        while ($row = $result->fetch_assoc()) {
            $dishes[] = $row;
        }
        $result->free();
    }

    return $dishes;
}
