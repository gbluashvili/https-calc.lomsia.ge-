<?php

function addProduct($mysqli, $data) {
    $stmt = $mysqli->prepare("
        INSERT INTO products (name, unit, quantity, price, vat_rate, min_quantity)
        VALUES (?, ?, ?, ?, ?, ?)
    ");

    $stmt->bind_param(
        "ssdddd",
        $data['name'],
        $data['unit'],
        $data['quantity'],
        $data['price'],
        $data['vat_rate'],
        $data['min_quantity']
    );

    return $stmt->execute();
}

function getProducts($mysqli) {
    $result = $mysqli->query("SELECT * FROM products ORDER BY id DESC");
    return $result->fetch_all(MYSQLI_ASSOC);
}

function addStockMovement($mysqli, $product_id, $qty, $reason = '') {
    $stmt = $mysqli->prepare("
        INSERT INTO stock_movements (product_id, change_qty, reason)
        VALUES (?, ?, ?)
    ");
    $stmt->bind_param("ids", $product_id, $qty, $reason);
    $stmt->execute();

    $mysqli->query("
        UPDATE products 
        SET quantity = quantity + ($qty)
        WHERE id = $product_id
    ");
}
