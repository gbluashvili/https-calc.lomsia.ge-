<?php
function getSalesReport(mysqli $db, $start_date = null, $end_date = null, $dish_id = null) {
    $query = "SELECT s.dish_id, d.name, SUM(s.quantity) as total_qty,
                     SUM(s.net_amount) as total_net,
                     SUM(s.vat_amount) as total_vat,
                     SUM(s.total_amount) as total_amount
              FROM sales s
              JOIN dishes d ON s.dish_id = d.id
              WHERE 1";

    $params = [];
    $types = '';

    if($start_date){
        $query .= " AND s.created_at >= ?";
        $params[] = $start_date;
        $types .= 's';
    }
    if($end_date){
        $query .= " AND s.created_at <= ?";
        $params[] = $end_date;
        $types .= 's';
    }
    if($dish_id){
        $query .= " AND s.dish_id = ?";
        $params[] = $dish_id;
        $types .= 'i';
    }

    $query .= " GROUP BY s.dish_id ORDER BY total_amount DESC";

    $stmt = $db->prepare($query);
    if(!empty($params)){
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
}
