// /home/mvpuufsr/calc/calc.lomsia.ge/public/js/menu.js

// გლობალური ცვლადები
let currentSaleDishId = null;
let currentSaleQuantity = 1;
let currentSalePrice = 0;
let dishIngredients = {};
let calculatedCostDetails = null;

// ============================================
// კერძის დამატების/რედაქტირების ფუნქციონალი
// ============================================

function showDishForm(editId = null) { 
    // ვამზადებთ ფორმას
    let formHTML = `
    <div id="dishFormDiv" class="form-container" style="border-top: 5px solid #6f42c1; margin-bottom: 20px;">
        <h3>${editId ? '✏️ კერძის რედაქტირება' : '🍳 ახალი კერძი'}</h3>
        <div class="form-body">
            <div class="pur-grid">
                <div class="form-group">
                    <label>კერძის დასახელება:</label>
                    <input type="text" id="new_d_name" placeholder="მაგ: ხინკალი">
                </div>
                <div class="form-group">
                    <label>მენიუს ID:</label>
                    <input type="number" id="new_menu_id" placeholder="მაგ: 1, 2, 3" ${window.has_menu_id ? '' : 'disabled'}>
                    <small style="font-size: 11px; color: #666;">${window.has_menu_id ? 'თუ გაქვთ სხვადასხვა მენიუ' : 'menu_id სვეტი ჯერ არ არსებობს ბაზაში'}</small>
                </div>
            </div>
            <div class="pur-grid">
                <div class="form-group">
                    <label>გასაყიდი ფასი (₾):</label>
                    <input type="number" id="new_d_price" step="0.01" placeholder="0.00">
                </div>
                <div class="form-group">
                    <label>თვითღირებულება (₾):</label>
                    <input type="number" id="new_d_cost_price" step="0.01" value="0.00">
                </div>
            </div>
            <div class="pur-grid">
                <div class="form-group">
                    <label>დღგ-ს გამოყენება:</label>
                    <select id="new_d_vat">
                        <option value="1" selected>კი</option>
                        <option value="0">არა</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>სტატუსი:</label>
                    <select id="new_d_status">
                        <option value="1" selected>აქტიური</option>
                        <option value="0">არააქტიური</option>
                    </select>
                </div>
            </div>
            <div class="form-actions">
                <button class="btn btn-blue" id="saveNewDish" data-edit-id="${editId || ''}">
                    ${editId ? '💾 ცვლილებების შენახვა' : '✅ კერძის დამატება'}
                </button>
                <button class="btn btn-gray" onclick="closeDishForm()">✕ გაუქმება</button>
            </div>
        </div>
    </div>
    `;
    
    // ვამოწმებთ არის თუ არა უკვე ფორმა გამოსახული
    const existingForm = document.getElementById('dishFormDiv');
    if (existingForm) {
        existingForm.remove();
    }
    
    // ვამატებთ ახალ ფორმას action-buttons დივის შემდეგ
    const actionButtons = document.querySelector('.action-buttons');
    actionButtons.insertAdjacentHTML('afterend', formHTML);
    
    // ვაჩვენებთ ფორმას ანიმაციით
    const formDiv = document.getElementById('dishFormDiv');
    formDiv.style.display = 'block';
    formDiv.style.opacity = '0';
    formDiv.style.transform = 'translateY(-20px)';
    
    setTimeout(() => {
        formDiv.style.transition = 'all 0.3s ease';
        formDiv.style.opacity = '1';
        formDiv.style.transform = 'translateY(0)';
    }, 10);
    
    // თუ რედაქტირებაა, ვავსებთ ველებს
    if (editId) {
        loadDishData(editId);
    } else {
        // ახალი კერძისთვის ვასუფთავებთ ველებს
        document.getElementById('new_d_name').value = '';
        document.getElementById('new_menu_id').value = '';
        document.getElementById('new_d_price').value = '';
        document.getElementById('new_d_cost_price').value = '0.00';
        document.getElementById('new_d_vat').value = '1';
        document.getElementById('new_d_status').value = '1';
    }
    
    // ვამატებთ ევენთ ლისენერს Save ღილაკზე
    document.getElementById('saveNewDish').addEventListener('click', saveDish);
}

function closeDishForm() {
    const formDiv = document.getElementById('dishFormDiv');
    if (formDiv) {
        formDiv.style.opacity = '0';
        formDiv.style.transform = 'translateY(-20px)';
        
        setTimeout(() => {
            formDiv.style.display = 'none';
        }, 300);
    }
}

function loadDishData(dishId) {
    $.ajax({
        url: 'ajax_get_dish.php',
        type: 'GET',
        data: { id: dishId },
        dataType: 'json',
        success: function(response) {
            if (response.status === 1) {
                const dish = response.dish;
                document.getElementById('new_d_name').value = dish.name || '';
                document.getElementById('new_menu_id').value = dish.menu_id || '';
                document.getElementById('new_d_price').value = dish.sale_price || '';
                document.getElementById('new_d_cost_price').value = dish.cost_price || '0.00';
                document.getElementById('new_d_vat').value = dish.enable_vat || '1';
                document.getElementById('new_d_status').value = dish.active || '1';
            } else {
                alert('❌ კერძის მონაცემების ჩატვირთვის შეცდომა: ' + response.message);
            }
        },
        error: function() {
            alert('❌ სერვერული შეცდომა მონაცემების ჩატვირთვისას');
        }
    });
}

function saveDish() {
    const saveBtn = document.getElementById('saveNewDish');
    const dishId = saveBtn.getAttribute('data-edit-id');
    const dishName = document.getElementById('new_d_name').value.trim();
    const dishPrice = parseFloat(document.getElementById('new_d_price').value) || 0;
    const costPrice = parseFloat(document.getElementById('new_d_cost_price').value) || 0;
    const menuId = document.getElementById('new_menu_id').value ? parseInt(document.getElementById('new_menu_id').value) : null;
    const enableVat = document.getElementById('new_d_vat').value;
    const active = document.getElementById('new_d_status').value;
    
    if (!dishName) {
        alert('გთხოვთ შეიყვანოთ კერძის დასახელება');
        return;
    }
    
    if (dishPrice <= 0) {
        alert('გთხოვთ შეიყვანოთ მართებული ფასი');
        return;
    }
    
    const dishData = {
        name: dishName,
        price: dishPrice,
        cost_price: costPrice,
        menu_id: menuId,
        enable_vat: enableVat,
        active: active
    };
    
    // თუ რედაქტირებაა
    if (dishId) {
        dishData.id = dishId;
    }
    
    // დისეიბლებული ღილაკი
    saveBtn.disabled = true;
    saveBtn.innerHTML = '⏳ იწერება...';
    
    $.ajax({
        url: 'ajax_save_dish.php',
        type: 'POST',
        data: dishData,
        dataType: 'json',
        success: function(response) {
            if (response.status === 1) {
                alert(dishId ? '✅ კერძი განახლებულია!' : '✅ კერძი დამატებულია!');
                location.reload();
            } else {
                alert('❌ შეცდომა: ' + response.message);
                saveBtn.disabled = false;
                saveBtn.innerHTML = dishId ? '💾 ცვლილებების შენახვა' : '✅ კერძის დამატება';
            }
        },
        error: function() {
            alert('❌ სერვერული შეცდომა');
            saveBtn.disabled = false;
            saveBtn.innerHTML = dishId ? '💾 ცვლილებების შენახვა' : '✅ კერძის დამატება';
        }
    });
}

// ============================================
// რეცეპტის ფუნქციონალი
// ============================================

function showDishRecipe(dishId) {
    console.log('Showing recipe for dish ID:', dishId);
    
    $.ajax({
        url: 'ajax_get_dish_recipe.php',
        type: 'GET',
        data: { dish_id: dishId },
        dataType: 'json',
        success: function(response) {
            if (response.status === 1) {
                createRecipeModal(response);
            } else {
                alert('❌ რეცეპტის ჩატვირთვის შეცდომა: ' + response.message);
            }
        },
        error: function(xhr, status, error) {
            console.error('AJAX Error:', error);
            alert('❌ სერვერული შეცდომა რეცეპტის ჩატვირთვისას');
        }
    });
}

function createRecipeModal(recipeData) {
    const dish = recipeData.dish;
    const ingredients = recipeData.ingredients || [];
    const totalCost = parseFloat(recipeData.total_cost) || 0;
    const salePrice = parseFloat(dish.sale_price) || 0;
    const profit = salePrice - totalCost;
    const margin = salePrice > 0 ? (profit / salePrice) * 100 : 0;
    
    let ingredientsHTML = '';
    if (ingredients.length > 0) {
        ingredients.forEach(ing => {
            ingredientsHTML += `
                <tr>
                    <td>${ing.product_name || 'უსახელო'}</td>
                    <td>${parseFloat(ing.quantity || 0).toFixed(3)} ${ing.unit || ''}</td>
                    <td>${parseFloat(ing.cost || 0).toFixed(2)} ₾</td>
                    <td>${parseFloat(ing.cost_percentage || 0).toFixed(1)}%</td>
                </tr>
            `;
        });
    } else {
        ingredientsHTML = `
            <tr>
                <td colspan="4" style="text-align: center; padding: 20px;">
                    ჯერ არ არის დამატებული ინგრედიენტები
                </td>
            </tr>
        `;
    }
    
    const modalHTML = `
        <div id="recipeModal" class="modal-overlay" style="display: flex;">
            <div class="modal-content" style="max-width: 800px;">
                <div class="modal-header">
                    <h3>📊 ${dish.name} - რეცეპტი</h3>
                    <button class="close-modal" onclick="closeRecipeModal()">&times;</button>
                </div>
                <div class="modal-body">
                    <div class="recipe-summary">
                        <div class="summary-item">
                            <div class="summary-label">გასაყიდი ფასი</div>
                            <div class="summary-value">${salePrice.toFixed(2)} ₾</div>
                        </div>
                        <div class="summary-item">
                            <div class="summary-label">თვითღირებულება</div>
                            <div class="summary-value">${totalCost.toFixed(2)} ₾</div>
                        </div>
                        <div class="summary-item">
                            <div class="summary-label">მოგება</div>
                            <div class="summary-value ${profit >= 0 ? 'profit-positive' : 'profit-negative'}">
                                ${profit.toFixed(2)} ₾
                            </div>
                        </div>
                        <div class="summary-item">
                            <div class="summary-label">მარჟა</div>
                            <div class="summary-value ${margin >= 0 ? 'margin-positive' : 'margin-negative'}">
                                ${margin.toFixed(1)}%
                            </div>
                        </div>
                    </div>
                    
                    <h4>ინგრედიენტები (${ingredients.length})</h4>
                    <div class="table-container" style="max-height: 300px; overflow-y: auto;">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>ინგრედიენტი</th>
                                    <th>რაოდენობა</th>
                                    <th>ღირებულება</th>
                                    <th>%</th>
                                </tr>
                            </thead>
                            <tbody>
                                ${ingredientsHTML}
                            </tbody>
                        </table>
                    </div>
                    
                    ${recipeData.notes ? `
                    <div class="recipe-notes">
                        <h4>შენიშვნები</h4>
                        <p>${recipeData.notes}</p>
                    </div>
                    ` : ''}
                </div>
                <div class="modal-footer">
                    <button class="btn btn-gray" onclick="closeRecipeModal()">დახურვა</button>
                    <button class="btn btn-purple" onclick="editDishRecipe(${dish.id})">✏️ რეცეპტის რედაქტირება</button>
                </div>
            </div>
        </div>
    `;
    
    // წაშალე არსებული მოდალი
    $('#recipeModal').remove();
    
    // დამატე ახალი მოდალი
    $('body').append(modalHTML);
    $('#recipeModal').fadeIn();
}

function closeRecipeModal() {
    $('#recipeModal').fadeOut(function() {
        $(this).remove();
    });
}

function editDishRecipe(dishId) {
    // ეს ფუნქცია გადაგიყვანთ რეცეპტის რედაქტირების გვერდზე
    window.location.href = 'edit_recipe.php?dish_id=' + dishId;
}

// ============================================
// კერძის წაშლის ფუნქციონალი
// ============================================

function deleteDish(dishId, dishName) {
    if (!confirm(`დარწმუნებული ხართ, რომ გსურთ კერძის "${dishName}" წაშლა?\n\nეს მოქმედება შექცევადი არ არის!`)) {
        return;
    }
    
    $.ajax({
        url: 'ajax_delete_dish.php',
        type: 'POST',
        data: { id: dishId },
        dataType: 'json',
        success: function(response) {
            if (response.status === 1) {
                alert('✅ კერძი წარმატებით წაიშალა!');
                location.reload();
            } else {
                alert('❌ შეცდომა: ' + response.message);
            }
        },
        error: function() {
            alert('❌ სერვერული შეცდომა');
        }
    });
}

// ============================================
// გაყიდვის ფუნქციონალი
// ============================================

// გაყიდვის რაოდენობის შეცვლა ღილაკებით
function changeSaleQuantity(change) {
    let newQuantity = currentSaleQuantity + change;
    if (newQuantity < 1) newQuantity = 1;
    
    currentSaleQuantity = newQuantity;
    $('#saleQuantity').val(newQuantity);
    updateSaleInfo();
    checkStockAndCalculateCost(currentSaleDishId, newQuantity);
}

// გაყიდვის რაოდენობის შეცვლა ინფუთიდან
function updateSaleQuantity(value) {
    const quantity = parseInt(value) || 1;
    if (quantity < 1) return;
    
    currentSaleQuantity = quantity;
    updateSaleInfo();
    checkStockAndCalculateCost(currentSaleDishId, quantity);
}

// გაყიდვის ინფორმაციის განახლება
function updateSaleInfo() {
    const totalPrice = currentSalePrice * currentSaleQuantity;
    const vat = totalPrice * 0.18;
    const priceWithoutVat = totalPrice / 1.18;
    
    $('#totalSalePrice').text(totalPrice.toFixed(2) + ' ₾');
    $('#vatAmount').text(vat.toFixed(2) + ' ₾');
    $('#priceWithoutVat').text(priceWithoutVat.toFixed(2) + ' ₾');
    
    // თუ ღირებულების დეტალები უკვე გამოთვლილია, განვაახლოთ
    if (calculatedCostDetails) {
        updateCostDetailsDisplay();
    }
}

// მარაგის შემოწმება და ღირებულების გამოთვლა ერთად
function checkStockAndCalculateCost(dishId, quantity) {
    $('#saleLoading').show();
    $('#loadingMessage').text('მარაგის შემოწმება და ღირებულების გაანგარიშება...');
    $('#progressBar').css('width', '30%');
    
    // ვამზადებთ მონაცემებს
    var requestData = {
        dish_id: dishId,
        quantity: quantity,
        unit_price: currentSalePrice
    };
    
    console.log('Sending AJAX request with data:', requestData);
    
    $.ajax({
        url: 'ajax_check_and_calculate.php',
        type: 'POST',
        data: requestData,
        dataType: 'json',
        success: function(response) {
            console.log('AJAX response:', response);
            $('#progressBar').css('width', '100%');
            
            setTimeout(function() {
                $('#saleLoading').hide();
                $('#progressBar').css('width', '0%');
                
                if (response.status === 1) {
                    // მარაგის შედეგის ჩვენება
                    displayStockCheckResult(response.ingredients);
                    dishIngredients[dishId] = response.ingredients;
                    
                    // ღირებულების დეტალების შენახვა და ჩვენება
                    if (response.cost_details) {
                        calculatedCostDetails = response.cost_details;
                        updateCostDetailsDisplay();
                    }
                    
                    // შეამოწმე არის თუ არა საკმარისი მარაგი
                    const hasInsufficient = response.ingredients ? response.ingredients.some(ing => !ing.has_enough) : false;
                    $('#insufficientStockWarning').toggle(hasInsufficient);
                    $('#confirmSaleBtn').prop('disabled', hasInsufficient);
                } else {
                    let errorMsg = response.message || 'გაურკვეველი შეცდომა';
                    if (response.debug) {
                        errorMsg += '\nDebug: ' + JSON.stringify(response.debug);
                    }
                    
                    $('#stockCheckResult').html(
                        `<div style="color: #dc3545; text-align: center; padding: 20px;">
                            <div>❌ შეცდომა</div>
                            <div style="font-size: 12px;">${errorMsg}</div>
                            <div style="font-size: 10px; color: #999; margin-top: 10px;">
                                dish_id: ${dishId}<br>
                                quantity: ${quantity}<br>
                                unit_price: ${currentSalePrice}
                            </div>
                        </div>`
                    ).show();
                    $('#confirmSaleBtn').prop('disabled', true);
                }
            }, 300);
        },
        error: function(xhr, status, error) {
            $('#saleLoading').hide();
            console.error('AJAX Error:', status, error, xhr.responseText);
            
            $('#stockCheckResult').html(
                `<div style="color: #dc3545; text-align: center; padding: 20px;">
                    <div>❌ სერვერული შეცდომა</div>
                    <div style="font-size: 12px;">${error}</div>
                    <div style="font-size: 10px; color: #999; margin-top: 10px;">
                        Status: ${status}<br>
                        Response: ${xhr.responseText}
                    </div>
                </div>`
            ).show();
            $('#confirmSaleBtn').prop('disabled', true);
        }
    });
}

// მარაგის შემოწმების შედეგის ჩვენება
function displayStockCheckResult(ingredients) {
    if (!ingredients || !Array.isArray(ingredients)) {
        console.error('Invalid ingredients data:', ingredients);
        $('#stockCheckResult').html(
            `<div style="color: #dc3545; text-align: center; padding: 20px;">
                <div>❌ მარაგის მონაცემები არ არის ხელმისაწვდომი</div>
            </div>`
        ).show();
        return;
    }
    
    let html = '<h4 style="margin-top: 0; color: #555;">მარაგის შემოწმება:</h4>';
    
    ingredients.forEach(ingredient => {
        // უსაფრთხო მნიშვნელობების აღება
        const required = parseFloat(ingredient.required) || 0;
        const available = parseFloat(ingredient.available) || 0;
        const unit = ingredient.unit || '';
        const product_name = ingredient.product_name || 'უსახელო ინგრედიენტი';
        const has_enough = ingredient.has_enough || false;
        const available_percentage = parseFloat(ingredient.available_percentage) || 0;
        
        const statusClass = has_enough ? 'stock-ok' : 
                           available_percentage >= 50 ? 'stock-low' : 'stock-critical';
        const statusText = has_enough ? '✅ საკმარისია' : 
                          available_percentage >= 50 ? '⚠️ დაბალია' : '❌ არ არის საკმარისი';
        
        html += `
            <div class="stock-item">
                <div class="stock-item-name">${product_name}</div>
                <div class="stock-item-status ${statusClass}">
                    ${required.toFixed(3)} ${unit} / 
                    ${available.toFixed(3)} ${unit}
                    (${available_percentage.toFixed(1)}%) - ${statusText}
                </div>
            </div>
        `;
    });
    
    $('#stockCheckResult').html(html).show();
}

// ღირებულების დეტალების განახლება
function updateCostDetailsDisplay() {
    if (!calculatedCostDetails) {
        console.log('No cost details available');
        return;
    }
    
    const cost_with_vat = parseFloat(calculatedCostDetails.cost_with_vat) || 0;
    const cost_excluding_vat = parseFloat(calculatedCostDetails.cost_excluding_vat) || 0;
    const total_revenue = parseFloat(calculatedCostDetails.total_revenue) || (currentSalePrice * currentSaleQuantity);
    const net_amount = parseFloat(calculatedCostDetails.net_amount) || (total_revenue / 1.18);
    const vat_amount = parseFloat(calculatedCostDetails.vat_amount) || (total_revenue * 0.18);
    const profit = parseFloat(calculatedCostDetails.profit) || (net_amount - cost_excluding_vat);
    const margin_percent = parseFloat(calculatedCostDetails.margin_percent) || 
        (cost_excluding_vat > 0 ? (profit / cost_excluding_vat) * 100 : 0);
    
    let html = `
        <div class="detail-item">
            <div class="detail-label">თვითღირ. (დღგ-თი)</div>
            <div class="detail-value detail-cost">${cost_with_vat.toFixed(2)} ₾</div>
        </div>
        <div class="detail-item">
            <div class="detail-label">თვითღირ. (Ex.VAT)</div>
            <div class="detail-value detail-cost">${cost_excluding_vat.toFixed(2)} ₾</div>
        </div>
        <div class="detail-item">
            <div class="detail-label">გაყიდვა (დღგ-თი)</div>
            <div class="detail-value detail-revenue">${total_revenue.toFixed(2)} ₾</div>
        </div>
        <div class="detail-item">
            <div class="detail-label">გაყიდვა (Ex.VAT)</div>
            <div class="detail-value detail-revenue">${net_amount.toFixed(2)} ₾</div>
        </div>
        <div class="detail-item">
            <div class="detail-label">დღგ</div>
            <div class="detail-value detail-vat">${vat_amount.toFixed(2)} ₾</div>
        </div>
        <div class="detail-item">
            <div class="detail-label">ამონაგები</div>
            <div class="detail-value detail-profit">${profit.toFixed(2)} ₾</div>
        </div>
        <div class="detail-item">
            <div class="detail-label">მარჟა</div>
            <div class="detail-value detail-profit">${margin_percent.toFixed(1)}%</div>
        </div>
        <div class="detail-item">
            <div class="detail-label">ერთეულის მოგება</div>
            <div class="detail-value detail-profit">${currentSaleQuantity > 0 ? (profit / currentSaleQuantity).toFixed(2) : '0.00'} ₾</div>
        </div>
    `;
    
    $('#costDetailsGrid').html(html);
    $('#costDetailsSection').show();
}

// გაყიდვის დადასტურება
function confirmSale() {
    if (!currentSaleDishId) {
        alert('❌ გაყიდვის მონაცემები არ არის ხელმისაწვდომი');
        return;
    }
    
    const dish = window.dishes_js ? window.dishes_js.find(d => d.id == currentSaleDishId) : null;
    if (!dish) {
        alert('❌ კერძი ვერ მოიძებნა');
        return;
    }
    
    // დეტალური ინფორმაციის მომზადება
    const saleData = {
        dish_id: currentSaleDishId,
        quantity: currentSaleQuantity,
        dish_name: dish.name,
        unit_price: currentSalePrice,
        total_price: currentSalePrice * currentSaleQuantity
    };
    
    // დამატებითი ინფორმაცია ახალი ცხრილისთვის
    if (calculatedCostDetails && window.has_new_columns) {
        Object.assign(saleData, {
            cost_with_vat: calculatedCostDetails.cost_with_vat || 0,
            cost_excluding_vat: calculatedCostDetails.cost_excluding_vat || 0,
            net_amount: calculatedCostDetails.net_amount || 0,
            vat_amount: calculatedCostDetails.vat_amount || 0,
            profit: calculatedCostDetails.profit || 0,
            margin_percent: calculatedCostDetails.margin_percent || 0,
            total_with_vat: calculatedCostDetails.total_revenue || saleData.total_price,
            unit_cost_with_vat: currentSaleQuantity > 0 ? (calculatedCostDetails.cost_with_vat || 0) / currentSaleQuantity : 0,
            unit_cost_excluding_vat: currentSaleQuantity > 0 ? (calculatedCostDetails.cost_excluding_vat || 0) / currentSaleQuantity : 0,
            unit_profit: currentSaleQuantity > 0 ? (calculatedCostDetails.profit || 0) / currentSaleQuantity : 0
        });
    }
    
    const confirmMessage = `დაადასტურეთ ${currentSaleQuantity} ცალი "${dish.name}"-ის გაყიდვა?\n` +
                          `ჯამური ღირებულება: ${saleData.total_price.toFixed(2)} ₾\n` +
                          (calculatedCostDetails ? 
                           `თვითღირებულება: ${(calculatedCostDetails.cost_with_vat || 0).toFixed(2)} ₾\n` +
                           `მოგება: ${(calculatedCostDetails.profit || 0).toFixed(2)} ₾` : '');
    
    if (confirm(confirmMessage)) {
        $('#confirmSaleBtn').prop('disabled', true).text('⏳ მიმდინარეობს გაყიდვა...');
        
        console.log('Sending sale data:', saleData);
        
        $.ajax({
            url: 'ajax_process_sale.php',
            type: 'POST',
            data: saleData,
            dataType: 'json',
            success: function(response) {
                if (response.status === 1) {
                    let successMessage = '✅ კერძი წარმატებით გაიყიდა!';
                    
                    if (response.details) {
                        successMessage += `\n\nდეტალები:\n` +
                                        `თვითღირებულება: ${(response.details.cost?.cost_with_vat || 0).toFixed(2)} ₾\n` +
                                        `გაყიდვების შემოსავალი: ${(response.details.sale?.total_with_vat || 0).toFixed(2)} ₾\n` +
                                        `მოგება: ${(response.details.sale?.profit || 0).toFixed(2)} ₾\n` +
                                        `მარჟა: ${(response.details.sale?.margin_percent || 0).toFixed(1)}%`;
                    }
                    
                    alert(successMessage);
                    console.log('Sale successful:', response);
                    
                    closeSaleModal();
                    location.reload();
                } else {
                    let errorMessage = '❌ გაყიდვის შეცდომა: ' + (response.message || 'გაურკვეველი შეცდომა');
                    if (response.low_stock_items) {
                        errorMessage += '\n\nდეფიციტური პროდუქტები:';
                        response.low_stock_items.forEach(item => {
                            errorMessage += `\n- ${item.product_name || 'უსახელო'}: საჭიროა ${item.required || 0}, არის ${item.available || 0}`;
                        });
                    }
                    alert(errorMessage);
                    console.error('Sale error:', response);
                    $('#confirmSaleBtn').prop('disabled', false).text('✅ გაყიდვის დადასტურება');
                }
            },
            error: function(xhr, status, error) {
                console.error('AJAX Error:', error);
                alert('❌ შეცდომა სერვერთან კავშირში: ' + error);
                $('#confirmSaleBtn').prop('disabled', false).text('✅ გაყიდვის დადასტურება');
            }
        });
    }
}

// მოდალური ფანჯრის დახურვა
function closeSaleModal() {
    $('#saleModal').fadeOut();
    currentSaleDishId = null;
    currentSaleQuantity = 1;
    calculatedCostDetails = null;
}

// ============================================
// DOM Ready ფუნქცია
// ============================================

$(document).ready(function() {
    // კონსოლში დიაგნოსტიკური ინფორმაციის ჩვენება
    console.log('System Status:', {
        hasNewColumns: window.has_new_columns,
        hasMenuId: window.has_menu_id,
        salesColumns: window.sales_columns,
        dishesCount: window.dishes_js ? window.dishes_js.length : 0,
        productsCount: window.products_js ? window.products_js.length : 0
    });
    
    // კერძის რედაქტირების ევენთი
    $(document).on('click', '.editDish', function() {
        const row = $(this).closest('tr');
        const dishId = row.data('id');
        showDishForm(dishId);
    });
    
    // რეცეპტის ღილაკის ევენთი
    $(document).on('click', '.editCalc', function() {
        const row = $(this).closest('tr');
        const dishId = row.data('id');
        showDishRecipe(dishId);
    });
    
    // წაშლის ღილაკის ევენთი
    $(document).on('click', '.deleteDish', function() {
        const row = $(this).closest('tr');
        const dishId = row.data('id');
        const dishName = row.find('.cell-dname').text();
        deleteDish(dishId, dishName);
    });
    
    // გაყიდვის მოდალური ფანჯრის გახსნა
    $(document).on('click', '.btn-sell-dish', function() {
        const dishId = $(this).data('id');
        const dishName = $(this).data('name');
        const dishPrice = $(this).data('price');
        
        currentSaleDishId = dishId;
        currentSalePrice = parseFloat(dishPrice) || 0;
        currentSaleQuantity = 1;
        calculatedCostDetails = null;
        
        // მოდალური ფანჯრის შევსება
        $('#saleModalBody').html(`
            <div class="sale-form-group">
                <label>კერძი:</label>
                <input type="text" value="${dishName}" disabled style="background: #f8f9fa;">
            </div>
            
            <div class="sale-form-group">
                <label>რაოდენობა:</label>
                <div class="quantity-controls">
                    <button class="quantity-btn" onclick="changeSaleQuantity(-1)">-</button>
                    <input type="number" id="saleQuantity" class="quantity-input" value="1" min="1" step="1" onchange="updateSaleQuantity(this.value)">
                    <button class="quantity-btn" onclick="changeSaleQuantity(1)">+</button>
                </div>
            </div>
            
            <div class="sale-info-grid">
                <div class="info-item">
                    <div class="info-label">ერთეულის ფასი</div>
                    <div class="info-value">${currentSalePrice.toFixed(2)} ₾</div>
                </div>
                <div class="info-item">
                    <div class="info-label">ჯამური ფასი</div>
                    <div class="info-value" id="totalSalePrice">${currentSalePrice.toFixed(2)} ₾</div>
                </div>
                <div class="info-item">
                    <div class="info-label">დღგ (18%)</div>
                    <div class="info-value" id="vatAmount">${(currentSalePrice * 0.18).toFixed(2)} ₾</div>
                </div>
                <div class="info-item">
                    <div class="info-label">ფასი დღგ-ს გარეშე</div>
                    <div class="info-value" id="priceWithoutVat">${(currentSalePrice / 1.18).toFixed(2)} ₾</div>
                </div>
            </div>
            
            <div id="costDetailsSection" style="display: none;">
                <h4 style="margin-top: 0; color: #555; border-bottom: 1px solid #eee; padding-bottom: 8px;">💰 ღირებულების ანალიზი</h4>
                <div class="sale-details-grid" id="costDetailsGrid">
                    <!-- ღირებულების დეტალები აქ გამოჩნდება -->
                </div>
            </div>
            
            <div id="stockCheckResult" class="stock-check-list" style="display: none;">
                <!-- სტოკის შემოწმების შედეგი აქ გამოჩნდება -->
            </div>
            
            <div class="insufficient-stock" id="insufficientStockWarning">
                ⚠️ საკმარისი მარაგი არ არის ზოგიერთი ინგრედიენტისთვის!
            </div>
            
            <div class="modal-actions">
                <button class="btn btn-gray" onclick="closeSaleModal()">გაუქმება</button>
                <button class="btn btn-orange" id="confirmSaleBtn" onclick="confirmSale()" disabled>
                    ✅ გაყიდვის დადასტურება
                </button>
            </div>
            
            <div id="saleLoading" style="text-align: center; padding: 20px; display: none;">
                <div style="color: #666; margin-bottom: 10px;" id="loadingMessage">მარაგის შემოწმება...</div>
                <div style="width: 100%; height: 4px; background: #e9ecef; border-radius: 2px; overflow: hidden;">
                    <div id="progressBar" style="height: 100%; background: #007bff; width: 0%; transition: width 0.3s;"></div>
                </div>
            </div>
        `);
        
        // მოდალური ფანჯრის გამოჩენა
        $('#saleModal').fadeIn();
        
        // შეამოწმე მარაგი და გამოთვალე ღირებულება
        checkStockAndCalculateCost(dishId, 1);
    });
    
    // ESC კლავიშით მოდალური ფანჯრის დახურვა
    $(document).on('keydown', function(e) {
        if (e.keyCode === 27) {
            closeSaleModal();
        }
    });
    
    // მოდალური ფანჯრის გარეთ დაწკაპუნებაზე დახურვა
    $('#saleModal').on('click', function(e) {
        if (e.target === this) {
            closeSaleModal();
        }
    });
});