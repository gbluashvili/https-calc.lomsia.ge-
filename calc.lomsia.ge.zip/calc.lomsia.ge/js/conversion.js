/**
 * ერთეულების კონვერტაციის ფუნქციები
 */

const conversionRates = {
    // წონის ერთეულები
    'მგ': { 'კგ': 0.000001, 'გრ': 0.001 },
    'გრ': { 'კგ': 0.001, 'მგ': 1000 },
    'კგ': { 'გრ': 1000, 'მგ': 1000000 },
    
    // მოცულობის ერთეულები
    'მლ': { 'ლ': 0.001 },
    'ლ': { 'მლ': 1000 },
    
    // სიგრძის ერთეულები
    'სმ': { 'მ': 0.01 },
    'მ': { 'სმ': 100 },
    
    // სხვა
    'ცალი': { 'ცალი': 1 }
};

/**
 * ერთეულების კონვერტაცია
 * @param {number} value - მნიშვნელობა
 * @param {string} fromUnit - საწყისი ერთეული
 * @param {string} toUnit - საბოლოო ერთეული
 * @returns {number} - კონვერტირებული მნიშვნელობა
 */
function convertUnits(value, fromUnit, toUnit) {
    if (fromUnit === toUnit) return value;
    
    if (conversionRates[fromUnit] && conversionRates[fromUnit][toUnit]) {
        return value * conversionRates[fromUnit][toUnit];
    }
    
    // თუ პირდაპირი კონვერტაცია არ არის, შეეცადეთ შუალედური კონვერტაცია
    if (fromUnit === 'გრ' && toUnit === 'კგ') {
        return value * 0.001;
    }
    if (fromUnit === 'კგ' && toUnit === 'გრ') {
        return value * 1000;
    }
    if (fromUnit === 'მლ' && toUnit === 'ლ') {
        return value * 0.001;
    }
    if (fromUnit === 'ლ' && toUnit === 'მლ') {
        return value * 1000;
    }
    
    console.warn(`კონვერტაცია ${fromUnit}-დან ${toUnit}-ში არ არის განსაზღვრული`);
    return value;
}

/**
 * ავტომატური კონვერტაცია პროდუქტის საბაზისო ერთეულში
 * @param {number} value - მნიშვნელობა
 * @param {string} inputUnit - შეყვანის ერთეული
 * @param {string} baseUnit - პროდუქტის საბაზისო ერთეული
 * @returns {number} - კონვერტირებული მნიშვნელობა
 */
function convertToProductBaseUnit(value, inputUnit, baseUnit) {
    // თუ ერთეულები ერთი ტიპის არიან (წონა, მოცულობა, და ა.შ.)
    const unitTypes = {
        'მგ': 'weight', 'გრ': 'weight', 'კგ': 'weight',
        'მლ': 'volume', 'ლ': 'volume',
        'ცალი': 'piece'
    };
    
    const inputType = unitTypes[inputUnit];
    const baseType = unitTypes[baseUnit];
    
    if (inputType !== baseType) {
        alert(`⚠️ ერთეულები არ ემთხვევა: ${inputUnit} (${inputType}) და ${baseUnit} (${baseType})`);
        return null;
    }
    
    return convertUnits(value, inputUnit, baseUnit);
}

// ექსპორტი გლობალურად
window.convertUnits = convertUnits;
window.convertToProductBaseUnit = convertToProductBaseUnit;