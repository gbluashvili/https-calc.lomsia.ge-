
<script>
    const products_js = <?= json_encode($products) ?>;
    const dishes_js = <?= json_encode($dishes) ?>;
    const has_new_columns = <?= $has_new_columns ? 'true' : 'false' ?>;
    const sales_columns = <?= json_encode($sales_columns) ?>;
    
    let currentSaleDishId = null;
    let currentSaleQuantity = 1;
    let currentSalePrice = 0;
    let dishIngredients = {};
    let calculatedCostDetails = null; // შეინახავს თვითღირებულების დეტალებს
    
    // კონსოლში დიაგნოსტიკური ინფორმაციის ჩვენება
    console.log('System Status:', {
        hasNewColumns: has_new_columns,
        salesColumns: sales_columns,
        dishesCount: dishes_js.length,
        productsCount: products_js.length
    });
    
    function showDishForm() { 
        $('#new_d_name').val('');
        $('#new_d_price').val('');
        $('#saveNewDish').removeAttr('data-edit-id').text('✅ კერძის დამატება');
        $('#dishFormDiv').toggle(); 
    }
    
    // გაყიდვის მოდალური ფანჯრის გახსნა
    $(document).on('click', '.btn-sell-dish', function() {
        const dishId = $(this).data('id');
        const dishName = $(this).data('name');
        const dishPrice = $(this).data('price');
        
        currentSaleDishId = dishId;
        currentSalePrice = parseFloat(dishPrice);
        currentSaleQuantity = 1;
        calculatedCostDetails = null;
        
        // მოდალური ფანჯრის შევსება
        $('#saleModalBody').html(`
            <div class="sale-form-group">
                <label>კერძი:</label>
                <input type="text" value="${dishName}" disabled style="background: #f8f9fa;">
            </div>
            
            <div class="sale-form-group">
                <label>რაოდენობა:</label>
                <div class="quantity-controls">
                    <button class="quantity-btn" onclick="changeSaleQuantity(-1)">-</button>
                    <input type="number" id="saleQuantity" class="quantity-input" value="1" min="1" step="1" onchange="updateSaleQuantity(this.value)">
                    <button class="quantity-btn" onclick="changeSaleQuantity(1)">+</button>
                </div>
            </div>
            
            <div class="sale-info-grid">
                <div class="info-item">
                    <div class="info-label">ერთეულის ფასი</div>
                    <div class="info-value">${currentSalePrice.toFixed(2)} ₾</div>
                </div>
                <div class="info-item">
                    <div class="info-label">ჯამური ფასი</div>
                    <div class="info-value" id="totalSalePrice">${currentSalePrice.toFixed(2)} ₾</div>
                </div>
                <div class="info-item">
                    <div class="info-label">დღგ (18%)</div>
                    <div class="info-value" id="vatAmount">${(currentSalePrice * 0.18).toFixed(2)} ₾</div>
                </div>
                <div class="info-item">
                    <div class="info-label">ფასი დღგ-ს გარეშე</div>
                    <div class="info-value" id="priceWithoutVat">${(currentSalePrice / 1.18).toFixed(2)} ₾</div>
                </div>
            </div>
            
            <div id="costDetailsSection" style="display: none;">
                <h4 style="margin-top: 0; color: #555; border-bottom: 1px solid #eee; padding-bottom: 8px;">💰 ღირებულების ანალიზი</h4>
                <div class="sale-details-grid" id="costDetailsGrid">
                    <!-- ღირებულების დეტალები აქ გამოჩნდება -->
                </div>
            </div>
            
            <div id="stockCheckResult" class="stock-check-list" style="display: none;">
                <!-- სტოკის შემოწმების შედეგი აქ გამოჩნდება -->
            </div>
            
            <div class="insufficient-stock" id="insufficientStockWarning">
                ⚠️ საკმარისი მარაგი არ არის ზოგიერთი ინგრედიენტისთვის!
            </div>
            
            <div class="modal-actions">
                <button class="btn btn-gray" onclick="closeSaleModal()">გაუქმება</button>
                <button class="btn btn-orange" id="confirmSaleBtn" onclick="confirmSale()" disabled>
                    ✅ გაყიდვის დადასტურება
                </button>
            </div>
            
            <div id="saleLoading" style="text-align: center; padding: 20px; display: none;">
                <div style="color: #666; margin-bottom: 10px;" id="loadingMessage">მარაგის შემოწმება...</div>
                <div style="width: 100%; height: 4px; background: #e9ecef; border-radius: 2px; overflow: hidden;">
                    <div id="progressBar" style="height: 100%; background: #007bff; width: 0%; transition: width 0.3s;"></div>
                </div>
            </div>
        `);
        
        // მოდალური ფანჯრის გამოჩენა
        $('#saleModal').fadeIn();
        
        // შეამოწმე მარაგი და გამოთვალე ღირებულება
        checkStockAndCalculateCost(dishId, 1);
    });
    
    // გაყიდვის რაოდენობის შეცვლა ღილაკებით
    function changeSaleQuantity(change) {
        let newQuantity = currentSaleQuantity + change;
        if (newQuantity < 1) newQuantity = 1;
        
        currentSaleQuantity = newQuantity;
        $('#saleQuantity').val(newQuantity);
        updateSaleInfo();
        checkStockAndCalculateCost(currentSaleDishId, newQuantity);
    }
    
    // გაყიდვის რაოდენობის შეცვლა ინფუთიდან
    function updateSaleQuantity(value) {
        const quantity = parseInt(value) || 1;
        if (quantity < 1) return;
        
        currentSaleQuantity = quantity;
        updateSaleInfo();
        checkStockAndCalculateCost(currentSaleDishId, quantity);
    }
    
    // გაყიდვის ინფორმაციის განახლება
    function updateSaleInfo() {
        const totalPrice = currentSalePrice * currentSaleQuantity;
        const vat = totalPrice * 0.18;
        const priceWithoutVat = totalPrice / 1.18;
        
        $('#totalSalePrice').text(totalPrice.toFixed(2) + ' ₾');
        $('#vatAmount').text(vat.toFixed(2) + ' ₾');
        $('#priceWithoutVat').text(priceWithoutVat.toFixed(2) + ' ₾');
        
        // თუ ღირებულების დეტალები უკვე გამოთვლილია, განვაახლოთ
        if (calculatedCostDetails) {
            updateCostDetailsDisplay();
        }
    }
    
    // მარაგის შემოწმება და ღირებულების გამოთვლა ერთად
    function checkStockAndCalculateCost(dishId, quantity) {
        $('#saleLoading').show();
        $('#loadingMessage').text('მარაგის შემოწმება და ღირებულების გაანგარიშება...');
        $('#progressBar').css('width', '30%');
        
        // ვამზადებთ მონაცემებს
        var requestData = {
            dish_id: dishId,
            quantity: quantity,
            unit_price: currentSalePrice
        };
        
        console.log('Sending AJAX request with data:', requestData);
        
        $.ajax({
            url: 'ajax_check_and_calculate.php',
            type: 'POST',
            data: requestData,
            dataType: 'json',
            success: function(response) {
                console.log('AJAX response:', response);
                $('#progressBar').css('width', '100%');
                
                setTimeout(function() {
                    $('#saleLoading').hide();
                    $('#progressBar').css('width', '0%');
                    
                    if (response.status === 1) {
                        // მარაგის შედეგის ჩვენება
                        displayStockCheckResult(response.ingredients);
                        dishIngredients[dishId] = response.ingredients;
                        
                        // ღირებულების დეტალების შენახვა და ჩვენება
                        calculatedCostDetails = response.cost_details;
                        updateCostDetailsDisplay();
                        
                        // შეამოწმე არის თუ არა საკმარისი მარაგი
                        const hasInsufficient = response.ingredients.some(ing => !ing.has_enough);
                        $('#insufficientStockWarning').toggle(hasInsufficient);
                        $('#confirmSaleBtn').prop('disabled', hasInsufficient);
                    } else {
                        let errorMsg = response.message || 'გაურკვეველი შეცდომა';
                        if (response.debug) {
                            errorMsg += '\nDebug: ' + JSON.stringify(response.debug);
                        }
                        
                        $('#stockCheckResult').html(
                            `<div style="color: #dc3545; text-align: center; padding: 20px;">
                                <div>❌ შეცდომა</div>
                                <div style="font-size: 12px;">${errorMsg}</div>
                                <div style="font-size: 10px; color: #999; margin-top: 10px;">
                                    dish_id: ${dishId}<br>
                                    quantity: ${quantity}<br>
                                    unit_price: ${currentSalePrice}
                                </div>
                            </div>`
                        ).show();
                        $('#confirmSaleBtn').prop('disabled', true);
                    }
                }, 300);
            },
            error: function(xhr, status, error) {
                $('#saleLoading').hide();
                console.error('AJAX Error:', status, error, xhr.responseText);
                
                $('#stockCheckResult').html(
                    `<div style="color: #dc3545; text-align: center; padding: 20px;">
                        <div>❌ სერვერული შეცდომა</div>
                        <div style="font-size: 12px;">${error}</div>
                        <div style="font-size: 10px; color: #999; margin-top: 10px;">
                            Status: ${status}<br>
                            Response: ${xhr.responseText}
                        </div>
                    </div>`
                ).show();
                $('#confirmSaleBtn').prop('disabled', true);
            }
        });
    }
    
    // მარაგის შემოწმების შედეგის ჩვენება
    function displayStockCheckResult(ingredients) {
        let html = '<h4 style="margin-top: 0; color: #555;">მარაგის შემოწმება:</h4>';
        
        ingredients.forEach(ingredient => {
            const statusClass = ingredient.has_enough ? 'stock-ok' : 
                               ingredient.available_percentage >= 50 ? 'stock-low' : 'stock-critical';
            const statusText = ingredient.has_enough ? '✅ საკმარისია' : 
                              ingredient.available_percentage >= 50 ? '⚠️ დაბალია' : '❌ არ არის საკმარისი';
            
            html += `
                <div class="stock-item">
                    <div class="stock-item-name">${ingredient.product_name}</div>
                    <div class="stock-item-status ${statusClass}">
                        ${ingredient.required.toFixed(3)} ${ingredient.unit} / 
                        ${ingredient.available.toFixed(3)} ${ingredient.unit}
                        (${ingredient.available_percentage.toFixed(1)}%) - ${statusText}
                    </div>
                </div>
            `;
        });
        
        $('#stockCheckResult').html(html).show();
    }
    
    // ღირებულების დეტალების განახლება
    function updateCostDetailsDisplay() {
        if (!calculatedCostDetails) return;
        
        const cost_with_vat = calculatedCostDetails.cost_with_vat || 0;
        const cost_excluding_vat = calculatedCostDetails.cost_excluding_vat || 0;
        const total_revenue = calculatedCostDetails.total_revenue || (currentSalePrice * currentSaleQuantity);
        const net_amount = calculatedCostDetails.net_amount || (total_revenue / 1.18);
        const vat_amount = calculatedCostDetails.vat_amount || (total_revenue * 0.18);
        const profit = calculatedCostDetails.profit || (net_amount - cost_excluding_vat);
        const margin_percent = calculatedCostDetails.margin_percent || 
            (cost_excluding_vat > 0 ? (profit / cost_excluding_vat) * 100 : 0);
        
        let html = `
            <div class="detail-item">
                <div class="detail-label">თვითღირ. (დღგ-თი)</div>
                <div class="detail-value detail-cost">${cost_with_vat.toFixed(2)} ₾</div>
            </div>
            <div class="detail-item">
                <div class="detail-label">თვითღირ. (Ex.VAT)</div>
                <div class="detail-value detail-cost">${cost_excluding_vat.toFixed(2)} ₾</div>
            </div>
            <div class="detail-item">
                <div class="detail-label">გაყიდვა (დღგ-თი)</div>
                <div class="detail-value detail-revenue">${total_revenue.toFixed(2)} ₾</div>
            </div>
            <div class="detail-item">
                <div class="detail-label">გაყიდვა (Ex.VAT)</div>
                <div class="detail-value detail-revenue">${net_amount.toFixed(2)} ₾</div>
            </div>
            <div class="detail-item">
                <div class="detail-label">დღგ</div>
                <div class="detail-value detail-vat">${vat_amount.toFixed(2)} ₾</div>
            </div>
            <div class="detail-item">
                <div class="detail-label">ამონაგები</div>
                <div class="detail-value detail-profit">${profit.toFixed(2)} ₾</div>
            </div>
            <div class="detail-item">
                <div class="detail-label">მარჟა</div>
                <div class="detail-value detail-profit">${margin_percent.toFixed(1)}%</div>
            </div>
            <div class="detail-item">
                <div class="detail-label">ერთეულის მოგება</div>
                <div class="detail-value detail-profit">${currentSaleQuantity > 0 ? (profit / currentSaleQuantity).toFixed(2) : '0.00'} ₾</div>
            </div>
        `;
        
        $('#costDetailsGrid').html(html);
        $('#costDetailsSection').show();
    }
    
    // გაყიდვის დადასტურება
    function confirmSale() {
        if (!currentSaleDishId) return;
        
        const dish = dishes_js.find(d => d.id == currentSaleDishId);
        if (!dish) return;
        
        // დეტალური ინფორმაციის მომზადება
        const saleData = {
            dish_id: currentSaleDishId,
            quantity: currentSaleQuantity,
            dish_name: dish.name,
            unit_price: currentSalePrice,
            total_price: currentSalePrice * currentSaleQuantity
        };
        
        // დამატებითი ინფორმაცია ახალი ცხრილისთვის
        if (calculatedCostDetails && has_new_columns) {
            Object.assign(saleData, {
                cost_with_vat: calculatedCostDetails.cost_with_vat,
                cost_excluding_vat: calculatedCostDetails.cost_excluding_vat,
                net_amount: calculatedCostDetails.net_amount,
                vat_amount: calculatedCostDetails.vat_amount,
                profit: calculatedCostDetails.profit,
                margin_percent: calculatedCostDetails.margin_percent,
                total_with_vat: calculatedCostDetails.total_revenue,
                unit_cost_with_vat: currentSaleQuantity > 0 ? calculatedCostDetails.cost_with_vat / currentSaleQuantity : 0,
                unit_cost_excluding_vat: currentSaleQuantity > 0 ? calculatedCostDetails.cost_excluding_vat / currentSaleQuantity : 0,
                unit_profit: currentSaleQuantity > 0 ? calculatedCostDetails.profit / currentSaleQuantity : 0
            });
        }
        
        const confirmMessage = `დაადასტურეთ ${currentSaleQuantity} ცალი "${dish.name}"-ის გაყიდვა?\n` +
                              `ჯამური ღირებულება: ${saleData.total_price.toFixed(2)} ₾\n` +
                              (calculatedCostDetails ? 
                               `თვითღირებულება: ${calculatedCostDetails.cost_with_vat.toFixed(2)} ₾\n` +
                               `მოგება: ${calculatedCostDetails.profit.toFixed(2)} ₾` : '');
        
        if (confirm(confirmMessage)) {
            $('#confirmSaleBtn').prop('disabled', true).text('⏳ მიმდინარეობს გაყიდვა...');
            
            console.log('Sending sale data:', saleData);
            
            $.ajax({
                url: 'ajax_process_sale.php',
                type: 'POST',
                data: saleData,
                dataType: 'json',
                success: function(response) {
                    if (response.status === 1) {
                        let successMessage = '✅ კერძი წარმატებით გაიყიდა!';
                        
                        if (response.details) {
                            successMessage += `\n\nდეტალები:\n` +
                                            `თვითღირებულება: ${response.details.cost.cost_with_vat.toFixed(2)} ₾\n` +
                                            `გაყიდვების შემოსავალი: ${response.details.sale.total_with_vat.toFixed(2)} ₾\n` +
                                            `მოგება: ${response.details.sale.profit.toFixed(2)} ₾\n` +
                                            `მარჟა: ${response.details.sale.margin_percent.toFixed(1)}%`;
                        }
                        
                        alert(successMessage);
                        console.log('Sale successful:', response);
                        
                        closeSaleModal();
                        location.reload();
                    } else {
                        let errorMessage = '❌ გაყიდვის შეცდომა: ' + (response.message || 'გაურკვეველი შეცდომა');
                        if (response.low_stock_items) {
                            errorMessage += '\n\nდეფიციტური პროდუქტები:';
                            response.low_stock_items.forEach(item => {
                                errorMessage += `\n- ${item.product_name}: საჭიროა ${item.required}, არის ${item.available}`;
                            });
                        }
                        alert(errorMessage);
                        console.error('Sale error:', response);
                        $('#confirmSaleBtn').prop('disabled', false).text('✅ გაყიდვის დადასტურება');
                    }
                },
                error: function(xhr, status, error) {
                    console.error('AJAX Error:', error);
                    alert('❌ შეცდომა სერვერთან კავშირში: ' + error);
                    $('#confirmSaleBtn').prop('disabled', false).text('✅ გაყიდვის დადასტურება');
                }
            });
        }
    }
    
    // მოდალური ფანჯრის დახურვა
    function closeSaleModal() {
        $('#saleModal').fadeOut();
        currentSaleDishId = null;
        currentSaleQuantity = 1;
        calculatedCostDetails = null;
    }
    
    // ESC კლავიშით მოდალური ფანჯრის დახურვა
    $(document).on('keydown', function(e) {
        if (e.keyCode === 27) {
            closeSaleModal();
        }
    });
    
    // მოდალური ფანჯრის გარეთ დაწკაპუნებაზე დახურვა
    $('#saleModal').on('click', function(e) {
        if (e.target === this) {
            closeSaleModal();
        }
    });
    
    // ============================================
    // რეცეპტის ფუნქციონალის დამატება
    // ============================================
    
    // რეცეპტის ნახვის ფუნქცია
    function viewDishRecipe(dishId) {
        console.log('Recipe button clicked for dish ID:', dishId);
        
        $.ajax({
            url: 'ajax_get_dish_calc.php',
            type: 'GET',
            data: { dish_id: dishId },
            dataType: 'json',
            success: function(response) {
                console.log('Response:', response);
                
                if (response.status === 1) {
                    // შექმენი მოდალური ფანჯარა
                    const html = `
                        <div id="recipeModalOverlay" style="position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 1001; display: flex; align-items: center; justify-content: center;">
                            <div style="background: white; padding: 20px; border-radius: 10px; width: 90%; max-width: 800px; max-height: 80vh; overflow-y: auto;">
                                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                                    <h3 style="margin: 0;">📊 ${response.dish.name} - რეცეპტი</h3>
                                    <button onclick="$('#recipeModalOverlay').remove()" style="background: none; border: none; font-size: 24px; cursor: pointer;">&times;</button>
                                </div>
                                
                                <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 10px; margin-bottom: 20px;">
                                    <div style="background: #f8f9fa; padding: 15px; border-radius: 8px;">
                                        <div style="font-size: 12px; color: #666;">გასაყიდი ფასი</div>
                                        <div style="font-size: 18px; font-weight: bold;">${response.dish.sale_price.toFixed(2)} ₾</div>
                                    </div>
                                    <div style="background: #f8f9fa; padding: 15px; border-radius: 8px;">
                                        <div style="font-size: 12px; color: #666;">თვითღირებულება</div>
                                        <div style="font-size: 18px; font-weight: bold; color: #dc3545;">${response.summary.cost_summary.total_cost_with_vat.toFixed(2)} ₾</div>
                                    </div>
                                    <div style="background: #f8f9fa; padding: 15px; border-radius: 8px;">
                                        <div style="font-size: 12px; color: #666;">მოგება</div>
                                        <div style="font-size: 18px; font-weight: bold; color: #28a745;">${response.summary.profit_summary.profit_excluding_vat.toFixed(2)} ₾</div>
                                    </div>
                                    <div style="background: #f8f9fa; padding: 15px; border-radius: 8px;">
                                        <div style="font-size: 12px; color: #666;">მარჟა</div>
                                        <div style="font-size: 18px; font-weight: bold; color: #28a745;">${response.summary.profit_summary.margin_percent_excluding_vat}%</div>
                                    </div>
                                </div>
                                
                                <h4>ინგრედიენტები (${response.items.length})</h4>
                                <div style="max-height: 300px; overflow-y: auto;">
                                    <table style="width: 100%; border-collapse: collapse; margin-top: 10px;">
                                        <thead>
                                            <tr style="background: #6f42c1; color: white;">
                                                <th style="padding: 10px; text-align: left;">ინგრედიენტი</th>
                                                <th style="padding: 10px; text-align: left;">რაოდენობა</th>
                                                <th style="padding: 10px; text-align: left;">ერთეულის ფასი</th>
                                                <th style="padding: 10px; text-align: left;">ღირებულება</th>
                                                <th style="padding: 10px; text-align: left;">%</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            ${response.items.map(item => `
                                                <tr style="border-bottom: 1px solid #eee;">
                                                    <td style="padding: 10px;">${item.product_name}</td>
                                                    <td style="padding: 10px;">${item.quantity.toFixed(3)} ${item.unit}</td>
                                                    <td style="padding: 10px;">${item.product_details.price.toFixed(2)} ₾</td>
                                                    <td style="padding: 10px;">${item.cost_details.cost_with_vat.toFixed(2)} ₾</td>
                                                    <td style="padding: 10px;">${item.cost_details.cost_percentage || 0}%</td>
                                                </tr>
                                            `).join('')}
                                        </tbody>
                                    </table>
                                </div>
                                
                                <div style="margin-top: 20px; padding: 15px; background: #f8f9fa; border-radius: 8px;">
                                    <h5 style="margin-top: 0;">📈 ანალიზი:</h5>
                                    <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 10px;">
                                        <div>
                                            <div style="font-size: 12px; color: #666;">გაყიდვა დღგ-ს გარეშე:</div>
                                            <div>${response.summary.revenue_summary.revenue_excluding_vat.toFixed(2)} ₾</div>
                                        </div>
                                        <div>
                                            <div style="font-size: 12px; color: #666;">დღგ თანხა:</div>
                                            <div>${response.summary.revenue_summary.vat_on_revenue.toFixed(2)} ₾</div>
                                        </div>
                                        <div>
                                            <div style="font-size: 12px; color: #666;">თვითღირებულება დღგ-ს გარეშე:</div>
                                            <div>${response.summary.cost_summary.total_cost_excluding_vat.toFixed(2)} ₾</div>
                                        </div>
                                        <div>
                                            <div style="font-size: 12px; color: #666;">მომგებიანობა:</div>
                                            <div>${response.summary.profit_summary.profitability}%</div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div style="margin-top: 20px; text-align: center;">
                                    <button onclick="$('#recipeModalOverlay').remove()" style="background: #6f42c1; color: white; border: none; padding: 10px 20px; border-radius: 5px; cursor: pointer;">დახურვა</button>
                                </div>
                            </div>
                        </div>
                    `;
                    
                    // წაშალე ძველი მოდალი
                    $('#recipeModalOverlay').remove();
                    
                    // დამატე ახალი მოდალი
                    $('body').append(html);
                } else {
                    alert('შეცდომა: ' + response.message);
                }
            },
            error: function(xhr, status, error) {
                console.error('AJAX Error:', status, error, xhr.responseText);
                alert('სერვერული შეცდომა. გთხოვთ სცადოთ მოგვიანებით.');
            }
        });
    }
    
    // ღილაკებზე მიბმა
    $(document).on('click', '.editCalc', function() {
        const dishId = $(this).closest('tr').data('id');
        console.log('Recipe button clicked for dish ID:', dishId);
        viewDishRecipe(dishId);
    });
</script>