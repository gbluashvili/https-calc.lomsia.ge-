/**
 * მთავარი JavaScript ფაილი - მენიუს და ინვენტარის ფუნქციები
 */
var dishTable, productTable; // გლობალური ცვლადები

$(document).ready(function() {
    // ========================
    // 1. ცხრილების ინიციალიზაცია
    // ========================
    
    // პროდუქტების ცხრილი
    if ($('#productTable').length && !$.fn.DataTable.isDataTable('#productTable')) {
        productTable = $('#productTable').DataTable({
            "pageLength": 10,
            "lengthMenu": [10, 25, 50, 100],
            "language": {
                "url": "//cdn.datatables.net/plug-ins/1.11.5/i18n/ka.json"
            },
            "dom": '<"top"lf>rt<"bottom"ip><"clear">',
            "order": [[1, "asc"]]
        });
    }

    // მენიუს ცხრილი
    if ($('#dishTable').length && !$.fn.DataTable.isDataTable('#dishTable')) {
        dishTable = $('#dishTable').DataTable({
            "pageLength": 25,
            "lengthMenu": [10, 25, 50, 100],
            "language": {
                "url": "//cdn.datatables.net/plug-ins/1.11.5/i18n/ka.json"
            },
            "dom": '<"top"lf>rt<"bottom"ip><"clear">'
        });
    }

    // ========================
    // 2. კერძების მართვა
    // ========================
    
    // კერძის დამატება/რედაქტირება
    $('#saveNewDish').on('click', function() {
        let btn = $(this);
        let editId = btn.attr('data-edit-id') || 0;
        
        let data = {
            id: editId,
            name: $('#new_d_name').val(),
            price: $('#new_d_price').val()
        };

        if (!data.name) {
            alert('გთხოვთ შეიყვანოთ კერძის დასახელება');
            return;
        }

        $.post('ajax_save_dish.php', data, function(res) {
            if (res.status == 1) {
                location.reload();
            } else {
                alert(res.message);
            }
        }, 'json');
    });

    // კერძის რედაქტირება
    $(document).on('click', '.editDish', function() {
        let row = $(this).closest('tr');
        let dishId = row.data('id');
        
        showDishForm();
        $('#new_d_name').val(row.find('.cell-dname').text().trim());
        $('#new_d_price').val(parseFloat(row.find('.cell-dprice').text()) || 0);
        $('#saveNewDish').attr('data-edit-id', dishId).text('✅ ცვლილების შენახვა');
    });

    // კერძის წაშლა
    $(document).on('click', '.deleteDish', function() {
        let row = $(this).closest('tr');
        let dishId = row.data('id');
        let dishName = row.find('.cell-dname').text();

        if (confirm('ნამდვილად გსურთ წაშალოთ კერძი: ' + dishName + '?')) {
            $.ajax({
                url: 'ajax_delete_dish.php',
                type: 'POST',
                data: { id: dishId },
                dataType: 'json',
                success: function(res) {
                    if (res.status == 1) {
                        dishTable.row(row).remove().draw(false);
                        alert('✅ კერძი წაიშალა');
                    } else {
                        alert('❌ შეცდომა: ' + res.message);
                    }
                }
            });
        }
    });

    // ========================
    // 3. პროდუქტების მართვა
    // ========================
    
    // პროდუქტის რედაქტირება
    $(document).on('click', '.editProduct', function() {
        let row = $(this).closest('tr');
        let productId = row.data('id');
        
        showProductForm();
        $('#new_p_name').val(row.find('.cell-pname').text().trim());
        $('#new_p_unit').val(row.find('.cell-punit').text().trim());
        $('#new_p_qty').val(parseFloat(row.find('.cell-qty').text().replace(/,/g, '')) || 0);
        $('#new_p_price').val(parseFloat(row.find('.cell-pprice').text().replace(/[^\d.]/g, '')) || 0);
        $('#new_p_limit').val(parseFloat(row.find('.cell-plimit').text().trim()) || 1);
        
        $('#saveNewProduct').attr('data-edit-id', productId).text('✅ ცვლილების შენახვა');
        $('html, body').animate({ scrollTop: $("#productFormDiv").offset().top - 20 }, 500);
    });

    // პროდუქტის წაშლა
    $(document).on('click', '.deleteProduct', function() {
        let row = $(this).closest('tr');
        let productId = row.data('id');
        let productName = row.find('.cell-pname').text();

        if (confirm('ნამდვილად გსურთ წაშალოთ პროდუქტი: ' + productName + '?')) {
            $.ajax({
                url: 'ajax_delete_product.php',
                type: 'POST',
                data: { id: productId },
                dataType: 'json',
                success: function(res) {
                    if (res.status == 1) {
                        productTable.row(row).remove().draw(false);
                        alert('✅ პროდუქტი წაიშალა');
                    } else {
                        alert('❌ შეცდომა: ' + res.message);
                    }
                }
            });
        }
    });

    // პროდუქტის შენახვა
    $('#saveNewProduct').on('click', function() {
        let btn = $(this);
        let editId = btn.attr('data-edit-id') || 0;
        
        let data = {
            id: editId,
            name: $('#new_p_name').val(),
            unit: $('#new_p_unit').val(),
            quantity: $('#new_p_qty').val(),
            price: $('#new_p_price').val(),
            limit: $('#new_p_limit').val()
        };

        if(!data.name) {
            alert('გთხოვთ შეიყვანოთ პროდუქტის დასახელება');
            return;
        }

        $.post('ajax_save_product.php', data, function(res) {
            if (res.status == 1) {
                location.reload();
            } else {
                alert(res.message);
            }
        }, 'json');
    });

    // ავტომატური კალკულაცია პროდუქტის მართვის ფორმაში
    $(document).on('input', '#new_p_qty, #new_p_price', function() {
        let qty = parseFloat($('#new_p_qty').val()) || 0;
        let total = parseFloat($('#new_p_price').val()) || 0;
        let unit = $('#new_p_unit').val();

        if ($('#calc_hint_product').length === 0) {
            $('#saveNewProduct').before('<div id="calc_hint_product" style="display:none; background: #e3f2fd; border: 1px dashed #2196f3; padding: 10px; margin: 10px 0; text-align: center; color: #0d47a1; font-weight: bold; border-radius: 4px;"></div>');
        }

        if (qty > 0 && total > 0) {
            let unitPrice = (total / qty).toFixed(2);
            $('#calc_hint_product').stop().fadeIn().html(
                `📊 გაანგარიშება: 1 ${unit} პროდუქტი გამოდის ${unitPrice} ₾`
            );
        } else {
            $('#calc_hint_product').fadeOut();
        }
    });

    // ========================
    // 4. რეცეპტის მართვა
    // ========================
    
    // რეცეპტის გახსნა/დახურვა
    $(document).on('click', '.editCalc', function() {
        let tr = $(this).closest('tr');
        let row = dishTable.row(tr);
        let dishId = tr.data('id');
        let dishName = tr.find('.cell-dname').text();
        let salePrice = parseFloat(tr.find('.cell-dprice').text()) || 0;

        if (row.child.isShown()) {
            row.child.hide();
            tr.removeClass('shown');
        } else {
            row.child(generateRecipeTemplate(dishId, dishName, salePrice)).show();
            tr.addClass('shown');
            let container = tr.next().find('.calc-child-row');
            
            // მონაცემების წამოღება ბაზიდან
            $.getJSON('ajax_get_dish_calc.php', { dish_id: dishId }, function(res) {
                if (res.items && res.items.length > 0) {
                    res.items.forEach(function(item) {
                        addCalcRow(container, item.product_id, item.quantity, item.unit, item.yield_coeff, item.has_vat);
                    });
                } else {
                    addCalcRow(container);
                }
                updateTotal(container);
                
                // Select2 ინიციალიზაცია
                container.find('.p_sel').each(function() {
                    $(this).select2({
                        width: '150px',
                        dropdownParent: container
                    });
                });
            });
        }
    });

    // ავტომატური გადათვლა რეცეპტში
    $(document).on('input change', '.p_sel, .c_qty, .c_yield, .c_unit, .c_vat', function() {
        updateTotal($(this).closest('.calc-child-row'));
    });

    // რეცეპტის შენახვა
    $(document).on('click', '.saveCalcBtn', function() {
        let btn = $(this);
        let container = btn.closest('.calc-child-row');
        let dishId = container.data('dish-id');
        let items = [];

        container.find('tbody tr').each(function() {
            let row = $(this);
            let productId = row.find('.p_sel').val();
            
            if (productId > 0) {
                items.push({
                    product_id: productId,
                    quantity: row.find('.c_qty').val(),
                    unit: row.find('.c_unit').val(),
                    yield_coeff: row.find('.c_yield').val(),
                    has_vat: row.find('.c_vat').is(':checked') ? 1 : 0
                });
            }
        });

        if (items.length === 0) {
            alert('გთხოვთ დაამატოთ მინიმუმ ერთი ინგრედიენტი');
            return;
        }

        btn.prop('disabled', true).text('⏳ ინახება...');

        $.ajax({
            url: 'ajax_save_dish_calc.php',
            type: 'POST',
            data: {
                dish_id: dishId,
                items: JSON.stringify(items)
            },
            success: function(response) {
                if (response.status == 1) {
                    alert('✅ ' + response.message);
                } else {
                    alert('❌ შეცდომა: ' + response.message);
                }
            },
            error: function() {
                alert('❌ სერვერთან კავშირი ვერ დამყარდა');
            },
            complete: function() {
                btn.prop('disabled', false).text('რეცეპტის შენახვა');
            }
        });
    });

    // Select2 ინიციალიზაცია ახალი სტრიქონებისთვის
    $(document).on('click', '.btn.btn-green.btn-sm', function(e) {
        setTimeout(function() {
            let container = $(e.target).closest('.calc-child-row');
            container.find('.p_sel').last().select2({
                width: '150px',
                dropdownParent: container
            });
        }, 100);
    });

    // ========================
    // 5. მიღების ფორმის ფუნქციები
    // ========================
    
    $(document).on('input', '#pur_qty_pack, #pur_total_amount', function() {
        let qty = parseFloat($('#pur_qty_pack').val()) || 0;
        let total = parseFloat($('#pur_total_amount').val()) || 0;
        let unit = $('#unit_display').text() || 'ერთეული';

        if ($('#calc_hint').length === 0) {
            $('#savePurchase').before('<div id="calc_hint" style="display:none; background: #f0fff4; border: 1px dashed #28a745; padding: 10px; margin-bottom: 15px; text-align: center; color: #28a745; font-weight: bold; border-radius: 4px;"></div>');
        }

        if (qty > 0 && total > 0) {
            let unitPrice = (total / qty).toFixed(2);
            $('#calc_hint').stop().fadeIn().html(
                `💡 გაანგარიშება: 1 ${unit} დაგიჯდათ ${unitPrice} ₾`
            );
        } else {
            $('#calc_hint').fadeOut();
        }
    });

    $('#pur_product_id').on('change', function() {
        let unit = $(this).find(':selected').data('unit') || '...';
        $('#unit_display').text(unit);
    });

    // ========================
    // 6. ახალი: მიღების შენახვა
    // ========================
    
    $('#savePurchase').on('click', function() {
        let productId = $('#pur_product_id').val();
        let quantity = parseFloat($('#pur_qty_pack').val()) || 0;
        let totalAmount = parseFloat($('#pur_total_amount').val()) || 0;
        let supplier = $('#pur_supplier').val();

        if (productId == 0 || quantity <= 0 || totalAmount <= 0) {
            alert('გთხოვთ შეავსოთ ყველა სავალდებულო ველი');
            return;
        }

        // ღილაკის დროებითი დაბლოკვა
        $(this).prop('disabled', true).text('⏳ ინახება...');

        $.ajax({
            url: 'ajax_save_purchase.php',
            type: 'POST',
            data: {
                product_id: productId,
                quantity: quantity,
                total_amount: totalAmount,
                supplier: supplier
            },
            dataType: 'json',
            success: function(res) {
                if (res.status == 1) {
                    alert('✅ მიღება წარმატებით შეინახა');
                    location.reload();
                } else {
                    alert('❌ შეცდომა: ' + res.message);
                }
            },
            error: function() {
                alert('❌ სერვერთან კავშირი ვერ დამყარდა');
            },
            complete: function() {
                $('#savePurchase').prop('disabled', false).text('✅ მიღების შენახვა');
            }
        });
    });

    // ========================
    // 7. ახალი: ჩამოწერის შენახვა
    // ========================
    
    $('#saveWaste').on('click', function() {
        let productId = $('#waste_product_id').val();
        let quantity = parseFloat($('#waste_qty').val()) || 0;
        let reason = $('#waste_reason').val();
        let note = $('#waste_note').val();

        if (productId == 0 || quantity <= 0) {
            alert('გთხოვთ შეავსოთ ყველა სავალდებულო ველი');
            return;
        }

        // ღილაკის დროებითი დაბლოკვა
        $(this).prop('disabled', true).text('⏳ ინახება...');

        $.ajax({
            url: 'ajax_save_waste.php',
            type: 'POST',
            data: {
                product_id: productId,
                quantity: quantity,
                reason: reason,
                note: note
            },
            dataType: 'json',
            success: function(res) {
                if (res.status == 1) {
                    alert('✅ ჩამოწერა წარმატებით შეინახა');
                    location.reload();
                } else {
                    alert('❌ შეცდომა: ' + res.message);
                }
            },
            error: function() {
                alert('❌ სერვერთან კავშირი ვერ დამყარდა');
            },
            complete: function() {
                $('#saveWaste').prop('disabled', false).text('✅ ჩამოწერის შენახვა');
            }
        });
    });
    
    // ========================
    // 8. ახალი: ბრუნვის ბმულების აქტივაცია
    // ========================
    $('.nav-item').hover(
        function() {
            $(this).css('transform', 'translateY(-5px)');
        },
        function() {
            $(this).css('transform', 'translateY(0)');
        }
    );
});

// ========================
// გლობალური ფუნქციები
// ========================

function showProductForm() {
    $('#productFormTitle').text('📦 ახალი პროდუქტი');
    $('#new_p_name').val('');
    $('#new_p_qty').val('');
    $('#new_p_price').val('');
    $('#new_p_limit').val('1');
    $('#productFormDiv').toggle();
    
    if ($('#calc_hint_product').length > 0) {
        $('#calc_hint_product').hide();
    }
    
    $('#saveNewProduct').removeAttr('data-edit-id').text('✅ პროდუქტის ბაზაში შენახვა');
}

function showDishForm() {
    $('#new_d_name').val('');
    $('#new_d_price').val('');
    $('#saveNewDish').removeAttr('data-edit-id').text('✅ კერძის დამატება');
    $('#dishFormDiv').toggle();
}

// ========================
// რეცეპტის კალკულაციის ფუნქციები
// ========================

function updateTotal(container) {
    let totalVAT = 0, totalExVAT = 0;
    let salePrice = parseFloat(container.data('sale-price')) || 0;

    container.find('tbody tr').each(function() {
        let row = $(this);
        let pricePerUnit = parseFloat(row.find('.p_sel option:selected').data('price')) || 0;
        let netQty = parseFloat(row.find('.c_qty').val()) || 0;
        let yieldPct = parseFloat(row.find('.c_yield').val()) || 0;
        let hasVat = row.find('.c_vat').is(':checked');
        let unit = row.find('.c_unit').val();

        // რაოდენობის კონვერტაცია (გრ -> კგ)
        let net = (unit === 'გრ') ? netQty / 1000 : netQty;
        
        // Gross (ბრუტო) რაოდენობის გამოთვლა
        let gross = (yieldPct > 0 && yieldPct < 1) ? net / yieldPct : net;
        
        // ექსელის ფორმულის იდენტური ლოგიკა
        let rowTotalWithVAT;
        if (hasVat) {
            rowTotalWithVAT = pricePerUnit * gross;
        } else {
            rowTotalWithVAT = (pricePerUnit * 1.18) * gross;
        }

        let rowTotalExVAT = rowTotalWithVAT / 1.18;

        // მნიშვნელობების გამოტანა ცხრილში
        row.find('.c_gross').text(gross.toFixed(3));
        row.find('.c_unit_price').text(pricePerUnit.toFixed(2));
        row.find('.c_row_total').text(rowTotalWithVAT.toFixed(3));
        
        totalVAT += rowTotalWithVAT;
        totalExVAT += rowTotalExVAT;
    });

    // გაყიდვის ფასი დღგ-ს გარეშე
    let saleExVAT = salePrice / 1.18;
    let profit = saleExVAT - totalExVAT;
    let margin = saleExVAT > 0 ? (profit / saleExVAT) * 100 : 0;

    // ვიზუალური განახლება
    container.find('.totalCost').text(totalVAT.toFixed(2));
    container.find('.totalCostExVAT').text(totalExVAT.toFixed(2));
    container.find('.profitVal').text(profit.toFixed(2));
    container.find('.marginPct').text(margin.toFixed(1) + "%");
}

function generateRecipeTemplate(id, name, price) {
    return `
    <div class="calc-child-row" data-dish-id="${id}" data-sale-price="${price}">
        <div class="excel-summary-grid" style="display:flex; gap:15px; background:#f0f2f5; padding:15px; border-radius:8px; border:1px solid #ccc; margin-bottom:15px;">
            <div class="summary-box">თვითღირ. (დღგ-თი): <b class="totalCost">0.00</b> ₾</div>
            <div class="summary-box">თვითღირ. (Ex.VAT): <span class="totalCostExVAT">0.00</span> ₾</div>
            <div class="summary-box">ამონაგები (მოგება): <b class="profitVal" style="color:green">0.00</b> ₾</div>
            <div class="summary-box">მარჟა %: <b class="marginPct" style="color:blue">0%</b></div>
        </div>
        <table class="display compact custom-calc-table" style="width:100%">
            <thead>
                <tr>
                    <th>ინგრედიენტი</th><th>Net (სუფთა)</th><th>ერთ.</th><th>Yield</th>
                    <th>Gross (საწყობი)</th><th>ფასი</th><th>დღგ-თი?</th><th>ჯამი</th><th></th>
                </tr>
            </thead>
            <tbody></tbody>
        </table>
        <div style="margin-top:10px;">
            <button class="btn btn-green btn-sm" onclick="addCalcRow(this)">+ ინგრედიენტი</button>
            <button class="btn btn-blue btn-sm saveCalcBtn">რეცეპტის შენახვა</button>
        </div>
    </div>`;
}

function addCalcRow(btnOrContainer, pid = 0, qty = 0, unit = 'კგ', yieldVal = 1, hasVat = 1) {
    let container = $(btnOrContainer).hasClass('calc-child-row') 
        ? $(btnOrContainer) 
        : $(btnOrContainer).closest('.calc-child-row');
    
    let options = '<option value="0">-- აირჩიე --</option>';
    if (typeof products_js !== 'undefined') {
        products_js.forEach(function(p) {
            let selected = p.id == pid ? 'selected' : '';
            options += `<option value="${p.id}" data-price="${p.price}" ${selected}>${p.name}</option>`;
        });
    }

    let row = `<tr>
        <td><select class="p_sel" style="width:150px;">${options}</select></td>
        <td><input type="number" class="c_qty" value="${qty}" step="0.001" style="width:70px;"></td>
        <td>
            <select class="c_unit">
                <option value="კგ" ${unit == 'კგ' ? 'selected' : ''}>კგ</option>
                <option value="გრ" ${unit == 'გრ' ? 'selected' : ''}>გრ</option>
                <option value="ცალი" ${unit == 'ცალი' ? 'selected' : ''}>ცალი</option>
                <option value="ლიტრი" ${unit == 'ლიტრი' ? 'selected' : ''}>ლიტრი</option>
            </select>
        </td>
        <td><input type="number" class="c_yield" value="${yieldVal}" step="0.01" style="width:50px;"></td>
        <td class="c_gross" style="color:blue; font-weight:bold;">0.000</td>
        <td class="c_unit_price">0.00</td>
        <td><input type="checkbox" class="c_vat" ${hasVat == 1 ? 'checked' : ''}></td>
        <td class="c_row_total" style="font-weight:bold;">0.00</td>
        <td><button class="btn btn-red btn-sm" onclick="$(this).closest('tr').remove(); updateTotal($(this).closest('.calc-child-row'));">✖</button></td>
    </tr>`;
    
    container.find('tbody').append(row);
    
    // Select2 ინიციალიზაცია ახალი სტრიქონისთვის
    setTimeout(function() {
        container.find('.p_sel').last().select2({
            width: '150px',
            dropdownParent: container
        });
    }, 50);
}

// ========================
// 9. გაყიდვების ისტორია
// ========================

function recordSale(productId, productName, quantity, unit, unitPrice, totalPrice, comment = '') {
    $.ajax({
        url: 'ajax_record_sale.php',
        type: 'POST',
        data: {
            product_id: productId,
            product_name: productName,
            quantity: quantity,
            unit: unit,
            unit_price: unitPrice,
            total_price: totalPrice,
            comment: comment
        },
        dataType: 'json',
        success: function(res) {
            // მხოლოდ დეველოპმენტისთვის
            if (res.status != 1) {
                console.error('გაყიდვის ჩაწერის შეცდომა:', res.message);
            }
        },
        error: function() {
            console.error('გაყიდვის ჩაწერის სერვერული შეცდომა');
        }
    });
}