<?php
// /home/mvpuufsr/calc/calc.lomsia.ge/admin/process_login.php

session_start();
require_once __DIR__ . '/../config/db.php';

// დავაყენოთ JSON ჰედერი
header('Content-Type: application/json');

// მიღებული მონაცემები
$username = trim($_POST['username'] ?? '');
$password = $_POST['password'] ?? '';
$redirect = $_POST['redirect'] ?? 'index.php';

// ვალიდაცია
if (empty($username) || empty($password)) {
    echo json_encode([
        'status' => 'error',
        'message' => 'გთხოვთ შეავსოთ ყველა ველი'
    ]);
    exit();
}

// მოძებნეთ მომხმარებელი
$sql = "SELECT * FROM users WHERE (username = ? OR email = ?) AND is_active = 1";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ss", $username, $username);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 1) {
    $user = $result->fetch_assoc();
    
    // შეამოწმეთ პაროლი
    if (password_verify($password, $user['password_hash'])) {
        // წარმატებული ავტორიზაცია
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['full_name'] = $user['full_name'];
        $_SESSION['email'] = $user['email'];
        $_SESSION['user_role'] = $user['role'];
        
        // განაახლეთ ბოლო აქტივობა
        $updateSql = "UPDATE users SET last_login = NOW() WHERE id = ?";
        $updateStmt = $conn->prepare($updateSql);
        $updateStmt->bind_param("i", $user['id']);
        $updateStmt->execute();
        
        echo json_encode([
            'status' => 'success',
            'message' => 'წარმატებით შეხვედით სისტემაში',
            'redirect' => $redirect
        ]);
    } else {
        echo json_encode([
            'status' => 'error',
            'message' => 'არასწორი მომხმარებელი ან პაროლი'
        ]);
    }
} else {
    echo json_encode([
        'status' => 'error',
        'message' => 'არასწორი მომხმარებელი ან პაროლი'
    ]);
}

$conn->close();
?>