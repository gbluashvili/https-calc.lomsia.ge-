<?php
// /home/mvpuufsr/calc/calc.lomsia.ge/admin/add_permissions_column.php
require_once __DIR__ . '/../config/db.php';

// შევამოწმოთ ადმინისტრატორია თუ არა
session_start();
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_role']) || 
    ($_SESSION['user_role'] !== 'admin' && $_SESSION['user_role'] !== 'super_admin')) {
    header('Location: login.php');
    exit();
}

echo '<!DOCTYPE html>
<html lang="ka">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ბაზის განახლება</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }
        .container { max-width: 800px; margin: 0 auto; background: white; padding: 30px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .success { color: green; background: #d4edda; padding: 10px; border-radius: 5px; margin: 10px 0; }
        .error { color: red; background: #f8d7da; padding: 10px; border-radius: 5px; margin: 10px 0; }
        .info { color: #0c5460; background: #d1ecf1; padding: 10px; border-radius: 5px; margin: 10px 0; }
        .btn { display: inline-block; padding: 10px 20px; background: #007bff; color: white; text-decoration: none; border-radius: 5px; margin-top: 20px; }
        .btn:hover { background: #0056b3; }
        ul { list-style-type: none; padding-left: 0; }
        li { padding: 5px 0; border-bottom: 1px solid #eee; }
    </style>
</head>
<body>
    <div class="container">
        <h2>🛠️ ბაზის განახლება - წვდომების სისტემა</h2>';

// შევამოწმოთ არსებული სვეტი
$check_sql = "SHOW COLUMNS FROM users LIKE 'permissions'";
$check_result = $conn->query($check_sql);

if ($check_result->num_rows == 0) {
    echo '<div class="info">ℹ️ \'permissions\' სვეტი არ არსებობს, დამატების პროცესი იწყება...</div>';
    
    // 1. დავამატოთ სვეტი
    echo '<h3>📋 1. სვეტის დამატება</h3>';
    $alter_sql = "ALTER TABLE users ADD COLUMN permissions VARCHAR(2000) DEFAULT '[]'";
    
    if ($conn->query($alter_sql)) {
        echo '<div class="success">✅ \'permissions\' სვეტი წარმატებით დაემატა!</div>';
        
        // 2. არსებული მომხმარებლების განახლება
        echo '<h3>👥 2. მომხმარებლების განახლება</h3>';
        $users_sql = "SELECT id, role, username FROM users";
        $users_result = $conn->query($users_sql);
        $updated_count = 0;
        $error_count = 0;
        
        echo '<ul>';
        while ($user = $users_result->fetch_assoc()) {
            $permissions = getDefaultPermissionsByRole($user['role']);
            $permissions_json = json_encode($permissions, JSON_UNESCAPED_UNICODE);
            
            // Escape special characters for SQL
            $permissions_json_escaped = $conn->real_escape_string($permissions_json);
            
            $update_sql = "UPDATE users SET permissions = '$permissions_json_escaped' WHERE id = {$user['id']}";
            
            if ($conn->query($update_sql)) {
                echo '<li>✅ მომხმარებელი #' . $user['id'] . ' (@' . $user['username'] . ', როლი: ' . $user['role'] . ') - განახლდა</li>';
                $updated_count++;
            } else {
                echo '<li class="error">❌ მომხმარებელი #' . $user['id'] . ': ' . $conn->error . '</li>';
                $error_count++;
            }
        }
        echo '</ul>';
        
        echo '<h3>📊 შედეგები</h3>';
        echo '<div class="success">✅ წარმატებით განახლდა: ' . $updated_count . ' მომხმარებელი</div>';
        if ($error_count > 0) {
            echo '<div class="error">❌ შეცდომების რაოდენობა: ' . $error_count . '</div>';
        }
        
        // 3. შევამოწმოთ განახლება
        echo '<h3>🔍 3. განახლების შემოწმება</h3>';
        $test_sql = "SELECT COUNT(*) as total_users, 
                    SUM(CASE WHEN permissions IS NOT NULL AND permissions != '[]' THEN 1 ELSE 0 END) as updated_users 
                    FROM users";
        $test_result = $conn->query($test_sql);
        $test_data = $test_result->fetch_assoc();
        
        echo '<div class="info">';
        echo 'სულ მომხმარებლები: ' . $test_data['total_users'] . '<br>';
        echo 'განახლებული მომხმარებლები: ' . $test_data['updated_users'] . '<br>';
        echo 'წვდომების სისტემა მზად არის გამოსაყენებლად!';
        echo '</div>';
        
        echo '<br><div class="success">🎉 ყველაფერი წარმატებით დასრულდა!</div>';
        echo '<a href="admin_panel.php" class="btn">← დაბრუნება ადმინ პანელში</a>';
        
    } else {
        echo '<div class="error">❌ შეცდომა სვეტის დამატებისას: ' . $conn->error . '</div>';
        echo '<p>შეგიძლიათ ხელით გაუშვათ SQL ბრძანება:</p>';
        echo '<pre>ALTER TABLE users ADD COLUMN permissions VARCHAR(2000) DEFAULT \'[]\';</pre>';
        echo '<a href="admin_panel.php" class="btn">← დაბრუნება</a>';
    }
} else {
    echo '<div class="info">ℹ️ \'permissions\' სვეტი უკვე არსებობს</div>';
    
    // შევამოწმოთ რამდენი მომხმარებელია განახლებული
    $stats_sql = "SELECT COUNT(*) as total_users, 
                 SUM(CASE WHEN permissions IS NOT NULL AND permissions != '[]' THEN 1 ELSE 0 END) as updated_users,
                 SUM(CASE WHEN permissions IS NULL OR permissions = '[]' THEN 1 ELSE 0 END) as unupdated_users
                 FROM users";
    $stats_result = $conn->query($stats_sql);
    $stats_data = $stats_result->fetch_assoc();
    
    echo '<h3>📊 სისტემის სტატუსი</h3>';
    echo '<div class="info">';
    echo 'სულ მომხმარებლები: ' . $stats_data['total_users'] . '<br>';
    echo 'განახლებული მომხმარებლები: ' . $stats_data['updated_users'] . '<br>';
    echo 'არაგანახლებული მომხმარებლები: ' . $stats_data['unupdated_users'] . '<br>';
    echo '</div>';
    
    // თუ არის არაგანახლებული მომხმარებლები, შევთავაზოთ განახლება
    if ($stats_data['unupdated_users'] > 0) {
        echo '<h3>🔄 არაგანახლებული მომხმარებლები</h3>';
        echo '<form method="POST">';
        echo '<input type="hidden" name="update_users" value="1">';
        echo '<p>აღმოჩენილია ' . $stats_data['unupdated_users'] . ' მომხმარებელი წვდომების გარეშე.</p>';
        echo '<button type="submit" style="padding: 10px 20px; background: #28a745; color: white; border: none; border-radius: 5px; cursor: pointer;">განაახლე მომხმარებლები</button>';
        echo '</form>';
    }
    
    echo '<a href="admin_panel.php" class="btn">← დაბრუნება ადმინ პანელში</a>';
}

// განაახლეთ მომხმარებლები POST მოთხოვნით
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_users'])) {
    echo '<h3>🔄 მომხმარებლების განახლება</h3>';
    
    // იპოვეთ მომხმარებლები წვდომების გარეშე
    $unupdated_sql = "SELECT id, role, username FROM users WHERE permissions IS NULL OR permissions = '[]'";
    $unupdated_result = $conn->query($unupdated_sql);
    $updated_count = 0;
    
    echo '<ul>';
    while ($user = $unupdated_result->fetch_assoc()) {
        $permissions = getDefaultPermissionsByRole($user['role']);
        $permissions_json = json_encode($permissions, JSON_UNESCAPED_UNICODE);
        
        // Escape special characters for SQL
        $permissions_json_escaped = $conn->real_escape_string($permissions_json);
        
        $update_sql = "UPDATE users SET permissions = '$permissions_json_escaped' WHERE id = {$user['id']}";
        
        if ($conn->query($update_sql)) {
            echo '<li>✅ მომხმარებელი #' . $user['id'] . ' (@' . $user['username'] . ') - განახლდა</li>';
            $updated_count++;
        } else {
            echo '<li class="error">❌ მომხმარებელი #' . $user['id'] . ': ' . $conn->error . '</li>';
        }
    }
    echo '</ul>';
    
    echo '<div class="success">✅ განახლდა: ' . $updated_count . ' მომხმარებელი</div>';
    echo '<a href="add_permissions_column.php" class="btn">↻ ხელახლა შემოწმება</a>';
}

echo '</div></body></html>';

function getDefaultPermissionsByRole($role) {
    $pages = [
        'public/index.php' => 'მთავარი გვერდი',
        'public/warehouse.php' => 'საწყობი',
        'public/menu.php' => 'მენიუ',
        'public/analytics.php' => 'ანალიტიკა',
        'public/sales_history.php' => 'გაყიდვების ისტორია',
        'public/reports.php' => 'ანგარიშები',
        'public/money_movement.php' => 'ფულადი ოპერაციები',
        'admin/admin_panel.php' => 'ადმინ პანელი'
    ];
    
    $rolePermissions = [
        'admin' => array_keys($pages), // ყველა გვერდი
        'super_admin' => array_keys($pages), // ყველა გვერდი
        'manager' => ['public/index.php', 'public/warehouse.php', 'public/menu.php', 'public/analytics.php', 
                     'public/sales_history.php', 'public/reports.php', 'public/money_movement.php'],
        'chef' => ['public/index.php', 'public/menu.php'],
        'warehouse' => ['public/index.php', 'public/warehouse.php'],
        'user' => ['public/index.php'],
        'custom' => ['public/index.php']
    ];
    
    $permissions = [];
    if (isset($rolePermissions[$role])) {
        foreach ($rolePermissions[$role] as $page) {
            $permissions[$page] = true;
        }
    } else {
        // Default - მხოლოდ მთავარ გვერდზე წვდომა
        $permissions['public/index.php'] = true;
    }
    
    return $permissions;
}
// ... არსებული კოდი ...

function getDefaultPermissionsByRole($role) {
    $pages = [
        'public/index.php' => 'მთავარი გვერდი',
        'public/warehouse.php' => 'საწყობი',
        'public/menu.php' => 'მენიუ',
        'public/analytics.php' => 'ანალიტიკა',
        'public/sales_history.php' => 'გაყიდვების ისტორია',
        'public/reports.php' => 'ანგარიშები',
        'public/money_movement.php' => 'ფულადი ოპერაციები'
    ];
    
    $rolePermissions = [
        'admin' => array_merge(array_keys($pages), ['admin/admin_panel.php']), // ყველა გვერდი + ადმინ პანელი
        'super_admin' => array_merge(array_keys($pages), ['admin/admin_panel.php']), // ყველა გვერდი + ადმინ პანელი
        'manager' => ['public/index.php', 'public/warehouse.php', 'public/menu.php', 'public/analytics.php', 
                     'public/sales_history.php', 'public/reports.php', 'public/money_movement.php'],
        'chef' => ['public/index.php', 'public/menu.php'],
        'warehouse' => ['public/index.php', 'public/warehouse.php'],
        'user' => ['public/index.php'],
        'custom' => ['public/index.php']
    ];
    
    $permissions = [];
    if (isset($rolePermissions[$role])) {
        foreach ($rolePermissions[$role] as $page) {
            $permissions[$page] = true;
        }
    } else {
        // Default - მხოლოდ მთავარ გვერდზე წვდომა
        $permissions['public/index.php'] = true;
    }
    
    return $permissions;
}
?>
?>