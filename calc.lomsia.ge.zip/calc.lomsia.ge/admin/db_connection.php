<?php
// /home/mvpuufsr/calc/calc.lomsia.ge/admin/db_connection.php

// სესიის დაწყება (უნდა იყოს პირველი)
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// config/db.php გზა
$configPath = dirname(__DIR__) . '/config/db.php';

if (!file_exists($configPath)) {
    die("Database configuration file not found.");
}

// ჩატვირთეთ კონფიგურაცია
require_once $configPath;

// შეამოწმეთ რომ $conn ცვლადი არსებობს
if (!isset($conn) || !($conn instanceof mysqli)) {
    die("Database connection not established properly.");
}
?>