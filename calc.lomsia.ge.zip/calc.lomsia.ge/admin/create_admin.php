<?php
// /home/mvpuufsr/calc/calc.lomsia.ge/admin/create_admin.php

// ჩართეთ კონფიგურაცია
require_once __DIR__ . '/../config/db.php';

// პაროლის გენერაცია - მარტივი პაროლი რომელიც გვახსოვს
$password = 'Admin123';
$hashed_password = password_hash($password, PASSWORD_BCRYPT);

echo "<h1>ადმინისტრატორის შექმნა</h1>";
echo "<p>გენერირებული პაროლი: <strong>$password</strong></p>";
echo "<p>ჰეშირებული პაროლი: <code>$hashed_password</code></p>";

// შეამოწმეთ არსებული მომხმარებლები
$check_sql = "SELECT id, username, email, role FROM users";
$result = $conn->query($check_sql);

if ($result && $result->num_rows > 0) {
    echo "<h3>არსებული მომხმარებლები:</h3>";
    echo "<table border='1' cellpadding='5'>";
    echo "<tr><th>ID</th><th>Username</th><th>Email</th><th>Role</th></tr>";
    
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row['id'] . "</td>";
        echo "<td>" . htmlspecialchars($row['username']) . "</td>";
        echo "<td>" . htmlspecialchars($row['email']) . "</td>";
        echo "<td>" . htmlspecialchars($row['role']) . "</td>";
        echo "</tr>";
    }
    echo "</table>";
}

// შექმენით ახალი ადმინისტრატორი
if (isset($_GET['create'])) {
    // ჯერ შევამოწმოთ არის თუ არა უკვე admin
    $admin_check = $conn->query("SELECT id FROM users WHERE username = 'admin'");
    
    if ($admin_check && $admin_check->num_rows > 0) {
        echo "<p style='color: orange;'>მომხმარებელი 'admin' უკვე არსებობს!</p>";
    } else {
        $username = 'admin';
        $email = 'admin@lomsia.ge';
        $full_name = 'სისტემის ადმინისტრატორი';
        $phone = '';
        
        $sql = "INSERT INTO users (username, email, password_hash, full_name, phone, role, is_active, created_at) 
                VALUES (?, ?, ?, ?, ?, 'admin', 1, NOW())";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sssss", $username, $email, $hashed_password, $full_name, $phone);
        
        if ($stmt->execute()) {
            echo "<p style='color: green; font-size: 18px;'>✅ ადმინისტრატორი წარმატებით შეიქმნა!</p>";
            echo "<p><strong>მომხმარებელი:</strong> admin</p>";
            echo "<p><strong>პაროლი:</strong> $password</p>";
            echo "<p><strong>ელ-ფოსტა:</strong> $email</p>";
        } else {
            echo "<p style='color: red;'>შეცდომა: " . $conn->error . "</p>";
        }
    }
}

echo "<hr>";
echo "<h3>ქმედებები:</h3>";
echo "<ul>";
echo "<li><a href='?create=1'>შექმენით ახალი ადმინისტრატორი (admin/Admin123)</a></li>";
echo "<li><a href='login.php'>გადადით ლოგინის გვერდზე</a></li>";
echo "<li><a href='test_login.php'>ტესტი პაროლის შემოწმებისთვის</a></li>";
echo "</ul>";
?>