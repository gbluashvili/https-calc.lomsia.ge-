<?php
// /home/mvpuufsr/calc/calc.lomsia.ge/admin/logout.php
session_start();
session_destroy();
header('Location: login.php');
exit();
?>