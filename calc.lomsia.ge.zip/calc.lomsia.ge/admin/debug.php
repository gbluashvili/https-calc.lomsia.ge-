<?php
// /home/mvpuufsr/calc/calc.lomsia.ge/admin/debug.php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

echo "<h1>Debug Page</h1>";

// შეამოწმეთ session
session_start();
echo "<h2>Session Status:</h2>";
echo "Session ID: " . session_id() . "<br>";
echo "Session Status: " . session_status() . "<br>";
var_dump($_SESSION);

// შეამოწმეთ ბაზასთან კავშირი
echo "<h2>Database Connection:</h2>";
try {
    require_once __DIR__ . '/../config/db.php';
    
    echo "DB_HOST: " . DB_HOST . "<br>";
    echo "DB_USER: " . DB_USER . "<br>";
    echo "DB_NAME: " . DB_NAME . "<br>";
    
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    
    if ($conn->connect_error) {
        echo "Connection failed: " . $conn->connect_error;
    } else {
        echo "Database connection successful!<br>";
        
        // შეამოწმეთ users ცხრილი
        $result = $conn->query("SELECT COUNT(*) as count FROM users");
        if ($result) {
            $row = $result->fetch_assoc();
            echo "Users in database: " . $row['count'] . "<br>";
        }
        
        $conn->close();
    }
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
}

// შეამოწმეთ ფაილების არსებობა
echo "<h2>File Check:</h2>";
$files = [
    '../config/db.php',
    'db_connection.php',
    'login.php'
];

foreach ($files as $file) {
    $path = __DIR__ . '/' . $file;
    echo $file . ": " . (file_exists($path) ? "Exists" : "Missing") . "<br>";
}
?>