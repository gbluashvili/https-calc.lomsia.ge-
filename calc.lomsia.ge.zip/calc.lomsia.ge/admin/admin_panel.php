<?php
// /home/mvpuufsr/calc/calc.lomsia.ge/admin/admin_panel.php

// ჩართეთ error reporting დეველოპმენტისთვის
error_reporting(E_ALL);
ini_set('display_errors', 1);

// 1. სესიის დაწყება
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// 2. ავტორიზაციის შემოწმება
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

// 3. ჩატვირთეთ db_connection
require_once __DIR__ . '/../config/db.php';

// 4. შევამოწმოთ არის თუ არა ადმინი
$is_admin = (isset($_SESSION['user_role']) && ($_SESSION['user_role'] === 'admin' || $_SESSION['user_role'] === 'super_admin'));
if (!$is_admin) {
    header('Location: ../public/index.php');
    exit();
}

// 5. შევამოწმოთ არსებობს თუ არა permissions სვეტი
$check_column = "SHOW COLUMNS FROM users LIKE 'permissions'";
$column_result = $conn->query($check_column);
if ($column_result->num_rows == 0) {
    // სვეტი არ არსებობს, გადამისამართება დამატების გვერდზე
    header('Location: add_permissions_column.php');
    exit();
}

// გვერდების სია
$pages = [
    'public/index.php' => 'მთავარი გვერდი',
    'public/warehouse.php' => 'საწყობი',
    'public/menu.php' => 'მენიუ',
    'public/analytics.php' => 'ანალიტიკა',
    'public/sales_history.php' => 'გაყიდვების ისტორია',
    'public/reports.php' => 'ანგარიშები',
    'public/money_movement.php' => 'ფულადი ოპერაციები'
    // admin/admin_panel.php არ შევიტანოთ აქ - მხოლოდ ადმინისტრატორებისთვის
];

// 6. დამუშავება: რედაქტირებისთვის მომხმარებლის მონაცემების ჩატვირთვა
$edit_mode = false;
$edit_user_id = 0;
$user_to_edit = null;

if (isset($_GET['edit_user'])) {
    $edit_user_id = intval($_GET['edit_user']);
    $sql = "SELECT * FROM users WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $edit_user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $user_to_edit = $result->fetch_assoc();
        $edit_mode = true;
        
        // ავტომატურად შევსებული ველები რედაქტირებისთვის
        $_POST['username'] = $user_to_edit['username'];
        $_POST['email'] = $user_to_edit['email'];
        $_POST['role'] = $user_to_edit['role'];
        $_POST['full_name'] = $user_to_edit['full_name'];
        $_POST['phone'] = $user_to_edit['phone'];
        
        // წვდომების დაყენება
        $permissions = json_decode($user_to_edit['permissions'] ?? '[]', true);
        foreach ($pages as $page_url => $page_name) {
            $permission_key = 'permission_' . str_replace(['/', '.', '-'], '_', $page_url);
            $_POST[$permission_key] = isset($permissions[$page_url]) && $permissions[$page_url] ? '1' : '';
        }
        
        // admin panel-ის წვდომის დაყენება
        $admin_panel_key = 'permission_admin_admin_panel_php';
        $_POST[$admin_panel_key] = isset($permissions['admin/admin_panel.php']) && $permissions['admin/admin_panel.php'] ? '1' : '';
    }
}

// 7. დამუშავება: ახალი მომხმარებლის დამატება ან რედაქტირება
$errors = [];
$success_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && (isset($_POST['add_user']) || isset($_POST['update_user']))) {
    $username = trim($_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $role = trim($_POST['role'] ?? '');
    $full_name = trim($_POST['full_name'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    
    // წვდომების მიღება
    $permissions = [];
    
    // რეგულარული გვერდები
    foreach ($pages as $page_url => $page_name) {
        $permission_key = 'permission_' . str_replace(['/', '.', '-'], '_', $page_url);
        if (isset($_POST[$permission_key]) && $_POST[$permission_key] == '1') {
            $permissions[$page_url] = true;
        }
    }
    
    // admin/admin_panel.php - მხოლოდ ადმინისტრატორებისთვის
    if ($role === 'admin' || $role === 'super_admin') {
        $admin_panel_key = 'permission_admin_admin_panel_php';
        if (isset($_POST[$admin_panel_key]) && $_POST[$admin_panel_key] == '1') {
            $permissions['admin/admin_panel.php'] = true;
        }
    }
    
    // JSON-ად გარდაქმნა
    $permissions_json = json_encode($permissions, JSON_UNESCAPED_UNICODE);
    
    // ვალიდაცია
    if (empty($username)) $errors[] = "მომხმარებლის სახელი სავალდებულოა";
    if (empty($email)) $errors[] = "ელ-ფოსტა სავალდებულოა";
    if (empty($role)) $errors[] = "როლი სავალდებულოა";
    
    // ახალი მომხმარებლისთვის პაროლი სავალდებულოა, რედაქტირებისთვის - არა
    if (isset($_POST['add_user']) && empty($password)) {
        $errors[] = "პაროლი სავალდებულოა";
    }
    
    if (isset($_POST['add_user']) && strlen($password) < 6) {
        $errors[] = "პაროლი უნდა იყოს მინიმუმ 6 სიმბოლო";
    }
    
    // შეამოწმეთ რომ მინიმუმ ერთი გვერდის წვდომა მონიშნულია
    if (empty($permissions)) {
        $errors[] = "მინიმუმ ერთი გვერდის წვდომა უნდა იყოს არჩეული";
    }
    
    if (empty($errors)) {
        if (isset($_POST['add_user'])) {
            // ახალი მომხმარებლის დამატება
            $check_sql = "SELECT id FROM users WHERE username = ? OR email = ?";
            $check_stmt = $conn->prepare($check_sql);
            $check_stmt->bind_param("ss", $username, $email);
            $check_stmt->execute();
            $check_result = $check_stmt->get_result();
            
            if ($check_result->num_rows > 0) {
                $errors[] = "მომხმარებელი ან ელ-ფოსტა უკვე არსებობს";
            } else {
                // პაროლის ჰეშირება
                $hashed_password = password_hash($password, PASSWORD_BCRYPT);
                
                // მომხმარებლის დამატება permissions-ით
                $sql = "INSERT INTO users (username, email, password_hash, full_name, phone, role, is_active, permissions) 
                        VALUES (?, ?, ?, ?, ?, ?, 1, ?)";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("sssssss", $username, $email, $hashed_password, $full_name, $phone, $role, $permissions_json);
                
                if ($stmt->execute()) {
                    $success_message = "✅ მომხმარებელი წარმატებით დაემატა!";
                    // გაასუფთავეთ ველები წარმატების შემდეგ
                    $_POST = array();
                    $edit_mode = false;
                } else {
                    $errors[] = "❌ შეცდომა: " . $conn->error;
                }
            }
        } elseif (isset($_POST['update_user'])) {
            // არსებული მომხმარებლის რედაქტირება
            $update_user_id = intval($_POST['update_user_id']);
            
            // შევამოწმოთ არის თუ არა უნიკალური username და email სხვა მომხმარებლებისგან
            $check_sql = "SELECT id FROM users WHERE (username = ? OR email = ?) AND id != ?";
            $check_stmt = $conn->prepare($check_sql);
            $check_stmt->bind_param("ssi", $username, $email, $update_user_id);
            $check_stmt->execute();
            $check_result = $check_stmt->get_result();
            
            if ($check_result->num_rows > 0) {
                $errors[] = "მომხმარებელი ან ელ-ფოსტა უკვე გამოყენებულია სხვა მომხმარებლის მიერ";
            } else {
                // პაროლის განახლება (თუ მითითებულია)
                if (!empty($password)) {
                    if (strlen($password) < 6) {
                        $errors[] = "პაროლი უნდა იყოს მინიმუმ 6 სიმბოლო";
                    } else {
                        $hashed_password = password_hash($password, PASSWORD_BCRYPT);
                        $sql = "UPDATE users SET username = ?, email = ?, password_hash = ?, full_name = ?, 
                                phone = ?, role = ?, permissions = ? WHERE id = ?";
                        $stmt = $conn->prepare($sql);
                        $stmt->bind_param("sssssssi", $username, $email, $hashed_password, $full_name, 
                                         $phone, $role, $permissions_json, $update_user_id);
                    }
                } else {
                    // პაროლის გარეშე განახლება
                    $sql = "UPDATE users SET username = ?, email = ?, full_name = ?, 
                            phone = ?, role = ?, permissions = ? WHERE id = ?";
                    $stmt = $conn->prepare($sql);
                    $stmt->bind_param("ssssssi", $username, $email, $full_name, 
                                     $phone, $role, $permissions_json, $update_user_id);
                }
                
                if (empty($errors) && isset($stmt) && $stmt->execute()) {
                    $success_message = "✅ მომხმარებელი წარმატებით განახლდა!";
                    // გაასუფთავეთ ველები
                    $_POST = array();
                    $edit_mode = false;
                } elseif (isset($stmt)) {
                    $errors[] = "❌ შეცდომა: " . $conn->error;
                }
            }
        }
    }
}

// 8. დამუშავება: მომხმარებლის სტატუსის შეცვლა
if (isset($_GET['toggle_status'])) {
    $user_id = intval($_GET['toggle_status']);
    $sql = "UPDATE users SET is_active = NOT is_active WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    header("Location: admin_panel.php");
    exit();
}

// 9. დამუშავება: მომხმარებლის წაშლა
if (isset($_GET['delete_user'])) {
    $user_id = intval($_GET['delete_user']);
    
    // შევამოწმოთ არ ვშლით თავსავე
    if ($user_id != $_SESSION['user_id']) {
        $sql = "DELETE FROM users WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
    }
    header("Location: admin_panel.php");
    exit();
}

// 10. მომხმარებლების წამოღება წვდომებით
$sql = "SELECT id, username, email, full_name, phone, role, is_active, created_at, last_login, 
        COALESCE(permissions, '[]') as permissions 
        FROM users 
        ORDER BY created_at DESC";
$result = $conn->query($sql);

// ყველა გვერდის სია წვდომების ჩვენებისთვის (admin/admin_panel.php-ს ჩათვლით)
$all_pages_for_display = array_merge($pages, ['admin/admin_panel.php' => 'ადმინ პანელი']);
?>
<!DOCTYPE html>
<html lang="ka">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ადმინ პანელი - მომხმარებლების მართვა</title>
    <link rel="stylesheet" href="../css/admin_panel.css">
    <style>
        /* დამატებითი სტილები ჩეკბოქსებისთვის */
        .permissions-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 12px;
            margin-top: 10px;
            background: #f8fafc;
            padding: 20px;
            border-radius: 10px;
            border: 1px solid #e2e8f0;
        }
        
        .permission-item {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 10px 15px;
            background: white;
            border-radius: 8px;
            border: 1px solid #e2e8f0;
            transition: all 0.2s;
        }
        
        .permission-item:hover {
            border-color: #cbd5e0;
            background: #f7fafc;
        }
        
        .permission-item input[type="checkbox"] {
            width: 18px;
            height: 18px;
            accent-color: #4c51bf;
        }
        
        .permission-item label {
            cursor: pointer;
            user-select: none;
            font-weight: 500;
            color: #4a5568;
            flex: 1;
        }
        
        .permission-status {
            font-size: 0.8rem;
            padding: 2px 8px;
            border-radius: 4px;
            background: #e2e8f0;
            color: #4a5568;
        }
        
        .select-all-buttons {
            display: flex;
            gap: 10px;
            margin-bottom: 15px;
        }
        
        .select-all-btn {
            background: #edf2f7;
            color: #4a5568;
            border: 1px solid #cbd5e0;
            padding: 8px 15px;
            border-radius: 6px;
            cursor: pointer;
            font-size: 0.9rem;
            transition: all 0.2s;
        }
        
        .select-all-btn:hover {
            background: #e2e8f0;
        }
        
        .permissions-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
        }
        
        .permissions-count {
            color: #718096;
            font-size: 0.9rem;
        }
        
        /* მომხმარებლების ცხრილში წვდომების ჩვენება */
        .user-permissions {
            max-width: 300px;
        }
        
        .permissions-badge {
            display: inline-block;
            background: #e2e8f0;
            color: #4a5568;
            padding: 3px 8px;
            border-radius: 12px;
            font-size: 0.8rem;
            margin: 2px;
        }
        
        .permissions-badge.admin {
            background: #bee3f8;
            color: #2c5282;
        }
        
        .permissions-modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            z-index: 1000;
            justify-content: center;
            align-items: center;
        }
        
        .permissions-modal-content {
            background: white;
            padding: 30px;
            border-radius: 15px;
            max-width: 600px;
            width: 90%;
            max-height: 80vh;
            overflow-y: auto;
        }
        
        .permissions-list {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 10px;
            margin-top: 15px;
        }
        
        .admin-only-badge {
            background: #4c51bf;
            color: white;
            padding: 2px 8px;
            border-radius: 4px;
            font-size: 0.7rem;
            margin-left: 5px;
            display: inline-block;
        }
        
        .edit-mode-banner {
            background: linear-gradient(90deg, #4c51bf, #667eea);
            color: white;
            padding: 15px 20px;
            border-radius: 10px;
            margin-bottom: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        
        .edit-mode-banner h3 {
            margin: 0;
            font-size: 1.2rem;
        }
        
        .edit-mode-banner .btn {
            background: rgba(255, 255, 255, 0.2);
            border: 1px solid rgba(255, 255, 255, 0.3);
            color: white;
        }
        
        .edit-mode-banner .btn:hover {
            background: rgba(255, 255, 255, 0.3);
        }
        
        .password-note {
            color: #718096;
            font-size: 0.85rem;
            margin-top: 5px;
            font-style: italic;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>ადმინისტრაციული პანელი</h1>
            <p>მომხმარებლების და წვდომების მართვა</p>
            <div class="user-info">
                მომხმარებელი: <strong><?php echo htmlspecialchars($_SESSION['username'] ?? ''); ?></strong> | 
                როლი: <strong><?php echo htmlspecialchars($_SESSION['user_role'] ?? ''); ?></strong> |
                <a href="../public/index.php" style="color: #cbd5e0; margin-left: 15px; text-decoration: none;">← მთავარი გვერდი</a>
            </div>
        </div>
        
        <a href="../public/index.php" class="btn-back">
            ← დაბრუნება მთავარ გვერდზე
        </a>
        
        <?php if (!empty($success_message)): ?>
            <div class="alert alert-success"><?php echo htmlspecialchars($success_message); ?></div>
        <?php endif; ?>
        
        <?php if (!empty($errors)): ?>
            <div class="alert alert-error">
                <?php foreach ($errors as $error): ?>
                    <div>• <?php echo htmlspecialchars($error); ?></div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
        
        <?php if ($edit_mode): ?>
            <div class="edit-mode-banner">
                <div>
                    <h3>✏️ მომხმარებლის რედაქტირება</h3>
                    <p style="margin: 5px 0 0 0; opacity: 0.9; font-size: 0.9rem;">
                        რედაქტირება: <strong><?php echo htmlspecialchars($user_to_edit['username']); ?></strong> 
                        (ID: #<?php echo $edit_user_id; ?>)
                    </p>
                </div>
                <a href="admin_panel.php" class="btn">❌ რედაქტირების გაუქმება</a>
            </div>
        <?php endif; ?>
        
        <!-- ახალი მომხმარებლის დამატება/რედაქტირების ფორმა -->
        <div class="card">
            <h2><?php echo $edit_mode ? '✏️ მომხმარებლის რედაქტირება' : '📝 ახალი მომხმარებლის რეგისტრაცია'; ?></h2>
            <form method="POST" action="" id="userForm">
                <?php if ($edit_mode): ?>
                    <input type="hidden" name="update_user_id" value="<?php echo $edit_user_id; ?>">
                <?php endif; ?>
                
                <div class="form-grid">
                    <div class="form-group">
                        <label for="username">მომხმარებლის სახელი *</label>
                        <input type="text" id="username" name="username" class="form-control" 
                               value="<?php echo htmlspecialchars($_POST['username'] ?? ''); ?>" 
                               required minlength="3">
                    </div>
                    
                    <div class="form-group">
                        <label for="email">ელ-ფოსტა *</label>
                        <input type="email" id="email" name="email" class="form-control" 
                               value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>" 
                               required>
                    </div>
                    
                    <div class="form-group">
                        <label for="password">პაროლი <?php echo $edit_mode ? '' : '*'; ?></label>
                        <input type="password" id="password" name="password" class="form-control" 
                               value="<?php echo htmlspecialchars($_POST['password'] ?? ''); ?>" 
                               <?php echo $edit_mode ? '' : 'required'; ?> minlength="6">
                        <div class="password-strength">
                            <div class="password-strength-bar" id="passwordStrengthBar"></div>
                        </div>
                        <?php if ($edit_mode): ?>
                            <small class="password-note">დატოვეთ ცარიელი, თუ არ გსურთ პაროლის შეცვლა</small>
                        <?php else: ?>
                            <small style="color: #718096; font-size: 0.85rem; display: block; margin-top: 5px;">
                                მინიმუმ 6 სიმბოლო
                            </small>
                        <?php endif; ?>
                    </div>
                    
                    <!-- მთავარი როლი -->
                    <div class="form-group">
                        <label for="role">მთავარი როლი *</label>
                        <select id="role" name="role" class="form-control" required>
                            <option value="">აირჩიეთ მთავარი როლი</option>
                            <option value="admin" <?php echo (isset($_POST['role']) && $_POST['role'] == 'admin') ? 'selected' : ''; ?>>ადმინისტრატორი</option>
                            <option value="manager" <?php echo (isset($_POST['role']) && $_POST['role'] == 'manager') ? 'selected' : ''; ?>>მენეჯერი</option>
                            <option value="chef" <?php echo (isset($_POST['role']) && $_POST['role'] == 'chef') ? 'selected' : ''; ?>>შეფ-მზარეული</option>
                            <option value="warehouse" <?php echo (isset($_POST['role']) && $_POST['role'] == 'warehouse') ? 'selected' : ''; ?>>საწყობი</option>
                            <option value="user" <?php echo (isset($_POST['role']) && $_POST['role'] == 'user') ? 'selected' : ''; ?>>მომხმარებელი</option>
                            <option value="custom" <?php echo (isset($_POST['role']) && $_POST['role'] == 'custom') ? 'selected' : ''; ?>>მორგებული როლი</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="full_name">სრული სახელი</label>
                        <input type="text" id="full_name" name="full_name" class="form-control" 
                               value="<?php echo htmlspecialchars($_POST['full_name'] ?? ''); ?>">
                    </div>
                    
                    <div class="form-group">
                        <label for="phone">ტელეფონი</label>
                        <input type="tel" id="phone" name="phone" class="form-control" 
                               value="<?php echo htmlspecialchars($_POST['phone'] ?? ''); ?>">
                    </div>
                    
                    <!-- წვდომები -->
                    <div class="form-group" style="grid-column: span 2;">
                        <label>გვერდების წვდომები *</label>
                        <div class="permissions-header">
                            <small class="permissions-count" id="selectedCount">არჩეულია 0/8 გვერდი</small>
                            <div class="select-all-buttons">
                                <button type="button" class="select-all-btn" onclick="selectAllPages(true)">ყველას არჩევა</button>
                                <button type="button" class="select-all-btn" onclick="selectAllPages(false)">ყველას გაუქმება</button>
                            </div>
                        </div>
                        
                        <div class="permissions-grid" id="permissionsGrid">
                            <?php foreach ($pages as $page_url => $page_name): 
                                $permission_key = 'permission_' . str_replace(['/', '.', '-'], '_', $page_url);
                                $is_checked = isset($_POST[$permission_key]) && $_POST[$permission_key] == '1';
                            ?>
                            <div class="permission-item">
                                <input type="checkbox" 
                                       id="<?php echo $permission_key; ?>" 
                                       name="<?php echo $permission_key; ?>" 
                                       value="1" 
                                       <?php echo $is_checked ? 'checked' : ''; ?>
                                       data-page-url="<?php echo htmlspecialchars($page_url); ?>">
                                <label for="<?php echo $permission_key; ?>">
                                    <?php echo htmlspecialchars($page_name); ?>
                                    <br>
                                    <small style="color: #718096; font-size: 0.8rem;">
                                        <?php echo htmlspecialchars($page_url); ?>
                                    </small>
                                </label>
                            </div>
                            <?php endforeach; ?>
                            
                            <!-- admin/admin_panel.php - მხოლოდ ადმინისტრატორებისთვის -->
                            <?php 
                            $admin_panel_key = 'permission_admin_admin_panel_php';
                            $is_admin_panel_checked = isset($_POST[$admin_panel_key]) && $_POST[$admin_panel_key] == '1';
                            
                            // მხოლოდ show if role is admin or super_admin in the form
                            $show_admin_panel = (isset($_POST['role']) && ($_POST['role'] == 'admin' || $_POST['role'] == 'super_admin')) 
                                                || (!isset($_POST['role']) && isset($_SESSION['user_role']) && ($_SESSION['user_role'] == 'admin' || $_SESSION['user_role'] == 'super_admin'));
                            ?>
                            <div class="permission-item" style="border-left: 4px solid #4c51bf; display: <?php echo $show_admin_panel ? 'flex' : 'none'; ?>" id="adminPanelItem">
                                <input type="checkbox" 
                                       id="<?php echo $admin_panel_key; ?>" 
                                       name="<?php echo $admin_panel_key; ?>" 
                                       value="1" 
                                       <?php echo $is_admin_panel_checked ? 'checked' : ''; ?>
                                       data-page-url="admin/admin_panel.php"
                                       <?php echo $show_admin_panel ? '' : 'disabled'; ?>>
                                <label for="<?php echo $admin_panel_key; ?>">
                                    ადმინ პანელი
                                    <br>
                                    <small style="color: #718096; font-size: 0.8rem;">
                                        admin/admin_panel.php
                                    </small>
                                </label>
                                <span class="admin-only-badge">მხოლოდ ადმინი</span>
                            </div>
                        </div>
                        <small style="color: #718096; font-size: 0.85rem; display: block; margin-top: 10px;">
                            * მონიშნეთ გვერდები რომელზეც მომხმარებელს ექნება წვდომა
                        </small>
                    </div>
                </div>
                
                <?php if ($edit_mode): ?>
                    <button type="submit" name="update_user" class="btn btn-primary">
                        💾 ცვლილებების შენახვა
                    </button>
                    <a href="admin_panel.php" class="btn" style="background: #e2e8f0; color: #4a5568; margin-left: 10px;">
                        ❌ გაუქმება
                    </a>
                <?php else: ?>
                    <button type="submit" name="add_user" class="btn btn-primary">
                        📝 მომხმარებლის დამატება
                    </button>
                    <button type="reset" class="btn" style="background: #e2e8f0; color: #4a5568; margin-left: 10px;" onclick="resetForm()">
                        🗑️ გასუფთავება
                    </button>
                <?php endif; ?>
            </form>
        </div>
        
        <!-- მომხმარებლების სია -->
        <div class="card">
            <h2>👥 მომხმარებლების სია</h2>
            
            <?php if ($result && $result->num_rows > 0): ?>
            <div style="overflow-x: auto;">
                <table class="users-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>მომხმარებელი</th>
                            <th>როლი</th>
                            <th>წვდომები</th>
                            <th>სტატუსი</th>
                            <th>ბოლო შესვლა</th>
                            <th>ქმედებები</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        // ხელახლა წამოვიღოთ მონაცემები, რადგან result-ის კურსორი შეიძლება უკვე გამოყენებული იყოს
                        $result = $conn->query($sql);
                        while ($user = $result->fetch_assoc()): 
                            $is_current_user = ($user['id'] == $_SESSION['user_id']);
                            $permissions = json_decode($user['permissions'] ?? '[]', true);
                        ?>
                        <tr>
                            <td>#<?php echo $user['id']; ?></td>
                            <td>
                                <strong><?php echo htmlspecialchars($user['full_name'] ?: $user['username']); ?></strong><br>
                                <small style="color: #718096;">@<?php echo htmlspecialchars($user['username']); ?></small><br>
                                <small style="color: #718096;">✉️ <?php echo htmlspecialchars($user['email']); ?></small>
                                <?php if ($user['phone']): ?>
                                <br><small style="color: #718096;">📱 <?php echo htmlspecialchars($user['phone']); ?></small>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span style="background: #e2e8f0; color: #4a5568; padding: 4px 10px; border-radius: 12px; font-size: 0.85rem; font-weight: 600;">
                                    <?php echo htmlspecialchars($user['role']); ?>
                                </span>
                            </td>
                            <td class="user-permissions">
                                <?php 
                                $count = 0;
                                $max_show = 3;
                                foreach ($all_pages_for_display as $page_url => $page_name) {
                                    if (isset($permissions[$page_url]) && $permissions[$page_url]) {
                                        if ($count < $max_show) {
                                            echo '<span class="permissions-badge">' . htmlspecialchars($page_name) . '</span>';
                                        }
                                        $count++;
                                    }
                                }
                                if ($count > $max_show) {
                                    echo '<span class="permissions-badge">+ ' . ($count - $max_show) . ' სხვა</span>';
                                }
                                if ($count == 0) {
                                    echo '<span style="color: #a0aec0;">წვდომები არ აქვს</span>';
                                }
                                ?>
                                <?php if ($count > 0): ?>
                                <br>
                                <button type="button" class="select-all-btn" onclick="showPermissions(<?php echo $user['id']; ?>, <?php echo htmlspecialchars(json_encode($permissions, JSON_UNESCAPED_UNICODE)); ?>)"
                                        style="margin-top: 5px; padding: 3px 8px; font-size: 0.8rem;">
                                    ყველას ნახვა
                                </button>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span class="status-<?php echo $user['is_active'] ? 'active' : 'inactive'; ?>">
                                    <?php echo $user['is_active'] ? 'აქტიური' : 'არააქტიური'; ?>
                                </span>
                            </td>
                            <td>
                                <?php if ($user['last_login']): ?>
                                    <?php echo date('d/m/Y H:i', strtotime($user['last_login'])); ?>
                                <?php else: ?>
                                    <span style="color: #a0aec0;">არასოდეს</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <div class="action-buttons">
                                    <!-- რედაქტირების ღილაკი -->
                                    <a href="?edit_user=<?php echo $user['id']; ?>" 
                                       class="btn btn-info btn-sm">
                                        ✏️ რედაქტირება
                                    </a>
                                    
                                    <!-- სტატუსის შეცვლა -->
                                    <a href="?toggle_status=<?php echo $user['id']; ?>" 
                                       class="btn btn-warning btn-sm">
                                        <?php echo $user['is_active'] ? '🔴 დეაქტივაცია' : '🟢 აქტივაცია'; ?>
                                    </a>
                                    
                                    <!-- წაშლა -->
                                    <?php if (!$is_current_user): ?>
                                    <a href="?delete_user=<?php echo $user['id']; ?>" 
                                       class="btn btn-danger btn-sm"
                                       onclick="return confirm('დარწმუნებული ხართ რომ გსურთ მომხმარებლის წაშლა? ამ მოქმედების გაუქმება შეუძლებელია!')">
                                        🗑️ წაშლა
                                    </a>
                                    <?php else: ?>
                                    <span class="btn btn-sm" style="background: #cbd5e0; color: #718096; cursor: not-allowed;">
                                        👤 ახლანდელი
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
            <?php else: ?>
                <div style="text-align: center; padding: 40px; color: #718096;">
                    <p style="font-size: 1.2rem; margin-bottom: 10px;">📭 მომხმარებლები არ მოიძებნა</p>
                    <p>დაამატეთ ახალი მომხმარებელი ზემოთ მოცემული ფორმის გამოყენებით.</p>
                </div>
            <?php endif; ?>
        </div>
        
        <!-- წვდომების მოდალური ფანჯარა -->
        <div id="permissionsModal" class="permissions-modal">
            <div class="permissions-modal-content">
                <h3>მომხმარებლის წვდომები</h3>
                <div id="modalPermissionsList" class="permissions-list"></div>
                <div style="text-align: right; margin-top: 20px;">
                    <button type="button" class="btn" onclick="closeModal()" style="background: #e2e8f0; color: #4a5568;">
                        დახურვა
                    </button>
                </div>
            </div>
        </div>
        
        <!-- სისტემის ინფორმაცია -->
        <div class="card">
            <h2>ℹ️ სისტემის ინფორმაცია</h2>
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px;">
                <div>
                    <h3 style="color: #4c51bf; margin-bottom: 10px;">სტატისტიკა</h3>
                    <p>მომხმარებლები: <strong><?php echo $result ? $result->num_rows : 0; ?></strong></p>
                    <p>გვერდები: <strong><?php echo count($all_pages_for_display); ?></strong></p>
                    <p>PHP ვერსია: <strong><?php echo phpversion(); ?></strong></p>
                </div>
                <div>
                    <h3 style="color: #4c51bf; margin-bottom: 10px;">წვდომები</h3>
                    <p>სესია: <strong><?php echo substr(session_id(), 0, 10) . '...'; ?></strong></p>
                    <p>IP მისამართი: <strong><?php echo $_SERVER['REMOTE_ADDR']; ?></strong></p>
                    <p>ბოლო აქტივობა: <strong><?php echo date('H:i:s'); ?></strong></p>
                </div>
            </div>
        </div>
        
        <!-- ფუტერი -->
        <div style="text-align: center; margin-top: 40px; padding-top: 20px; border-top: 1px solid #e2e8f0;">
            <a href="../public/index.php" class="btn btn-primary">🏠 მთავარი გვერდი</a>
            <a href="logout.php" class="btn btn-danger" style="margin-left: 10px;">🚪 გამოსვლა</a>
        </div>
    </div>
    
    <script>
        // პაროლის სიძლიერის ინდიკატორი
        document.getElementById('password').addEventListener('input', function(e) {
            const password = e.target.value;
            const strength = calculatePasswordStrength(password);
            const strengthBar = document.getElementById('passwordStrengthBar');
            
            let color, width;
            
            if (password.length === 0) {
                width = '0%';
                color = '#e2e8f0';
            } else if (strength < 2) {
                width = '25%';
                color = '#f56565';
            } else if (strength < 4) {
                width = '50%';
                color = '#ed8936';
            } else if (strength < 5) {
                width = '75%';
                color = '#ecc94b';
            } else {
                width = '100%';
                color = '#48bb78';
            }
            
            strengthBar.style.width = width;
            strengthBar.style.background = color;
        });
        
        function calculatePasswordStrength(password) {
            let strength = 0;
            
            if (password.length >= 6) strength++;
            if (password.length >= 8) strength++;
            if (/[A-Z]/.test(password)) strength++;
            if (/[0-9]/.test(password)) strength++;
            if (/[^A-Za-z0-9]/.test(password)) strength++;
            
            return strength;
        }
        
        // წვდომების მართვა
        function updateSelectedCount() {
            const checkboxes = document.querySelectorAll('#permissionsGrid input[type="checkbox"]:not(:disabled)');
            let selected = 0;
            checkboxes.forEach(cb => {
                if (cb.checked) selected++;
            });
            document.getElementById('selectedCount').textContent = `არჩეულია ${selected}/${checkboxes.length} გვერდი`;
        }
        
        function selectAllPages(select) {
            const checkboxes = document.querySelectorAll('#permissionsGrid input[type="checkbox"]:not(:disabled)');
            checkboxes.forEach(cb => {
                cb.checked = select;
            });
            updateSelectedCount();
        }
        
        // ფორმის დადასტურება
        document.getElementById('userForm').addEventListener('submit', function(e) {
            const password = document.getElementById('password').value;
            const username = document.getElementById('username').value;
            const isEditMode = <?php echo $edit_mode ? 'true' : 'false'; ?>;
            
            // წვდომების შემოწმება
            const checkboxes = document.querySelectorAll('#permissionsGrid input[type="checkbox"]:not(:disabled):checked');
            if (checkboxes.length === 0) {
                e.preventDefault();
                alert('❌ მინიმუმ ერთი გვერდის წვდომა უნდა იყოს არჩეული');
                return false;
            }
            
            // ახალი მომხმარებლისთვის პაროლის შემოწმება
            if (!isEditMode) {
                if (password.length < 6) {
                    e.preventDefault();
                    alert('❌ პაროლი უნდა იყოს მინიმუმ 6 სიმბოლო');
                    return false;
                }
            }
            
            if (username.length < 3) {
                e.preventDefault();
                alert('❌ მომხმარებლის სახელი უნდა იყოს მინიმუმ 3 სიმბოლო');
                return false;
            }
            
            return true;
        });
        
        // განახლება ჩეკბოქსების შეცვლისას
        document.querySelectorAll('#permissionsGrid input[type="checkbox"]').forEach(cb => {
            cb.addEventListener('change', updateSelectedCount);
        });
        
        // პირველ ჩატვირთვაზე დათვლა
        document.addEventListener('DOMContentLoaded', function() {
            updateSelectedCount();
            
            // თუ რედაქტირების რეჟიმში ვართ, ავტომატურად გადავცვალოთ title
            const editMode = <?php echo $edit_mode ? 'true' : 'false'; ?>;
            if (editMode) {
                const formTitle = document.querySelector('.card h2');
                if (formTitle) {
                    formTitle.innerHTML = '✏️ მომხმარებლის რედაქტირება';
                }
                
                // ავტომატურად გადავცვალოთ გვერდის სათაური
                document.title = 'მომხმარებლის რედაქტირება - ადმინ პანელი';
            }
        });
        
        // ფორმის გასუფთავება
        function resetForm() {
            document.getElementById('userForm').reset();
            setTimeout(updateSelectedCount, 100);
        }
        
        // მოდალური ფანჯრის მართვა
        function showPermissions(userId, permissions) {
            const modal = document.getElementById('permissionsModal');
            const list = document.getElementById('modalPermissionsList');
            
            let html = '';
            const pages = {
                'public/index.php': 'მთავარი გვერდი',
                'public/warehouse.php': 'საწყობი',
                'public/menu.php': 'მენიუ',
                'public/analytics.php': 'ანალიტიკა',
                'public/sales_history.php': 'გაყიდვების ისტორია',
                'public/reports.php': 'ანგარიშები',
                'public/money_movement.php': 'ფულადი ოპერაციები',
                'admin/admin_panel.php': 'ადმინ პანელი'
            };
            
            let count = 0;
            for (const [page_url, page_name] of Object.entries(pages)) {
                const hasAccess = permissions && permissions[page_url] === true;
                if (hasAccess) count++;
                
                html += `
                    <div style="display: flex; align-items: center; gap: 10px; padding: 8px; background: ${hasAccess ? '#f0fff4' : '#fff5f5'}; border-radius: 6px;">
                        <div style="width: 10px; height: 10px; border-radius: 50%; background: ${hasAccess ? '#48bb78' : '#f56565'};"></div>
                        <div>
                            <div style="font-weight: 500;">${page_name}</div>
                            <div style="font-size: 0.8rem; color: #718096;">${page_url}</div>
                        </div>
                        <div style="margin-left: auto; color: ${hasAccess ? '#38a169' : '#e53e3e'}; font-weight: 600;">
                            ${hasAccess ? '✓ წვდომა აქვს' : '✗ წვდომა არ აქვს'}
                        </div>
                    </div>
                `;
            }
            
            list.innerHTML = html;
            
            // დამატებითი ინფორმაცია
            const info = document.createElement('div');
            info.innerHTML = `<p style="color: #4a5568; margin-bottom: 15px;"><strong>წვდომების რაოდენობა:</strong> ${count}/${Object.keys(pages).length}</p>`;
            list.prepend(info);
            
            modal.style.display = 'flex';
        }
        
        function closeModal() {
            document.getElementById('permissionsModal').style.display = 'none';
        }
        
        // მოდალური ფანჯრის დახურვა ღილაკზე ESC
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                closeModal();
            }
        });
        
        // დაადასტურეთ წაშლა
        document.querySelectorAll('a[href*="delete_user"]').forEach(link => {
            link.addEventListener('click', function(e) {
                if (!confirm('დარწმუნებული ხართ რომ გსურთ ამ მომხმარებლის წაშლა?\nამ მოქმედების გაუქმება შეუძლებელია!')) {
                    e.preventDefault();
                }
            });
        });
        
        // როლის შეცვლისას ავტომატური წვდომების დაყენება
        document.getElementById('role').addEventListener('change', function(e) {
            const role = this.value;
            const checkboxes = document.querySelectorAll('#permissionsGrid input[type="checkbox"]');
            const adminPanelItem = document.getElementById('adminPanelItem');
            const adminPanelCheckbox = document.getElementById('permission_admin_admin_panel_php');
            
            // ავტომატური წვდომები როლების მიხედვით
            const rolePermissions = {
                'admin': ['public/index.php', 'public/warehouse.php', 'public/menu.php', 'public/analytics.php', 
                         'public/sales_history.php', 'public/reports.php', 'public/money_movement.php', 'admin/admin_panel.php'],
                'super_admin': ['public/index.php', 'public/warehouse.php', 'public/menu.php', 'public/analytics.php', 
                               'public/sales_history.php', 'public/reports.php', 'public/money_movement.php', 'admin/admin_panel.php'],
                'manager': ['public/index.php', 'public/warehouse.php', 'public/menu.php', 'public/analytics.php', 
                           'public/sales_history.php', 'public/reports.php', 'public/money_movement.php'],
                'chef': ['public/index.php', 'public/menu.php'],
                'warehouse': ['public/index.php', 'public/warehouse.php'],
                'user': ['public/index.php'],
                'custom': ['public/index.php']
            };
            
            // ადმინ პანელის ჩვენება/დამალვა
            const isAdmin = (role === 'admin' || role === 'super_admin');
            if (adminPanelItem) {
                adminPanelItem.style.display = isAdmin ? 'flex' : 'none';
            }
            if (adminPanelCheckbox) {
                adminPanelCheckbox.disabled = !isAdmin;
                if (!isAdmin) {
                    adminPanelCheckbox.checked = false;
                }
            }
            
            if (rolePermissions[role]) {
                checkboxes.forEach(cb => {
                    const pageUrl = cb.getAttribute('data-page-url');
                    if (pageUrl !== 'admin/admin_panel.php' || isAdmin) {
                        cb.checked = rolePermissions[role].includes(pageUrl);
                    }
                });
            } else {
                // custom როლისთვის - მხოლოდ მთავარი გვერდი
                checkboxes.forEach(cb => {
                    const pageUrl = cb.getAttribute('data-page-url');
                    if (pageUrl === 'public/index.php') {
                        cb.checked = true;
                    } else if (pageUrl !== 'admin/admin_panel.php') {
                        cb.checked = false;
                    }
                });
            }
            
            updateSelectedCount();
        });
        
        // ავტომატურად გადაახვიე რედაქტირების ფორმაზე
        <?php if ($edit_mode): ?>
        document.addEventListener('DOMContentLoaded', function() {
            const formCard = document.querySelector('.card');
            if (formCard) {
                formCard.scrollIntoView({ behavior: 'smooth', block: 'start' });
            }
        });
        <?php endif; ?>
    </script>
</body>
</html>