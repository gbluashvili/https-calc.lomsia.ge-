<?php
session_start();
require_once 'db_connection.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    echo json_encode([]);
    exit();
}

if (isset($_GET['user_id'])) {
    $userId = intval($_GET['user_id']);
    $sql = "SELECT p.* FROM permissions p WHERE p.user_id = ? AND p.allowed = 1";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $permissions = [];
    while ($row = $result->fetch_assoc()) {
        $permissions[] = $row;
    }
    
    echo json_encode($permissions);
} else {
    echo json_encode([]);
}
?>