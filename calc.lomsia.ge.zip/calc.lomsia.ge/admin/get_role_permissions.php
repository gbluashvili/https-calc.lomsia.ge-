<?php
session_start();
require_once 'db_connection.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    echo json_encode([]);
    exit();
}

if (isset($_GET['role_id'])) {
    $roleId = intval($_GET['role_id']);
    $sql = "SELECT rp.* FROM role_permissions rp WHERE rp.role_id = ? AND rp.allowed = 1";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $roleId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $permissions = [];
    while ($row = $result->fetch_assoc()) {
        $permissions[] = $row;
    }
    
    echo json_encode($permissions);
} else {
    echo json_encode([]);
}
?>