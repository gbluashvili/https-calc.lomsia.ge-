<?php
// /home/mvpuufsr/calc/calc.lomsia.ge/admin/logout.php
session_start();

// ყველა სესიის ცვლადის გასუფთავება
$_SESSION = array();

// სესიის დასრულება
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

// სესიის განადგურება
session_destroy();

// გადამისამართება ლოგინის გვერდზე
header('Location: login.php');
exit();
?>