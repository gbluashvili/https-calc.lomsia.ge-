<?php
// /home/mvpuufsr/calc/calc.lomsia.ge/config/db.php

// პირველ რიგში განვსაზღვროთ მუდმივები
define('DB_HOST', "localhost");
define('DB_USER', "mvpuufsr_calc");
define('DB_PASS', "Anamaria1986!@#");
define('DB_NAME', "mvpuufsr_calc");

// შემდეგ შევქმნათ კავშირი
$mysqli = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

if ($mysqli->connect_error) {
    die("Database connection failed: " . $mysqli->connect_error);
}

$mysqli->set_charset("utf8mb4");

$conn = $mysqli;

// ფუნქცია კავშირის მისაღებად
function getConnection() {
    global $conn;
    return $conn;
}
?>