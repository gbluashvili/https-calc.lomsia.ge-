<?php
// ლოგის ფაილის ადგილი
define('ERROR_LOG_FILE', __DIR__ . '/error.log');

// ფუნქცია ლოგის ჩაწერისთვის
function log_error($message){
    $date = date('Y-m-d H:i:s');
    $msg  = "[$date] $message\n";
    file_put_contents(ERROR_LOG_FILE, $msg, FILE_APPEND);
}
