<?php
// analytics.php - განახლებული ვერსია

// სესიის დაწყება მხოლოდ ერთხელ
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ვთქვათ, რომ config.php ფაილში არის დაკავშირების ინფორმაცია
// პირდაპირი დაკავშირება
try {
    $conn = new PDO(
        "mysql:host=localhost;dbname=mvpuufsr_calc;charset=utf8mb4",
        "mvpuufsr_calc", 
        "9f87c44d25bddad374"
    );
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $conn->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("მონაცემთა ბაზასთან კავშირის შეცდომა: " . $e->getMessage());
}

// შესვლის შემოწმება (თუ session არ არის, მაინც ვაჩვენოთ ანალიტიკა)
$user_logged_in = isset($_SESSION['user_id']);

// პარამეტრები
$date_from = isset($_GET['from']) ? $_GET['from'] : date('Y-m-d', strtotime('-7 days'));
$date_to = isset($_GET['to']) ? $_GET['to'] : date('Y-m-d');

// მონაცემების მოპოვება
$stats = [];
$top_dishes = [];
$daily_sales = [];
$error = null;

try {
    // 1. ძირითადი სტატისტიკა
    $query = "SELECT 
                COUNT(*) as sale_count,
                COALESCE(SUM(total_price), 0) as revenue,
                COALESCE(SUM(cost_with_vat), 0) as cost_with_vat,
                COALESCE(SUM(profit), 0) as profit
              FROM sales 
              WHERE DATE(sale_date) BETWEEN ? AND ?";
    
    $stmt = $conn->prepare($query);
    $stmt->execute([$date_from, $date_to]);
    $stats = $stmt->fetch();
    
    if (!$stats) {
        $stats = [
            'sale_count' => 0,
            'revenue' => 0,
            'cost_with_vat' => 0,
            'profit' => 0
        ];
    }
    
    // 2. მარჟის გამოთვლა
    $margin_percent = $stats['cost_with_vat'] > 0 ? 
        ($stats['profit'] / $stats['cost_with_vat']) * 100 : 0;
    
    // 3. ტოპ 5 გაყიდვადი კერძი
    $query = "SELECT 
                dish_name,
                SUM(quantity) as qty,
                SUM(total_price) as revenue,
                SUM(cost_with_vat) as cost,
                SUM(profit) as profit
              FROM sales 
              WHERE DATE(sale_date) BETWEEN ? AND ?
              GROUP BY dish_name 
              ORDER BY revenue DESC 
              LIMIT 5";
    
    $stmt = $conn->prepare($query);
    $stmt->execute([$date_from, $date_to]);
    $top_dishes = $stmt->fetchAll();
    
    // 4. დღიური გაყიდვები
    $query = "SELECT 
                DATE(sale_date) as sale_day,
                SUM(total_price) as daily_revenue,
                COUNT(*) as daily_sales
              FROM sales 
              WHERE DATE(sale_date) BETWEEN ? AND ?
              GROUP BY DATE(sale_date)
              ORDER BY sale_day";
    
    $stmt = $conn->prepare($query);
    $stmt->execute([$date_from, $date_to]);
    $daily_sales = $stmt->fetchAll();
    
    // 5. საშუალო მაჩვენებლები
    $days_count = max(1, (strtotime($date_to) - strtotime($date_from)) / (60*60*24) + 1);
    $avg_daily_revenue = $stats['revenue'] / $days_count;
    $avg_daily_profit = $stats['profit'] / $days_count;
    $avg_transaction_value = $stats['sale_count'] > 0 ? 
        $stats['revenue'] / $stats['sale_count'] : 0;
        
} catch (PDOException $e) {
    $error = "მონაცემთა ბაზასთან შეცდომა: " . $e->getMessage();
}

// რენტაბელობის პროცენტი
$roi_percent = $stats['revenue'] > 0 ? 
    ($stats['profit'] / $stats['revenue']) * 100 : 0;

$page_title = "ბიზნეს ანალიტიკა";
?>
<!DOCTYPE html>
<html lang="ka">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root {
            --primary: #2c3e50;
            --secondary: #3498db;
            --success: #2ecc71;
            --danger: #e74c3c;
            --warning: #f39c12;
            --light: #f8f9fa;
            --dark: #343a40;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            color: #333;
        }
        
        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 20px;
        }
        
        .header {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            padding: 30px;
            border-radius: 20px;
            margin-bottom: 30px;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.2);
            text-align: center;
        }
        
        .header h1 {
            font-size: 2.5rem;
            color: var(--primary);
            margin-bottom: 10px;
        }
        
        .header p {
            font-size: 1.1rem;
            color: #666;
        }
        
        .filter-bar {
            background: white;
            padding: 25px;
            border-radius: 15px;
            margin-bottom: 30px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
        }
        
        .filter-bar form {
            display: flex;
            gap: 20px;
            align-items: center;
            flex-wrap: wrap;
        }
        
        .filter-group {
            flex: 1;
            min-width: 200px;
        }
        
        .filter-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #555;
        }
        
        .filter-group input {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #e0e0e0;
            border-radius: 10px;
            font-size: 16px;
        }
        
        .btn {
            padding: 12px 25px;
            border: none;
            border-radius: 10px;
            cursor: pointer;
            font-size: 16px;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            gap: 10px;
            text-decoration: none;
            transition: all 0.3s ease;
        }
        
        .btn-green {
            background: var(--success);
            color: white;
        }
        
        .btn-blue {
            background: var(--secondary);
            color: white;
        }
        
        .btn-gray {
            background: #95a5a6;
            color: white;
        }
        
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }
        
        .stat-cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 25px;
            margin-bottom: 40px;
        }
        
        .stat-card {
            background: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 15px 35px rgba(0,0,0,0.1);
            position: relative;
            overflow: hidden;
        }
        
        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 6px;
            height: 100%;
        }
        
        .stat-card.revenue::before {
            background: var(--success);
        }
        
        .stat-card.cost::before {
            background: var(--danger);
        }
        
        .stat-card.profit::before {
            background: var(--secondary);
        }
        
        .stat-card h4 {
            color: #555;
            margin-bottom: 15px;
            font-size: 18px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .stat-value {
            font-size: 2.8rem;
            font-weight: 700;
            color: var(--primary);
            margin-bottom: 10px;
        }
        
        .stat-details {
            margin-top: 20px;
            padding-top: 15px;
            border-top: 1px solid #eee;
        }
        
        .stat-detail {
            display: flex;
            justify-content: space-between;
            margin-bottom: 8px;
            font-size: 14px;
            color: #666;
        }
        
        .grid {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 25px;
            margin-bottom: 40px;
        }
        
        @media (max-width: 1200px) {
            .grid {
                grid-template-columns: 1fr;
            }
        }
        
        .card {
            background: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 15px 35px rgba(0,0,0,0.1);
        }
        
        .card h3 {
            color: var(--primary);
            margin-bottom: 25px;
            padding-bottom: 15px;
            border-bottom: 2px solid #f0f0f0;
            font-size: 1.5rem;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .table-container {
            overflow-x: auto;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
            min-width: 600px;
        }
        
        thead {
            background: #f8f9fa;
        }
        
        th {
            padding: 15px;
            text-align: left;
            font-weight: 600;
            color: #495057;
            border-bottom: 2px solid #dee2e6;
        }
        
        td {
            padding: 15px;
            border-bottom: 1px solid #e9ecef;
        }
        
        tbody tr:hover {
            background: #f8f9fa;
        }
        
        .text-center { text-align: center; }
        .text-right { text-align: right; }
        
        .positive { color: var(--success); font-weight: 600; }
        .negative { color: var(--danger); font-weight: 600; }
        
        .alert {
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 30px;
            background: #fee2e2;
            border: 1px solid #fecaca;
            color: #dc2626;
            display: flex;
            align-items: center;
            gap: 15px;
        }
        
        .empty-state {
            text-align: center;
            padding: 40px 20px;
            color: #6c757d;
        }
        
        .empty-state i {
            font-size: 3rem;
            margin-bottom: 15px;
            opacity: 0.3;
        }
        
        .recommendation {
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 15px;
            display: flex;
            align-items: flex-start;
            gap: 15px;
        }
        
        .recommendation.success {
            background: #d1fae5;
            border-left: 4px solid var(--success);
        }
        
        .recommendation.warning {
            background: #fef3c7;
            border-left: 4px solid var(--warning);
        }
        
        .recommendation.danger {
            background: #fee2e2;
            border-left: 4px solid var(--danger);
        }
        
        .recommendation.info {
            background: #dbeafe;
            border-left: 4px solid var(--secondary);
        }
        
        @media (max-width: 768px) {
            .filter-bar form {
                flex-direction: column;
                align-items: stretch;
            }
            
            .btn {
                width: 100%;
                justify-content: center;
            }
            
            .header {
                padding: 20px;
            }
            
            .header h1 {
                font-size: 2rem;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <?php if ($error): ?>
        <div class="alert">
            <i class="fas fa-exclamation-triangle"></i>
            <div>
                <strong>შეცდომა!</strong>
                <p><?php echo htmlspecialchars($error); ?></p>
            </div>
        </div>
        <?php endif; ?>
        
        <div class="header">
            <h1><i class="fas fa-chart-line"></i> ბიზნეს ანალიტიკა</h1>
            <p>პერიოდი: <?php echo date('d.m.Y', strtotime($date_from)); ?> - <?php echo date('d.m.Y', strtotime($date_to)); ?></p>
            <?php if (!$user_logged_in): ?>
            <p style="color: var(--warning); margin-top: 10px;">
                <i class="fas fa-exclamation-triangle"></i> მომხმარებელი არ არის შესული სისტემაში
            </p>
            <?php endif; ?>
        </div>
        
        <div class="filter-bar">
            <form method="GET">
                <div class="filter-group">
                    <label><i class="fas fa-calendar-alt"></i> დან:</label>
                    <input type="date" name="from" value="<?php echo htmlspecialchars($date_from); ?>">
                </div>
                <div class="filter-group">
                    <label><i class="fas fa-calendar-alt"></i> მდე:</label>
                    <input type="date" name="to" value="<?php echo htmlspecialchars($date_to); ?>">
                </div>
                <button type="submit" class="btn btn-green">
                    <i class="fas fa-filter"></i> გაფილტვრა
                </button>
                <a href="analytics.php" class="btn btn-gray">
                    <i class="fas fa-times"></i> გასუფთავება
                </a>
                <a href="javascript:window.print()" class="btn btn-blue">
                    <i class="fas fa-print"></i> ამობეჭდვა
                </a>
            </form>
        </div>
        
        <div class="stat-cards">
            <div class="stat-card revenue">
                <h4><i class="fas fa-money-bill-wave"></i> შემოსავალი</h4>
                <div class="stat-value"><?php echo number_format($stats['revenue'], 2); ?> ₾</div>
                <div class="stat-details">
                    <div class="stat-detail">
                        <span>გაყიდვები:</span>
                        <span><?php echo $stats['sale_count']; ?> ტრანზაქცია</span>
                    </div>
                    <div class="stat-detail">
                        <span>საშუალო დღიური:</span>
                        <span><?php echo number_format($avg_daily_revenue, 2); ?> ₾</span>
                    </div>
                    <div class="stat-detail">
                        <span>საშუალო ჩეკი:</span>
                        <span><?php echo number_format($avg_transaction_value, 2); ?> ₾</span>
                    </div>
                </div>
            </div>
            
            <div class="stat-card cost">
                <h4><i class="fas fa-money-bill-alt"></i> დანახარჯები</h4>
                <div class="stat-value"><?php echo number_format($stats['cost_with_vat'], 2); ?> ₾</div>
                <div class="stat-details">
                    <div class="stat-detail">
                        <span>ღირებულება:</span>
                        <span><?php echo number_format($stats['cost_with_vat'] / 1.18, 2); ?> ₾</span>
                    </div>
                    <div class="stat-detail">
                        <span>დღგ:</span>
                        <span><?php echo number_format($stats['cost_with_vat'] - ($stats['cost_with_vat'] / 1.18), 2); ?> ₾</span>
                    </div>
                    <div class="stat-detail">
                        <span>შემოსავლის %:</span>
                        <span><?php echo $stats['revenue'] > 0 ? number_format(($stats['cost_with_vat'] / $stats['revenue']) * 100, 2) : 0; ?>%</span>
                    </div>
                </div>
            </div>
            
            <div class="stat-card profit">
                <h4><i class="fas fa-chart-bar"></i> წმინდა მოგება</h4>
                <div class="stat-value"><?php echo number_format($stats['profit'], 2); ?> ₾</div>
                <div class="stat-details">
                    <div class="stat-detail">
                        <span>მარჟა:</span>
                        <span class="positive"><?php echo number_format($margin_percent, 2); ?>%</span>
                    </div>
                    <div class="stat-detail">
                        <span>რენტაბელობა:</span>
                        <span class="<?php echo $roi_percent >= 0 ? 'positive' : 'negative'; ?>">
                            <?php echo number_format($roi_percent, 2); ?>%
                        </span>
                    </div>
                    <div class="stat-detail">
                        <span>საშუალო დღიური:</span>
                        <span class="<?php echo $avg_daily_profit >= 0 ? 'positive' : 'negative'; ?>">
                            <?php echo number_format($avg_daily_profit, 2); ?> ₾
                        </span>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="grid">
            <div class="card">
                <h3><i class="fas fa-chart-line"></i> გაყიდვების დინამიკა</h3>
                <?php if (!empty($daily_sales)): ?>
                <div class="table-container">
                    <table>
                        <thead>
                            <tr>
                                <th>თარიღი</th>
                                <th class="text-right">შემოსავალი</th>
                                <th class="text-center">გაყიდვები</th>
                                <th class="text-right">საშუალო ჩეკი</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($daily_sales as $day): ?>
                            <?php 
                            $daily_avg = $day['daily_sales'] > 0 ? 
                                $day['daily_revenue'] / $day['daily_sales'] : 0;
                            ?>
                            <tr>
                                <td><?php echo date('d.m.Y', strtotime($day['sale_day'])); ?></td>
                                <td class="text-right"><?php echo number_format($day['daily_revenue'], 2); ?> ₾</td>
                                <td class="text-center"><?php echo $day['daily_sales']; ?></td>
                                <td class="text-right"><?php echo number_format($daily_avg, 2); ?> ₾</td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php else: ?>
                <div class="empty-state">
                    <i class="fas fa-chart-line"></i>
                    <p>გაყიდვები არ მოიძებნა არჩეულ პერიოდში</p>
                </div>
                <?php endif; ?>
            </div>
            
            <div class="card">
                <h3><i class="fas fa-trophy"></i> ტოპ 5 კერძი</h3>
                <?php if (!empty($top_dishes)): ?>
                <div class="table-container">
                    <table>
                        <thead>
                            <tr>
                                <th>კერძი</th>
                                <th class="text-center">რაოდენობა</th>
                                <th class="text-right">შემოსავალი</th>
                                <th class="text-right">მოგება</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($top_dishes as $dish): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($dish['dish_name']); ?></td>
                                <td class="text-center"><?php echo $dish['qty']; ?></td>
                                <td class="text-right"><?php echo number_format($dish['revenue'], 2); ?> ₾</td>
                                <td class="text-right <?php echo $dish['profit'] >= 0 ? 'positive' : 'negative'; ?>">
                                    <?php echo number_format($dish['profit'], 2); ?> ₾
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php else: ?>
                <div class="empty-state">
                    <i class="fas fa-utensils"></i>
                    <p>გაყიდვები არ მოიძებნა</p>
                </div>
                <?php endif; ?>
            </div>
        </div>
        
        <div class="card">
            <h3><i class="fas fa-lightbulb"></i> რეკომენდაციები</h3>
            <div style="margin-top: 20px;">
                <?php if ($roi_percent > 30): ?>
                <div class="recommendation success">
                    <i class="fas fa-trophy"></i>
                    <div>
                        <strong>შესანიშნავი მომგებიანობა! 🏆</strong>
                        <p>რენტაბელობა <?php echo number_format($roi_percent, 2); ?>%-ია. თქვენი ბიზნესი ჯანსაღად მუშაობს!</p>
                    </div>
                </div>
                <?php elseif ($roi_percent > 20): ?>
                <div class="recommendation success">
                    <i class="fas fa-check-circle"></i>
                    <div>
                        <strong>კარგი მომგებიანობა 👍</strong>
                        <p>რენტაბელობა <?php echo number_format($roi_percent, 2); ?>%-ია. გააგრძელეთ ამ კურსით.</p>
                    </div>
                </div>
                <?php elseif ($roi_percent > 10): ?>
                <div class="recommendation warning">
                    <i class="fas fa-exclamation-triangle"></i>
                    <div>
                        <strong>საშუალო მომგებიანობა ⚠️</strong>
                        <p>რენტაბელობა <?php echo number_format($roi_percent, 2); ?>%-ია. განიხილეთ ფასების გადახედვა.</p>
                    </div>
                </div>
                <?php elseif ($roi_percent > 0): ?>
                <div class="recommendation danger">
                    <i class="fas fa-times-circle"></i>
                    <div>
                        <strong>დაბალი მომგებიანობა 🚨</strong>
                        <p>რენტაბელობა მხოლოდ <?php echo number_format($roi_percent, 2); ?>%-ია. გადახედეთ ბიზნეს მოდელს.</p>
                    </div>
                </div>
                <?php else: ?>
                <div class="recommendation danger">
                    <i class="fas fa-fire"></i>
                    <div>
                        <strong>ზარალის ზონა 🔥</strong>
                        <p>ბიზნესი ზარალით მუშაობს! სასწრაფი ზომები აუცილებელია.</p>
                    </div>
                </div>
                <?php endif; ?>
                
                <?php if ($avg_transaction_value < 30): ?>
                <div class="recommendation info">
                    <i class="fas fa-lightbulb"></i>
                    <div>
                        <strong>საშუალო ჩეკის გაზრდის შესაძლებლობა 💡</strong>
                        <p>საშუალო ჩეკი <?php echo number_format($avg_transaction_value, 2); ?> ₾-ია. შესთავაზეთ კომბო მენიუ.</p>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>
</html>