<?php
// /home/mvpuufsr/calc/calc.lomsia.ge/includes/session_check.php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// სესიის ვადის გამოწმება (30 წუთი)
$session_timeout = 30 * 60; // 30 წუთი წამებში

if (isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY'] > $session_timeout)) {
    // სესიის ვადა გაუვიდა
    session_unset();
    session_destroy();
    
    if (isset($_SERVER['REQUEST_URI'])) {
        $_SESSION['redirect_after_login'] = $_SERVER['REQUEST_URI'];
    }
    
    header('Location: /admin/login.php?error=session_expired');
    exit();
}

// განაახლეთ ბოლო აქტივობის დრო
$_SESSION['LAST_ACTIVITY'] = time();

// სესიის ID-ის რეგენერაცია თორე შეტევებისგან
if (!isset($_SESSION['CREATED'])) {
    $_SESSION['CREATED'] = time();
} elseif (time() - $_SESSION['CREATED'] > 1800) {
    // 30 წუთში ერთხელ
    session_regenerate_id(true);
    $_SESSION['CREATED'] = time();
}
?>