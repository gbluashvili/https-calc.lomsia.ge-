<?php

function calculateDishCost(mysqli $conn, int $dish_id): float
{
    $sql = "
        SELECT 
            dc.quantity,
            dc.unit,
            dc.yield_coeff,
            p.price_per_kg,
            p.unit_weight_kg
        FROM dish_calc dc
        JOIN products p ON p.id = dc.product_id
        WHERE dc.dish_id = ?
    ";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $dish_id);
    $stmt->execute();

    $stmt->bind_result($quantity, $unit, $yield, $price_per_kg, $unit_weight);

    $total = 0;

    while ($stmt->fetch()) {

        if ($unit === 'გრ') {
            $qty_kg = ($quantity / 1000);
        }
        elseif ($unit === 'კგ') {
            $qty_kg = $quantity;
        }
        elseif ($unit === 'ცალი') {
            if ($unit_weight === null) {
                continue; // ან throw exception
            }
            $qty_kg = $quantity * $unit_weight;
        }
        else {
            continue;
        }

        $qty_kg *= $yield;

        $total += $qty_kg * $price_per_kg;
    }

    return round($total, 2);
}

// CSRF ტოკენის ფუნქციები
function generateCsrfToken() {
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    
    return $_SESSION['csrf_token'];
}

function validateCsrfToken($token) {
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    
    if (empty($token) || empty($_SESSION['csrf_token'])) {
        return false;
    }
    
    return hash_equals($_SESSION['csrf_token'], $token);
}

// ავტომატურად შევქმნათ CSRF ტოკენი თუ არ არსებობს
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
?>