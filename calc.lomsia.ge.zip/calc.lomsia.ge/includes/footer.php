<!-- Common Footer -->
<div class="footer">
    <div class="footer-content">
        <div class="footer-section">
            <h4>🍴 Restaurant CMS</h4>
            <p>რესტორნის მართვის სისტემა</p>
            <p>ვერსია: 2.0.0</p>
        </div>
        
        <div class="footer-section">
            <h4>სწრაფი ბმულები</h4>
            <ul>
                <li><a href="index.php">მთავარი</a></li>
                <li><a href="warehouse.php">საწყობი</a></li>
                <li><a href="menu.php">მენიუ</a></li>
                <li><a href="analytics.php">ანალიტიკა</a></li>
            </ul>
        </div>
        
        <div class="footer-section">
            <h4>ინსტრუმენტები</h4>
            <ul>
                <li><a href="inventory.php">ინვენტარიზაცია</a></li>
                <li><a href="import_dishes.php">მენიუს იმპორტი</a></li>
                <li><a href="import_products_v2.php">პროდუქტების იმპორტი</a></li>
                <li><a href="suppliers.php">მომწოდებლები</a></li>
            </ul>
        </div>
        
        <div class="footer-section">
            <h4>კონტაქტი</h4>
            <p>ტელ: +995 5579444458</p>
            <p>Email: info@lomsia.ge</p>
            <p>© <?php echo date('Y'); ?> ყველა უფლება დაცულია</p>
        </div>
    </div>
    
    <div class="footer-bottom">
        <p>სისტემის დრო: <?php echo date('d.m.Y H:i:s'); ?></p>
    </div>
</div>

<!-- Common JavaScript -->
<script>
// Global configuration
const SITE_CONFIG = {
    currency: '₾',
    dateFormat: 'dd.mm.yyyy',
    language: 'ka'
};

// Common utility functions
function formatCurrency(amount) {
    return parseFloat(amount).toFixed(2) + ' ' + SITE_CONFIG.currency;
}

function formatNumber(number, decimals = 3) {
    return parseFloat(number).toFixed(decimals);
}

function showLoading(selector = 'body') {
    $(selector).append('<div class="loading-overlay"><div class="loading-spinner"></div></div>');
}

function hideLoading() {
    $('.loading-overlay').remove();
}

// DataTables Georgian language configuration
if ($.fn.DataTable) {
    $.extend(true, $.fn.dataTable.defaults, {
        "language": {
            "url": "//cdn.datatables.net/plug-ins/1.11.5/i18n/ka.json"
        },
        "pageLength": 25,
        "responsive": true,
        "dom": '<"top"lf>rt<"bottom"ip><"clear">'
    });
}

// Auto-hide alerts after 5 seconds
$(document).ready(function() {
    setTimeout(function() {
        $('.alert-box').fadeOut(500, function() {
            $(this).remove();
        });
    }, 5000);
    
    // Close alert on click
    $('.alert-box').on('click', function() {
        $(this).fadeOut(300);
    });
    
    // Confirm dialog for destructive actions
    $('.confirm-action').on('click', function(e) {
        const message = $(this).data('confirm') || 'დარწმუნებული ხართ?';
        if (!confirm(message)) {
            e.preventDefault();
            return false;
        }
    });
});
</script>

</body>
</html>