<?php
// /home/mvpuufsr/calc/calc.lomsia.ge/includes/auth_check.php

function checkPageAccess($conn, $user_id, $current_page) {
    // ადმინისტრატორებს (admin, super_admin) ყველა გვერდზე წვდომა აქვთ
    if (isset($_SESSION['user_role']) && ($_SESSION['user_role'] === 'admin' || $_SESSION['user_role'] === 'super_admin')) {
        return true;
    }
    
    // admin/admin_panel.php - მხოლოდ ადმინისტრატორებს
    if ($current_page === 'admin/admin_panel.php') {
        return false; // მხოლოდ admin/super_admin
    }
    
    // წამოიღეთ მომხმარებლის წვდომები
    $sql = "SELECT permissions FROM users WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result && $user = $result->fetch_assoc()) {
        $permissions = json_decode($user['permissions'] ?? '[]', true);
        
        // შეამოწმეთ აქვს თუ არა წვდომა მიმდინარე გვერდზე
        if (isset($permissions[$current_page]) && $permissions[$current_page]) {
            return true;
        }
    }
    
    return false;
}

// ავტომატური შემოწმების ფუნქცია
function checkAccessAndRedirect($conn) {
    // მიმდინარე გვერდის დადგენა
    $current_script = $_SERVER['SCRIPT_NAME'];
    $current_page = '';
    
    // გადაიყვანეთ სრული გზა გვერდის მისამართად
    if (strpos($current_script, '/admin/') !== false) {
        $current_page = 'admin/' . basename($current_script);
    } elseif (strpos($current_script, '/public/') !== false) {
        $current_page = 'public/' . basename($current_script);
    } else {
        $current_page = basename($current_script);
    }
    
    // ადმინისტრატორებისთვის ყოველთვის დაუბრუნეთ true
    if (isset($_SESSION['user_role']) && ($_SESSION['user_role'] === 'admin' || $_SESSION['user_role'] === 'super_admin')) {
        return true;
    }
    
    // admin/admin_panel.php - მხოლოდ ადმინისტრატორებისთვის
    if ($current_page === 'admin/admin_panel.php') {
        header('Location: ../public/access_denied.php');
        exit();
    }
    
    // შემოწმება ჩვეულებრივი მომხმარებლებისთვის
    if (!checkPageAccess($conn, $_SESSION['user_id'], $current_page)) {
        header('Location: ../public/access_denied.php');
        exit();
    }
    
    return true;
}
?>