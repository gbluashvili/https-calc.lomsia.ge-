<?php
// /home/mvpuufsr/calc/calc.lomsia.ge/includes/header.php
?>
<!DOCTYPE html>
<html lang="ka">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($page_title) ? $page_title . ' - ' : ''; ?>Restaurant CMS</title>
    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.css">
    <script type="text/javascript" src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.js"></script>
    
    <!-- Chart.js for Analytics -->
    <?php if (basename($_SERVER['PHP_SELF']) === 'analytics.php'): ?>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <?php endif; ?>
    
    <!-- Select2 for dropdowns -->
    <?php if (in_array(basename($_SERVER['PHP_SELF']), ['warehouse.php', 'menu.php'])): ?>
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <?php endif; ?>
    
    <link rel="stylesheet" href="../css/style.css">
    <style>
        /* გამოსვლის ღილაკის სტილები */
        .logout-btn {
            position: fixed;
            top: 20px;
            right: 20px;
            background: linear-gradient(to right, #e53e3e, #c53030);
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 8px;
            text-decoration: none;
            font-weight: 600;
            z-index: 1000;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            transition: all 0.3s;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .admin-panel-btn {
            position: fixed;
            top: 20px;
            right: 160px; /* გამოსვლის ღილაკისგან მარჯვნივ */
            background: linear-gradient(to right, #4c51bf, #2d3748);
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 8px;
            text-decoration: none;
            font-weight: 600;
            z-index: 1000;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            transition: all 0.3s;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .logout-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.15);
            background: linear-gradient(to right, #c53030, #9b2c2c);
        }
        
        .admin-panel-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.15);
            background: linear-gradient(to right, #2d3748, #1a202c);
        }
        
        .user-info-header {
            position: fixed;
            top: 20px;
            left: 20px;
            background: rgba(255, 255, 255, 0.95);
            padding: 10px 15px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            z-index: 1000;
            font-size: 0.9rem;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .user-avatar {
            width: 32px;
            height: 32px;
            background: linear-gradient(135deg, #4c51bf 0%, #2d3748 100%);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
            font-size: 0.9rem;
        }
        
        .user-details {
            display: flex;
            flex-direction: column;
        }
        
        .user-name {
            font-weight: 600;
            color: #2d3748;
        }
        
        .user-role {
            font-size: 0.8rem;
            color: #718096;
        }
        
        /* ადმინისტრატორებისთვის დამატებითი სტილები */
        .admin-badge {
            background: linear-gradient(to right, #00c292, #00a884);
            color: white;
            padding: 2px 8px;
            border-radius: 12px;
            font-size: 0.7rem;
            font-weight: bold;
            margin-left: 5px;
        }
        
        @media (max-width: 768px) {
            .logout-btn, .admin-panel-btn {
                top: 10px;
                padding: 8px 15px;
                font-size: 0.9rem;
            }
            
            .logout-btn {
                right: 10px;
            }
            
            .admin-panel-btn {
                right: 120px; /* მობილურისთვის ნაკლები მანძილი */
            }
            
            .user-info-header {
                top: 10px;
                left: 10px;
                padding: 8px 12px;
                font-size: 0.8rem;
            }
            
            .user-avatar {
                width: 28px;
                height: 28px;
                font-size: 0.8rem;
            }
            
            /* მობილურისთვის სტეკირება */
            @media (max-width: 480px) {
                .admin-panel-btn {
                    right: 10px;
                    top: 60px; /* ქვემოთ გადავიტანოთ */
                }
                
                .logout-btn {
                    top: 60px;
                    right: 160px;
                }
            }
        }
    </style>
</head>
<body>

<!-- მომხმარებლის ინფორმაცია -->
<?php 
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (isset($_SESSION['user_id'])): 
    $username = $_SESSION['username'] ?? '';
    $full_name = $_SESSION['full_name'] ?? $username;
    $user_role = $_SESSION['user_role'] ?? 'მომხმარებელი';
    $first_letter = strtoupper(substr($username, 0, 1));
    
    // შევამოწმოთ არის თუ არა ადმინისტრატორი
    $is_admin = ($user_role === 'admin' || $user_role === 'super_admin');
?>
<div class="user-info-header">
    <div class="user-avatar">
        <?php echo $first_letter; ?>
    </div>
    <div class="user-details">
        <div class="user-name">
            <?php echo htmlspecialchars($full_name); ?>
            <?php if ($is_admin): ?>
                <span class="admin-badge">ADMIN</span>
            <?php endif; ?>
        </div>
        <div class="user-role"><?php echo htmlspecialchars($user_role); ?></div>
    </div>
</div>

<?php if ($is_admin): ?>
<a href="/admin/admin_panel.php" class="admin-panel-btn" title="ადმინისტრაციული პანელი">
    👑 ადმინ პანელი
</a>
<?php endif; ?>

<a href="/admin/logout.php" class="logout-btn" onclick="return confirm('დარწმუნებული ხართ რომ გსურთ სისტემიდან გამოსვლა?')">
    🚪 გამოსვლა
</a>
<?php endif; ?>

<!-- Navigation Header -->
<div class="top-bar" style="margin-top: <?php echo isset($_SESSION['user_id']) ? '80px' : '20px'; ?>;">
    <h2>
        <?php 
        $page_titles = [
            'index.php' => 'მთავარი დაფა',
            'warehouse.php' => '📦 საწყობის მართვა',
            'menu.php' => '🍳 მენიუს მართვა',
            'analytics.php' => '📊 ბიზნეს ანალიტიკა',
            'sales_history.php' => '📈 გაყიდვების ისტორია',
            'reports.php' => '📋 რეპორტები',
            'suppliers.php' => '🤝 მომწოდებლები',
            'inventory.php' => '📝 ინვენტარიზაცია',
            'dishes.php' => '🍽️ კერძების მართვა',
            'products.php' => '📦 პროდუქტების მართვა',
            'import_dishes.php' => '📥 მენიუს იმპორტი',
            'import_products_v2.php' => '📥 პროდუქტების იმპორტი',
            'money_movement.php' => '💰 ფულის მოძრაობა'
        ];
        
        $current_page = basename($_SERVER['PHP_SELF']);
        echo $page_titles[$current_page] ?? 'Restaurant CMS';
        ?>
    </h2>
    <div class="nav-links">
        <a href="index.php" class="btn btn-blue <?php echo ($current_page === 'index.php') ? 'active' : ''; ?>">🏠 მთავარი</a>
        <a href="warehouse.php" class="btn btn-green <?php echo ($current_page === 'warehouse.php') ? 'active' : ''; ?>">📦 საწყობი</a>
        <a href="menu.php" class="btn btn-purple <?php echo ($current_page === 'menu.php') ? 'active' : ''; ?>">🍳 მენიუ</a>
        <a href="analytics.php" class="btn btn-cyan <?php echo ($current_page === 'analytics.php') ? 'active' : ''; ?>">📊 ანალიტიკა</a>
        <a href="sales_history.php" class="btn btn-orange <?php echo ($current_page === 'sales_history.php') ? 'active' : ''; ?>">📈 ისტორია</a>
        <a href="reports.php" class="btn btn-yellow <?php echo ($current_page === 'reports.php') ? 'active' : ''; ?>">📋 რეპორტები</a>
        <a href="money_movement.php" class="btn btn-red <?php echo ($current_page === 'money_movement.php') ? 'active' : ''; ?>">💰 ფულის მოძრაობა</a>
    </div>
</div>

<!-- Session Messages -->
<?php if (session_status() === PHP_SESSION_ACTIVE): ?>
    <?php if (isset($_SESSION['success']) && !empty($_SESSION['success'])): ?>
    <div class="alert-box success">
        ✅ <?php echo htmlspecialchars($_SESSION['success']); ?>
        <?php unset($_SESSION['success']); ?>
    </div>
    <?php endif; ?>
    
    <?php if (isset($_SESSION['error']) && !empty($_SESSION['error'])): ?>
    <div class="alert-box error">
        ❌ <?php echo htmlspecialchars($_SESSION['error']); ?>
        <?php unset($_SESSION['error']); ?>
    </div>
    <?php endif; ?>
    
    <?php if (isset($_SESSION['warning']) && !empty($_SESSION['warning'])): ?>
    <div class="alert-box warning">
        ⚠️ <?php echo htmlspecialchars($_SESSION['warning']); ?>
        <?php unset($_SESSION['warning']); ?>
    </div>
    <?php endif; ?>
<?php endif; ?>

<script>
// გამოსვლის დადასტურება
document.querySelectorAll('.logout-btn').forEach(btn => {
    btn.addEventListener('click', function(e) {
        if (!confirm('დარწმუნებული ხართ რომ გსურთ სისტემიდან გამოსვლა?')) {
            e.preventDefault();
        }
    });
});

// ადმინ პანელის დამატებითი ფუნქცია
document.querySelectorAll('.admin-panel-btn').forEach(btn => {
    btn.addEventListener('click', function(e) {
        // შეგიძლიათ დაამატოთ დამატებითი ლოგიკა აქ
        console.log('ადმინ პანელზე გადასვლა...');
    });
});

// სესიის ვადის მონიტორინგი
let lastActivity = Date.now();
const sessionTimeout = 45 * 60 * 1000; // 45 წუთი

function resetActivityTimer() {
    lastActivity = Date.now();
}

// აქტივობის აღრიცხვა
document.addEventListener('mousemove', resetActivityTimer);
document.addEventListener('keypress', resetActivityTimer);
document.addEventListener('click', resetActivityTimer);

// ვადის შემოწმება
setInterval(() => {
    const now = Date.now();
    if (now - lastActivity > sessionTimeout) {
        if (confirm('თქვენი სესიის ვადა გაუვიდა. გსურთ გაიაროთ ავტორიზაცია ხელახლა?')) {
            window.location.href = '/admin/logout.php?expired=true';
        }
    }
}, 60000); // შეამოწმეთ ყოველ წუთში

// ადმინ პანელზე წვდომის შემოწმება (არასავალდებულო)
function checkAdminAccess() {
    // თუ გსურთ დამატებითი უსაფრთხოების შემოწმება AJAX-ით
    fetch('/admin/check_admin.php')
        .then(response => response.json())
        .then(data => {
            if (!data.is_admin) {
                const adminBtn = document.querySelector('.admin-panel-btn');
                if (adminBtn) {
                    adminBtn.style.display = 'none';
                }
            }
        })
        .catch(error => {
            console.error('Admin check error:', error);
        });
}

// გაუშვით შემოწმება გვერდის ჩატვირთვისას
window.addEventListener('load', function() {
    // checkAdminAccess(); // ამოიღეთ კომენტარი თუ გსურთ AJAX შემოწმება
});
</script>