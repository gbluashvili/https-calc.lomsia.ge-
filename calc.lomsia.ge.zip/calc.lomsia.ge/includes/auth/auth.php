<?php
session_start();
require __DIR__ . "/../config/db.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: /login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$page_key = basename($_SERVER['PHP_SELF'], ".php");

// Admin-ს ყველაფერზე აქვს წვდომა
$role = $db->query("
    SELECT role FROM users WHERE id = $user_id
")->fetch_assoc()['role'];

if ($role === 'admin') {
    return;
}

// სხვა იუზერები
$stmt = $db->prepare("
    SELECT p.allowed FROM permissions p
    JOIN pages pg ON pg.id = p.page_id
    WHERE p.user_id = ? AND pg.page_key = ? AND p.allowed = 1
");
$stmt->bind_param("is", $user_id, $page_key);
$stmt->execute();

if ($stmt->get_result()->num_rows === 0) {
    die("⛔ წვდომა აკრძალულია");
}
