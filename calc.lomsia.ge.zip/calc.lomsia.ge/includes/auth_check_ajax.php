<?php
// /home/mvpuufsr/calc/calc.lomsia.ge/includes/auth_check_ajax.php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// თუ არაავტორიზებულია
if (!isset($_SESSION['user_id'])) {
    // მხოლოდ AJAX მოთხოვნებისთვის
    if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && 
        strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
        
        header('Content-Type: application/json');
        echo json_encode([
            'status' => 'unauthorized',
            'html' => get_login_modal_html(),
            'redirect' => 'https://calc.lomsia.ge/admin/login.php'
        ]);
        exit();
    } else {
        // ჩვეულებრივი მოთხოვნისთვის - გადამისამართება
        header('Location: https://calc.lomsia.ge/admin/login.php?redirect=' . 
               urlencode($_SERVER['REQUEST_URI']));
        exit();
    }
}

function get_login_modal_html() {
    ob_start();
    ?>
    <div id="loginModal" style="display: none;">
        <div style="position: fixed; top: 0; left: 0; width: 100%; height: 100%; 
                   background: rgba(0,0,0,0.8); z-index: 9999; display: flex; 
                   align-items: center; justify-content: center;">
            <div style="background: white; padding: 30px; border-radius: 15px; 
                       width: 90%; max-width: 400px; position: relative;">
                <button onclick="closeLoginModal()" style="position: absolute; top: 10px; 
                       right: 10px; background: none; border: none; font-size: 24px; 
                       cursor: pointer;">×</button>
                
                <h2 style="text-align: center; margin-bottom: 20px;">ავტორიზაცია</h2>
                
                <form id="ajaxLoginForm" onsubmit="return submitLoginForm(event)">
                    <div style="margin-bottom: 15px;">
                        <input type="text" name="username" placeholder="მომხმარებელი" 
                               style="width: 100%; padding: 10px; border: 1px solid #ddd; 
                               border-radius: 5px;" required>
                    </div>
                    
                    <div style="margin-bottom: 20px;">
                        <input type="password" name="password" placeholder="პაროლი" 
                               style="width: 100%; padding: 10px; border: 1px solid #ddd; 
                               border-radius: 5px;" required>
                    </div>
                    
                    <button type="submit" style="width: 100%; padding: 12px; 
                            background: #4CAF50; color: white; border: none; 
                            border-radius: 5px; cursor: pointer;">
                        შესვლა
                    </button>
                </form>
            </div>
        </div>
    </div>
    
    <script>
    function showLoginModal() {
        document.getElementById('loginModal').style.display = 'block';
    }
    
    function closeLoginModal() {
        document.getElementById('loginModal').style.display = 'none';
    }
    
    function submitLoginForm(e) {
        e.preventDefault();
        
        const formData = new FormData(e.target);
        
        fetch('https://calc.lomsia.ge/admin/process_login.php', {
            method: 'POST',
            body: formData,
            headers: {
                'X-Requested-With': 'XMLHttpRequest'
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                window.location.reload();
            } else {
                alert(data.message || 'შეცდომა');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('სერვერული შეცდომა');
        });
        
        return false;
    }
    
    // ავტომატურად გახსნა მოდალური ფანჯარა
    document.addEventListener('DOMContentLoaded', function() {
        showLoginModal();
    });
    </script>
    <?php
    return ob_get_clean();
}
?>