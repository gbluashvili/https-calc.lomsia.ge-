<?php
require_once __DIR__ . '/../config/db.php';

if (isset($_POST['import'])) {
    $file = $_FILES['csv_file']['tmp_name'];
    $handle = fopen($file, "r");
    
    $imported = 0;
    $updated = 0;

    while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
        // მონაცემების ამოღება სვეტებიდან (ინდექსები 0, 1, 2 თქვენი ფაილის მიხედვით)
        $name = trim($mysqli->real_escape_string($data[1])); 
        $price = floatval($data[2]);
        $vat_info = isset($data[3]) ? trim($data[3]) : 'დღგ-თი';

        if (!empty($name) && $price > 0) {
            // ვამოწმებთ არსებობს თუ არა
            $check = $mysqli->query("SELECT id FROM products WHERE name = '$name'");
            
            if ($check->num_rows > 0) {
                // განახლება
                $mysqli->query("UPDATE products SET price = $price, vat_status = '$vat_info' WHERE name = '$name'");
                $updated++;
            } else {
                // ახლის დამატება
                $mysqli->query("INSERT INTO products (name, price, unit, vat_status) VALUES ('$name', $price, 'კგ', '$vat_info')");
                $imported++;
            }
        }
    }
    fclose($handle);
    $msg = "წარმატება: დაემატა $imported, განახლდა $updated პროდუქტი.";
}
?>

<!DOCTYPE html>
<html lang="ka">
<head>
    <meta charset="UTF-8">
    <title>პროდუქტების იმპორტი</title>
    <style>
        body { font-family: sans-serif; background: #f4f7f6; display: flex; justify-content: center; padding: 50px; }
        .card { background: white; padding: 30px; border-radius: 15px; box-shadow: 0 10px 20px rgba(0,0,0,0.1); width: 100%; max-width: 500px; }
        .upload-area { border: 2px dashed #007bff; padding: 30px; text-align: center; margin: 20px 0; border-radius: 10px; cursor: pointer; }
        .btn { background: #007bff; color: white; border: none; padding: 12px 25px; border-radius: 5px; width: 100%; cursor: pointer; font-size: 16px; }
        .success-msg { color: #155724; background: #d4edda; padding: 10px; border-radius: 5px; margin-bottom: 20px; }
    </style>
</head>
<body>

<div class="card">
    <h2>📥 მონაცემების იმპორტი</h2>
    <?php if(isset($msg)) echo "<div class='success-msg'>$msg</div>"; ?>
    
    <form method="POST" enctype="multipart/form-data">
        <p>აირჩიეთ CSV ფაილი, სადაც მითითებულია ფასები და დღგ-ს სტატუსი.</p>
        <input type="file" name="csv_file" accept=".csv" required style="margin-bottom: 20px;">
        <button type="submit" name="import" class="btn">ატვირთვა და დამუშავება</button>
    </form>
    <br>
    <a href="index.php" style="color: #666; text-decoration: none;">← პანელზე დაბრუნება</a>
</div>

</body>
</html>