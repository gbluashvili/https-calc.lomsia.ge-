<?php
require_once __DIR__ . '/../config/db.php';
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['status' => 0, 'message' => 'არასწორი მოთხოვნის მეთოდი']);
    exit;
}

if (!isset($_POST['dish_id']) || !isset($_POST['quantity'])) {
    echo json_encode(['status' => 0, 'message' => 'არასრული მონაცემები']);
    exit;
}

$dish_id = intval($_POST['dish_id']);
$quantity = intval($_POST['quantity']);

if ($quantity <= 0) {
    echo json_encode(['status' => 0, 'message' => 'არასწორი რაოდენობა']);
    exit;
}

try {
    // ვიღებთ კერძის ინგრედიენტებს dish_calc ცხრილიდან
    $ingredients_query = "
        SELECT 
            dc.product_id,
            dc.quantity as required_quantity,
            dc.unit,
            p.name as product_name,
            p.quantity as stock_quantity,
            p.unit as product_unit
        FROM dish_calc dc
        JOIN products p ON dc.product_id = p.id
        WHERE dc.dish_id = ?
    ";
    
    $stmt = $mysqli->prepare($ingredients_query);
    if (!$stmt) {
        throw new Exception("Query preparation failed: " . $mysqli->error);
    }
    
    $stmt->bind_param('i', $dish_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $ingredients = $result->fetch_all(MYSQLI_ASSOC);
    
    if (empty($ingredients)) {
        echo json_encode(['status' => 0, 'message' => 'კერძს არ აქვს ინგრედიენტები']);
        exit;
    }
    
    // ვამოწმებთ მარაგს
    $check_results = [];
    $all_have_enough = true;
    
    foreach ($ingredients as $ingredient) {
        $required = floatval($ingredient['required_quantity']) * $quantity;
        $available = floatval($ingredient['stock_quantity']);
        
        $has_enough = $available >= $required;
        $available_percentage = $available > 0 ? ($available / $required) * 100 : 0;
        
        $check_results[] = [
            'product_id' => $ingredient['product_id'],
            'product_name' => $ingredient['product_name'],
            'required' => $required,
            'available' => $available,
            'unit' => $ingredient['unit'],
            'has_enough' => $has_enough,
            'available_percentage' => $available_percentage
        ];
        
        if (!$has_enough) {
            $all_have_enough = false;
        }
    }
    
    echo json_encode([
        'status' => 1,
        'ingredients' => $check_results,
        'all_have_enough' => $all_have_enough,
        'dish_id' => $dish_id,
        'quantity' => $quantity
    ]);
    
} catch (Exception $e) {
    echo json_encode(['status' => 0, 'message' => 'შეცდომა: ' . $e->getMessage()]);
}
?>