<?php
header('Content-Type: application/json');
require_once __DIR__.'/../config/db.php';
require_once __DIR__.'/../functions/product.php';

$product_id = (int)($_POST['product_id'] ?? 0);
$qty        = (float)($_POST['qty'] ?? 0);
$reason     = $_POST['reason'] ?? '';

if ($product_id <= 0 || $qty == 0) {
    echo json_encode(['status'=>0,'message'=>'Invalid data']);
    exit;
}

addStockMovement($mysqli, $product_id, $qty, $reason);

echo json_encode(['status'=>1]);
