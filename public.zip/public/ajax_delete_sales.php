<?php
require_once __DIR__ . '/../config/db.php';
header('Content-Type: application/json');

// ვამოწმებთ, რომ მოთხოვნა POST-ით მოვიდა
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405); // Method Not Allowed
    echo json_encode(['status' => 0, 'message' => 'არასწორი მოთხოვნის მეთოდი']);
    exit;
}

// ვამოწმებთ აქციის პარამეტრს
$action = $_POST['action'] ?? '';

if (empty($action)) {
    echo json_encode(['status' => 0, 'message' => 'მოქმედება არ არის მითითებული']);
    exit;
}

try {
    // ვიწყებთ ტრანზაქციას
    $mysqli->begin_transaction();
    
    // განვსაზღვროთ ცხრილის სახელი (შეამოწმეთ რომელი ცხრილი არსებობს)
    $check_dish_sales = $mysqli->query("SHOW TABLES LIKE 'dish_sales'");
    $table_name = ($check_dish_sales && $check_dish_sales->num_rows > 0) ? 'dish_sales' : 'sales';
    
    switch ($action) {
        case 'delete_single':
            // ერთი ჩანაწერის წაშლა
            $id = intval($_POST['id'] ?? 0);
            if ($id <= 0) {
                throw new Exception('არასწორი ჩანაწერის ID');
            }
            
            $stmt = $mysqli->prepare("DELETE FROM {$table_name} WHERE id = ?");
            $stmt->bind_param('i', $id);
            $stmt->execute();
            
            if ($stmt->affected_rows === 0) {
                throw new Exception('ჩანაწერი ვერ მოიძებნა');
            }
            
            $message = 'ჩანაწერი წარმატებით წაიშალა';
            break;
            
        case 'delete_selected':
            // მრავალი ჩანაწერის წაშლა
            if (!isset($_POST['ids']) || empty($_POST['ids'])) {
                throw new Exception('არაარჩეული ჩანაწერები');
            }
            
            // გადავიყვანოთ IDs მასივად
            $ids = $_POST['ids'];
            if (!is_array($ids)) {
                // თუ არ არის მასივი, შეიძლება იყოს JSON სტრიქონი
                $ids = json_decode($ids, true);
                if (!is_array($ids)) {
                    throw new Exception('არასწორი ფორმატი ID-ებისთვის');
                }
            }
            
            $ids = array_map('intval', $ids);
            $ids = array_filter($ids, function($id) {
                return $id > 0;
            });
            
            if (empty($ids)) {
                throw new Exception('არაარჩეული ჩანაწერები');
            }
            
            // შევქმნათ placeholders
            $placeholders = implode(',', array_fill(0, count($ids), '?'));
            $query = "DELETE FROM {$table_name} WHERE id IN ($placeholders)";
            
            $stmt = $mysqli->prepare($query);
            
            // შევქმნათ ტიპების სტრიქონი
            $types = str_repeat('i', count($ids));
            $stmt->bind_param($types, ...$ids);
            $stmt->execute();
            
            $message = count($ids) . ' ჩანაწერი წარმატებით წაიშალა';
            break;
            
        case 'delete_all':
            // ყველა ჩანაწერის წაშლა
            $stmt = $mysqli->prepare("DELETE FROM {$table_name}");
            $stmt->execute();
            $count = $stmt->affected_rows;
            
            $message = "ყველა ჩანაწერი ($count) წარმატებით წაიშალა";
            break;
            
        default:
            throw new Exception('არასწორი მოქმედება: ' . htmlspecialchars($action));
    }
    
    // ვადასტურებთ ტრანზაქციას
    $mysqli->commit();
    
    echo json_encode([
        'status' => 1,
        'message' => $message,
        'action' => $action
    ]);
    
} catch (Exception $e) {
    // ვაბრუნებთ ტრანზაქციას
    if (isset($mysqli)) {
        $mysqli->rollback();
    }
    
    error_log("Error in ajax_delete_sales.php: " . $e->getMessage());
    
    echo json_encode([
        'status' => 0,
        'message' => 'შეცდომა: ' . $e->getMessage()
    ]);
}
?>