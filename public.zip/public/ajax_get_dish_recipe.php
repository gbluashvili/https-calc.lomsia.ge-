<?php
require_once __DIR__ . '/../config/db.php';

header('Content-Type: application/json; charset=utf-8');

$dish_id = isset($_GET['dish_id']) ? intval($_GET['dish_id']) : 0;

if ($dish_id > 0) {
    // ჯერ შევამოწმოთ არსებობს თუ არა dish_recipe ცხრილი
    $check_table = $mysqli->query("SHOW TABLES LIKE 'dish_recipe'");
    if ($check_table->num_rows == 0) {
        // თუ ცხრილი არ არსებობს, შევქმნათ
        $create_table = "CREATE TABLE IF NOT EXISTS dish_recipe (
            id INT AUTO_INCREMENT PRIMARY KEY,
            dish_id INT NOT NULL,
            product_id INT NOT NULL,
            quantity DECIMAL(10,3) NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (dish_id) REFERENCES dishes(id) ON DELETE CASCADE,
            FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
            UNIQUE KEY unique_dish_product (dish_id, product_id)
        )";
        
        if (!$mysqli->query($create_table)) {
            echo json_encode([
                'status' => 0,
                'message' => 'ცხრილის შექმნის შეცდომა: ' . $mysqli->error
            ], JSON_UNESCAPED_UNICODE);
            exit;
        }
    }
    
    // მოაქვს კერძის რეცეპტი
    $query = "SELECT dr.product_id, dr.quantity, p.name as product_name, p.unit 
              FROM dish_recipe dr 
              LEFT JOIN products p ON dr.product_id = p.id 
              WHERE dr.dish_id = ? 
              ORDER BY p.name ASC";
    
    $stmt = $mysqli->prepare($query);
    if ($stmt) {
        $stmt->bind_param("i", $dish_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        $ingredients = [];
        $total_cost = 0;
        
        while ($row = $result->fetch_assoc()) {
            // გამოთვალე ღირებულება
            $cost_query = "SELECT purchase_price FROM products WHERE id = ?";
            $cost_stmt = $mysqli->prepare($cost_query);
            if ($cost_stmt) {
                $cost_stmt->bind_param("i", $row['product_id']);
                $cost_stmt->execute();
                $cost_result = $cost_stmt->get_result();
                
                if ($cost_row = $cost_result->fetch_assoc()) {
                    $ingredient_cost = $cost_row['purchase_price'] * $row['quantity'];
                    $total_cost += $ingredient_cost;
                }
                $cost_stmt->close();
            }
            
            $ingredients[] = [
                'product_id' => $row['product_id'],
                'quantity' => floatval($row['quantity']),
                'product_name' => $row['product_name'],
                'unit' => $row['unit']
            ];
        }
        
        $stmt->close();
        
        echo json_encode([
            'status' => 1,
            'ingredients' => $ingredients,
            'total_cost' => $total_cost
        ], JSON_UNESCAPED_UNICODE);
    } else {
        echo json_encode([
            'status' => 1,
            'ingredients' => [],
            'total_cost' => 0,
            'message' => 'რეცეპტი ჯერ არ არსებობს'
        ], JSON_UNESCAPED_UNICODE);
    }
} else {
    echo json_encode([
        'status' => 0,
        'message' => 'არასწორი კერძის ID'
    ], JSON_UNESCAPED_UNICODE);
}

$mysqli->close();
?>