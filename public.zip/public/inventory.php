<?php
require_once __DIR__ . '/../config/db.php';

// თუ ფორმა დადასტურდა, ვინახავთ მონაცემებს
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach ($_POST['counted'] as $product_id => $qty) {
        if ($qty !== '') {
            $theo_qty = $_POST['theoretical'][$product_id];
            
            // 1. ვინახავთ ისტორიას
            $stmt = $mysqli->prepare("INSERT INTO inventory_counts (product_id, counted_qty, theoretical_qty) VALUES (?, ?, ?)");
            $stmt->bind_param("idd", $product_id, $qty, $theo_qty);
            $stmt->execute();

            // 2. ვაახლებთ ძირითად ნაშთს საწყობში რეალური ციფრით
            $update = $mysqli->prepare("UPDATE products SET quantity = ? WHERE id = ?");
            $update->bind_param("di", $qty, $product_id);
            $update->execute();
        }
    }
    header("Location: inventory.php?success=1");
    exit;
}

// პროდუქტების წამოღება (ფასთან ერთად)
$products = $mysqli->query("SELECT * FROM products ORDER BY name ASC")->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="ka">
<head>
    <meta charset="UTF-8">
    <title>ინვენტარიზაცია - Restaurant CMS</title>
    <style>
        body { font-family: sans-serif; background: #f4f7f6; padding: 20px; }
        .container { background: white; padding: 25px; border-radius: 12px; box-shadow: 0 4px 10px rgba(0,0,0,0.05); max-width: 1000px; margin: auto; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { padding: 12px; border-bottom: 1px solid #eee; text-align: left; }
        th { background: #f8f9fa; color: #555; }
        .diff-pos { color: #28a745; font-weight: bold; } /* მწვანე ზედმეტობისთვის */
        .diff-neg { color: #dc3545; font-weight: bold; } /* წითელი დანაკლისისთვის */
        input[type="number"] { width: 90px; padding: 8px; border: 1px solid #ddd; border-radius: 4px; font-size: 14px; }
        .btn-save { background: #28a745; color: white; padding: 12px 25px; border: none; border-radius: 5px; cursor: pointer; float: right; margin-top: 20px; font-size: 16px; transition: 0.3s; }
        .btn-save:hover { background: #218838; }
        .header-flex { display: flex; justify-content: space-between; align-items: center; border-bottom: 2px solid #eee; padding-bottom: 15px; }
        .unit-label { color: #888; font-size: 0.9em; }
    </style>
</head>
<body>

<div class="container">
    <div class="header-flex">
        <h2 style="margin:0;">📝 ინვენტარიზაცია (Stock Count)</h2>
        <a href="index.php" style="text-decoration: none; color: #007bff; font-weight: bold;">← მთავარი პანელი</a>
    </div>

    <?php if(isset($_GET['success'])): ?>
        <div style="background: #d4edda; color: #155724; padding: 15px; border-radius: 5px; margin: 20px 0; border: 1px solid #c3e6cb;">
            ✅ ინვენტარიზაცია წარმატებით დასრულდა! საწყობის ნაშთები განახლდა რეალური მონაცემებით.
        </div>
    <?php endif; ?>

    <form method="POST" onsubmit="return confirm('დარწმუნებული ხართ, რომ გსურთ ინვენტარიზაციის დასრულება? ნაშთები გადაიწერება!');">
        <table>
            <thead>
                <tr>
                    <th>პროდუქტი</th>
                    <th>თეორიული ნაშთი</th>
                    <th>რეალური ნაშთი</th>
                    <th>სხვაობა (Qty)</th>
                    <th>სხვაობა (₾)</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($products as $p): ?>
                <tr>
                    <td>
                        <strong><?= htmlspecialchars($p['name']) ?></strong><br>
                        <span class="unit-label">1 <?= $p['unit'] ?> = <?= number_format($p['price'], 2) ?> ₾</span>
                    </td>
                    <td>
                        <span id="theo_<?= $p['id'] ?>"><?= number_format($p['quantity'], 3) ?></span> <?= $p['unit'] ?>
                        <input type="hidden" name="theoretical[<?= $p['id'] ?>]" value="<?= $p['quantity'] ?>">
                    </td>
                    <td>
                        <input type="number" step="0.001" name="counted[<?= $p['id'] ?>]" 
                               class="count-input" 
                               data-id="<?= $p['id'] ?>" 
                               data-theo="<?= $p['quantity'] ?>"
                               data-price="<?= $p['price'] ?>"
                               placeholder="0.000">
                    </td>
                    <td><span id="diff_<?= $p['id'] ?>">0.000</span></td>
                    <td><span id="cost_diff_<?= $p['id'] ?>">0.00</span> ₾</td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        
        <button type="submit" class="btn-save">💾 ინვენტარიზაციის შენახვა</button>
        <div style="clear:both;"></div>
    </form>
</div>



<script>
document.querySelectorAll('.count-input').forEach(input => {
    input.addEventListener('input', function() {
        const id = this.dataset.id;
        const theo = parseFloat(this.dataset.theo) || 0;
        const price = parseFloat(this.dataset.price) || 0;
        const counted = parseFloat(this.value);

        // თუ ველი ცარიელია, გავანულოთ სხვაობები
        if (isNaN(counted)) {
            document.getElementById('diff_' + id).textContent = "0.000";
            document.getElementById('cost_diff_' + id).textContent = "0.00";
            document.getElementById('diff_' + id).className = "";
            document.getElementById('cost_diff_' + id).className = "";
            return;
        }
        
        // გაანგარიშება
        const diff = counted - theo;
        const costDiff = diff * price;
        
        const diffSpan = document.getElementById('diff_' + id);
        const costSpan = document.getElementById('cost_diff_' + id);
        
        // მნიშვნელობების გამოტანა
        diffSpan.textContent = (diff > 0 ? "+" : "") + diff.toFixed(3);
        costSpan.textContent = (costDiff > 0 ? "+" : "") + costDiff.toFixed(2);
        
        // ფერების მართვა
        if (diff < 0) {
            diffSpan.className = 'diff-neg';
            costSpan.className = 'diff-neg';
        } else if (diff > 0) {
            diffSpan.className = 'diff-pos';
            costSpan.className = 'diff-pos';
        } else {
            diffSpan.className = '';
            costSpan.className = '';
        }
    });
});
</script>

</body>
</html>