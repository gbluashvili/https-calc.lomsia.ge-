<?php
require_once __DIR__ . '/../config/db.php';

$date_from = $_GET['date_from'] ?? date('Y-m-d');
$date_to   = $_GET['date_to']   ?? date('Y-m-d');
$filter_dish = $_GET['dish_id'] ?? 'all';

// კერძების სია ფილტრისთვის
$dishes_list = $mysqli->query("SELECT id, name FROM dishes ORDER BY name ASC")->fetch_all(MYSQLI_ASSOC);

// მთავარი რეპორტის SQL
$sql = "
    SELECT 
        d.name AS dish_name,
        p.name AS product_name,
        dc.unit,
        SUM(s.quantity) AS total_sold_dishes,
        SUM(dc.quantity * s.quantity) AS total_usage
    FROM sales s
    JOIN dishes d ON s.dish_id = d.id
    JOIN dish_calc dc ON d.id = dc.dish_id
    JOIN products p ON dc.product_id = p.id
    WHERE DATE(s.sale_date) BETWEEN ? AND ?
";

if ($filter_dish !== 'all') {
    $sql .= " AND d.id = " . intval($filter_dish);
}

$sql .= " GROUP BY d.id, p.id ORDER BY d.name ASC, total_usage DESC";

$stmt = $mysqli->prepare($sql);
$stmt->bind_param("ss", $date_from, $date_to);
$stmt->execute();
$usage_data = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="ka">
<head>
    <meta charset="UTF-8">
    <title>ხარჯვა კერძების მიხედვით</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.css">
    <script type="text/javascript" src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.js"></script>
    <style>
        body { font-family: sans-serif; padding: 20px; background: #f4f7f6; }
        .container { background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .filter-box { background: #e9ecef; padding: 20px; border-radius: 8px; margin-bottom: 20px; display: flex; gap: 15px; align-items: flex-end; flex-wrap: wrap; }
        .btn { padding: 10px 15px; border: none; border-radius: 4px; cursor: pointer; color: white; text-decoration: none; background: #007bff; }
        .btn-secondary { background: #6c757d; }
        label { display: block; font-size: 12px; font-weight: bold; margin-bottom: 5px; }
        select, input { padding: 8px; border: 1px solid #ccc; border-radius: 4px; }
    </style>
</head>
<body>

<div class="container">
    <div style="display:flex; justify-content: space-between; align-items: center;">
        <h2>📉 ინგრედიენტების ხარჯვა კერძების მიხედვით</h2>
        <a href="index.php" class="btn btn-secondary">🏠 მთავარი</a>
    </div>

    <form method="GET" class="filter-box">
        <div>
            <label>თარიღიდან:</label>
            <input type="date" name="date_from" value="<?= $date_from ?>">
        </div>
        <div>
            <label>თარიღამდე:</label>
            <input type="date" name="date_to" value="<?= $date_to ?>">
        </div>
        <div>
            <label>გაფილტრე კერძით:</label>
            <select name="dish_id">
                <option value="all">ყველა კერძი</option>
                <?php foreach($dishes_list as $dl): ?>
                    <option value="<?= $dl['id'] ?>" <?= $filter_dish == $dl['id'] ? 'selected' : '' ?>>
                        <?= htmlspecialchars($dl['name']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <button type="submit" class="btn">ნახვა</button>
    </form>

    <table id="usageTable" class="display">
        <thead>
            <tr>
                <th>კერძი</th>
                <th>გაიყიდა (პორცია)</th>
                <th>ინგრედიენტი</th>
                <th>ჯამური ხარჯი</th>
                <th>ერთეული</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach($usage_data as $row): ?>
            <tr>
                <td><strong><?= htmlspecialchars($row['dish_name']) ?></strong></td>
                <td><?= $row['total_sold_dishes'] ?></td>
                <td><?= htmlspecialchars($row['product_name']) ?></td>
                <td style="color: #d63384; font-weight: bold;">
                    <?php 
                        if($row['unit'] == 'გრ') {
                            echo number_format($row['total_usage'] / 1000, 3) . ' (კგ)';
                        } else {
                            echo number_format($row['total_usage'], 3);
                        }
                    ?>
                </td>
                <td><?= ($row['unit'] == 'გრ' ? 'კგ/გრ' : $row['unit']) ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<script>
$(document).ready(function() {
    $('#usageTable').DataTable({
        "language": { "url": "//cdn.datatables.net/plug-ins/1.11.5/i18n/ka.json" },
        "pageLength": 50,
        "order": [[ 0, "asc" ]]
    });
});
</script>

</body>
</html>