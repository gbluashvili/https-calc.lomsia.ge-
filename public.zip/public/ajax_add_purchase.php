<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../config/db.php';

// მონაცემების მიღება და ვალიდაცია
$p_id      = intval($_POST['product_id']);
$qty_pack  = floatval($_POST['qty_pack'] ?? 0);
$conv      = floatval($_POST['conv_factor'] ?? 1);
$unit_cost = floatval($_POST['price']); // საბაზო ერთეულის ფასი
$supplier  = $_POST['supplier'] ?? '';
$invoice   = $_POST['invoice'] ?? '';
$p_date    = !empty($_POST['purchase_date']) ? $_POST['purchase_date'] : date('Y-m-d');

// Excel-ის ლოგიკა: Qty Base = Qty Pack * Conv
// თუ Qty Pack მითითებულია, ვიყენებთ მას, თუ არა - პირდაპირ Qty Base-ს
$qty_base = ($qty_pack > 0) ? ($qty_pack * $conv) : floatval($_POST['qty_base'] ?? 0);

if ($p_id <= 0 || $qty_base <= 0) {
    echo json_encode(['status' => 0, 'message' => 'მონაცემები არასრულია ან რაოდენობა ნულის ტოლია']);
    exit;
}

$mysqli->begin_transaction();

try {
    // 1. მიმდინარე ნაშთის, ფასის და დღგ-ს სტატუსის წამოღება
    $prod_res = $mysqli->query("SELECT quantity, price, vat_status FROM products WHERE id = $p_id");
    if (!$prod_res || $prod_res->num_rows === 0) {
        throw new Exception("პროდუქტი ვერ მოიძებნა");
    }
    $prod = $prod_res->fetch_assoc();
    
    $current_qty = floatval($prod['quantity']);
    $current_price = floatval($prod['price']);
    
    // საშუალო შეწონილი ფასის ფორმულა (WAC)
    $new_total_qty = $current_qty + $qty_base;
    if ($new_total_qty > 0) {
        $new_weighted_price = (($current_qty * $current_price) + ($qty_base * $unit_cost)) / $new_total_qty;
    } else {
        $new_weighted_price = $unit_cost;
    }

    // 2. ჩაწერა purchases ცხრილში
    $total_sum = $qty_base * $unit_cost;
    
    // შესწორებული bind_param: "ssiddddds" (9 სიმბოლო, ჰარების გარეშე)
    $ins = $mysqli->prepare("INSERT INTO purchases (purchase_date, supplier, product_id, qty_pack, conv_factor, qty_base, unit_cost_base, total_amount, invoice_no) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
    
    if (!$ins) {
        throw new Exception("Prepare failed: " . $mysqli->error);
    }

    // s=string, i=integer, d=double
    $ins->bind_param(
        "ssiddddds", 
        $p_date, 
        $supplier, 
        $p_id, 
        $qty_pack, 
        $conv, 
        $qty_base, 
        $unit_cost, 
        $total_sum, 
        $invoice
    );
    
    if (!$ins->execute()) {
        throw new Exception("Execute failed: " . $ins->error);
    }

    // 3. პროდუქტის განახლება (ახალი ნაშთი + ახალი საშუალო ფასი)
    $upd = $mysqli->prepare("UPDATE products SET quantity = ?, price = ? WHERE id = ?");
    $upd->bind_param("ddi", $new_total_qty, $new_weighted_price, $p_id);
    $upd->execute();

    $mysqli->commit();
    echo json_encode(['status' => 1]);

} catch (Exception $e) {
    $mysqli->rollback();
    echo json_encode(['status' => 0, 'message' => $e->getMessage()]);
}