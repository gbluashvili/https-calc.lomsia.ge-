<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$csvFile = 'products.csv';
echo "<h3>CSV ფაილის შემოწმება: $csvFile</h3>";

if (!file_exists($csvFile)) {
    die("CSV ფაილი არ მოიძებნა");
}

// წაიკითხე ფაილი
$content = file_get_contents($csvFile);
echo "<p>ფაილის ზომა: " . strlen($content) . " ბაიტი</p>";

// გახსენი და აჩვენე პირველი რამდენიმე ხაზი
$handle = fopen($csvFile, 'r');
echo "<h4>პირველი 10 ხაზი:</h4>";
echo "<pre style='background: #f0f0f0; padding: 10px; border: 1px solid #ccc;'>";

$lineNumber = 0;
while (($line = fgets($handle)) !== false && $lineNumber < 10) {
    $lineNumber++;
    echo "Line $lineNumber: " . htmlspecialchars($line) . "<br>";
    
    // აჩვენე როგორ იყოფა სვეტებად
    $columns = str_getcsv($line);
    echo "Columns: " . count($columns) . " → ";
    foreach ($columns as $index => $col) {
        echo "[$index: '" . trim($col) . "'] ";
    }
    echo "<br><hr>";
}

echo "</pre>";

// დათვალე სულ ხაზები
rewind($handle);
$totalLines = 0;
while (($line = fgets($handle)) !== false) {
    $totalLines++;
}
echo "<p>სულ ხაზები ფაილში: $totalLines</p>";

fclose($handle);

// შეამოწმე ენკოდინგი
echo "<h4>ენკოდინგის შემოწმება:</h4>";
$encodings = ['UTF-8', 'Windows-1251', 'ISO-8859-1'];
foreach ($encodings as $enc) {
    $content_enc = mb_convert_encoding($content, 'UTF-8', $enc);
    if (mb_check_encoding($content_enc, 'UTF-8')) {
        echo "<p>შესაძლო ენკოდინგი: $enc</p>";
    }
}

// ჩამოტვირთე ბმული CSV-ს ნახვისთვის
echo "<h4><a href='products.csv' download>ჩამოტვირთე CSV ფაილი</a></h4>";
?>