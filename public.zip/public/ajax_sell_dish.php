<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../config/db.php';

$dish_id  = intval($_POST['dish_id'] ?? 0);
$sold_qty = intval($_POST['sold_qty'] ?? 1);

if ($dish_id <= 0 || $sold_qty <= 0) {
    echo json_encode(['status' => 0, 'message' => 'არასწორი მონაცემები']);
    exit;
}

// 1. კერძის მონაცემები
$dish_res = $mysqli->query("SELECT name, sale_price, enable_vat FROM dishes WHERE id = $dish_id");
$dish_data = $dish_res->fetch_assoc();

if (!$dish_data) {
    echo json_encode(['status' => 0, 'message' => 'კერძი ვერ მოიძებნა']);
    exit;
}

$dish_name = $dish_data['name'];
$sale_price = $dish_data['sale_price'];
$has_vat = $dish_data['enable_vat'];

// 2. რეცეპტი - აქ დავამატეთ yield_coeff-ის წამოღება
$stmt = $mysqli->prepare("SELECT product_id, quantity, unit, yield_coeff FROM dish_calc WHERE dish_id = ?");
$stmt->bind_param("i", $dish_id);
$stmt->execute();
$recipe = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

$mysqli->begin_transaction();

try {
    // საწყობიდან ჩამოკლება Yield-ის გათვალისწინებით
    foreach ($recipe as $item) {
        $p_id = $item['product_id'];
        $net_qty = $item['quantity']; // სუფთა წონა რეცეპტიდან
        $unit = $item['unit'];
        $yield = floatval($item['yield_coeff'] > 0 ? $item['yield_coeff'] : 1); // კოეფიციენტი

        // ფორმულა: Gross = (Net * Sold_Qty) / Yield
        $needed_qty = ($net_qty * $sold_qty) / $yield;

        // თუ ერთეული გრამია, გადავიყვანოთ კილოგრამში (ბაზაში ნაშთი კგ-შია)
        if ($unit === 'გრ') {
            $needed_qty /= 1000;
        }

        $mysqli->query("UPDATE products SET quantity = quantity - $needed_qty WHERE id = $p_id");
    }

    // 3. გაანგარიშება გაყიდვისთვის
    $total_revenue = $sale_price * $sold_qty; 
    
    if ($has_vat) {
        $net_amount = $total_revenue / 1.18; 
        $vat_amount = $total_revenue - $net_amount; 
    } else {
        $net_amount = $total_revenue;
        $vat_amount = 0;
    }

    // 4. ჩაწერა sales ცხრილში
    $ins = $mysqli->prepare("INSERT INTO sales (dish_id, dish_name, quantity, net_amount, vat_amount, total_amount, sale_price) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $ins->bind_param("isidddd", $dish_id, $dish_name, $sold_qty, $net_amount, $vat_amount, $total_revenue, $sale_price);
    
    if ($ins->execute()) {
        $mysqli->commit();
        echo json_encode(['status' => 1]);
    } else {
        throw new Exception($mysqli->error);
    }

} catch (Exception $e) {
    $mysqli->rollback();
    echo json_encode(['status' => 0, 'message' => $e->getMessage()]);
}