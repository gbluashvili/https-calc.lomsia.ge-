<?php
require_once __DIR__ . '/../config/db.php';

// ბაზასთან დაკავშირების შემოწმება
if (!$mysqli) {
    die("ბაზასთან დაკავშირება ვერ მოხერხდა: " . ($mysqli->connect_error ?? "Unknown error"));
}

// პროდუქტის მონაცემები ბაზიდან - მოვერგოთ თქვენს ცხრილს
$products = [];
$result = $mysqli->query("SELECT * FROM products ORDER BY name ASC");
if ($result) {
    $products = $result->fetch_all(MYSQLI_ASSOC);
    $result->free();
} else {
    echo "<div class='alert alert-danger'>შეცდომა მონაცემების მიღებისას: " . $mysqli->error . "</div>";
}

// კრიტიკული ნაშთი - min_quantity ველის გამოყენება
$low_stock = array_filter($products, function($p) {
    return isset($p['quantity'], $p['min_quantity']) && 
           (float)$p['quantity'] <= (float)$p['min_quantity'] && 
           (float)$p['min_quantity'] > 0;
});

// მიღების/ჩამოწერის ფორმის ჩვენება
$show_purchase = isset($_GET['action']) && $_GET['action'] == 'purchase';
$show_waste = isset($_GET['action']) && $_GET['action'] == 'waste';
?>
<!DOCTYPE html>
<html lang="ka">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>საწყობის მართვა</title>
<?php include __DIR__ . '/../includes/header.php'; ?>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css">
<script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet"/>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<link rel="stylesheet" href="../css/style.css">

</head>
<body>

<div class="container">
    <div class="tab-container">
        <div class="tab-buttons">
            <button class="btn btn-green" onclick="showProductForm()">+ ახალი პროდუქტი</button>
            <button class="btn btn-blue" onclick="$('#purchaseFormDiv').toggle(); $('.form-container').not('#purchaseFormDiv').hide();">📥 მიღება</button>
            <button class="btn btn-red" onclick="$('#wasteFormDiv').toggle(); $('.form-container').not('#wasteFormDiv').hide();">🗑️ ჩამოწერა</button>
            <a href="sales_history.php" class="btn btn-orange">📈 გაყიდვების ისტორია</a>
            <a href="index.php" class="btn btn-gray">← უკან</a>
        </div>
    </div>

    <?php if(!empty($low_stock)): ?>
    <div class="alert-box">
        <strong>⚠️ კრიტიკული ნაშთი:</strong> 
        <?= htmlspecialchars(implode(', ', array_map(function($p) {
            return $p['name'] . " (" . $p['quantity'] . " " . $p['unit'] . ")";
        }, $low_stock))) ?>
    </div>
    <?php endif; ?>

    <!-- პროდუქტის დამატების/რედაქტირების ფორმა -->
    <div id="productFormDiv" class="form-container" style="display: <?= $show_purchase || $show_waste ? 'none' : 'block' ?>; border-top:5px solid #00c292;">
        <h3 id="productFormTitle">📦 პროდუქტის მართვა</h3>
        <div class="form-body">
            <div class="pur-grid">
                <div class="form-group">
                    <label>დასახელება:</label>
                    <input type="text" id="new_p_name" autocomplete="off" placeholder="დაიწყეთ აკრეფა პროდუქტის სახელისთვის...">
                    <div id="productSuggestions" class="search-suggestions"></div>
                </div>
                <div class="form-group">
                    <label>ერთეული:</label>
                    <select id="new_p_unit">
                        <option value="კგ">კგ</option>
                        <option value="გრ">გრ</option>
                        <option value="ლიტრი">ლიტრი</option>
                        <option value="ცალი">ცალი</option>
                        <option value="მეტრი">მეტრი</option>
                        <option value="ტონა">ტონა</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>ნაშთი:</label>
                    <input type="number" id="new_p_qty" step="0.001" min="0" value="0">
                    <span id="qty_unit_display" class="unit-display">კგ</span>
                </div>
                <div class="form-group">
                    <label>თვითღირებულება:</label>
                    <input type="number" id="new_p_price" step="0.01" min="0" value="0">
                </div>
                <div class="form-group">
                    <label>მინ. ზღვარი:</label>
                    <input type="number" id="new_p_limit" step="0.001" min="0" value="1">
                </div>
                <div class="form-group">
                    <label><input type="checkbox" id="new_p_vat"> ფასი VAT-ით (18%)</label>
                </div>
            </div>
            <button class="btn btn-blue" id="saveNewProduct">✅ შენახვა</button>
            <button class="btn btn-gray" onclick="$('#productFormDiv').hide()">✖️ გაუქმება</button>
        </div>
    </div>

    <!-- 📥 მიღების ფორმა -->
    <div id="purchaseFormDiv" class="form-container" style="display: <?= $show_purchase ? 'block' : 'none' ?>; border-top:5px solid #28a745;">
        <h3>📥 პროდუქტის მიღება</h3>
        <div class="form-body">
            <div class="pur-grid">
                <div class="form-group">
                    <label>პროდუქტი:</label>
                    <select id="pur_product_id" class="select2">
                        <option value="0">-- აირჩიე პროდუქტი --</option>
                        <?php foreach($products as $p): 
                            // vat_status-დან განვსაზღვროთ vat მნიშვნელობა
                            $vat = ($p['vat_status'] == 'დღგ-თი' || $p['vat_rate'] > 0) ? 1 : 0;
                        ?>
                        <option value="<?= htmlspecialchars($p['id']) ?>" 
                                data-unit="<?= htmlspecialchars($p['unit']) ?>" 
                                data-vat="<?= $vat ?>">
                            <?= htmlspecialchars($p['name']) ?> (<?= htmlspecialchars($p['quantity']) ?> <?= htmlspecialchars($p['unit']) ?>)
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>რაოდენობა (დამატება ნაშთში):</label>
                    <input type="number" id="pur_qty_pack" step="0.001" min="0" value="0">
                    <span id="unit_display" style="margin-left:5px; color:#666;">კგ</span>
                </div>
                <div class="form-group">
                    <label>ფასი (ჯამი):</label>
                    <input type="number" id="pur_total_amount" step="0.01" min="0" value="0">
                </div>
                <div class="form-group">
                    <label><input type="checkbox" id="pur_vat"> ფასი VAT-ით (18%)</label>
                </div>
                <div class="form-group">
                    <label>მომწოდებელი:</label>
                    <input type="text" id="pur_supplier" placeholder="მომწოდებლის სახელი">
                </div>
                <div class="form-group">
                    <label>შენიშვნა:</label>
                    <input type="text" id="pur_notes" placeholder="დამატებითი ინფორმაცია">
                </div>
            </div>
            <button class="btn btn-green" id="savePurchase">✅ მიღების შენახვა</button>
            <button class="btn btn-gray" onclick="$('#purchaseFormDiv').hide()">✖️ გაუქმება</button>
        </div>
    </div>

    <!-- 🗑️ ჩამოწერის ფორმა -->
    <div id="wasteFormDiv" class="form-container" style="display: <?= $show_waste ? 'block' : 'none' ?>; border-top:5px solid #dc3545;">
        <h3>🗑️ პროდუქტის ჩამოწერა</h3>
        <div class="form-body">
            <div class="pur-grid">
                <div class="form-group">
                    <label>პროდუქტი:</label>
                    <select id="waste_product_id" class="select2">
                        <option value="0">-- აირჩიე პროდუქტი --</option>
                        <?php foreach($products as $p): ?>
                        <option value="<?= htmlspecialchars($p['id']) ?>" 
                                data-unit="<?= htmlspecialchars($p['unit']) ?>" 
                                data-current="<?= htmlspecialchars($p['quantity']) ?>">
                            <?= htmlspecialchars($p['name']) ?> (<?= htmlspecialchars($p['quantity']) ?> <?= htmlspecialchars($p['unit']) ?>)
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>რაოდენობა (ნაშთიდან გამოკლება):</label>
                    <input type="number" id="waste_qty" step="0.001" min="0" value="0">
                    <span id="waste_unit_display" style="margin-left:5px; color:#666;">კგ</span>
                    <small class="text-muted">მაქსიმალური: <span id="max_waste_qty">0</span></small>
                </div>
                <div class="form-group">
                    <label>მიზეზი:</label>
                    <select id="waste_reason">
                        <option value="დაზიანება">დაზიანება</option>
                        <option value="ვადის გასვლა">ვადის გასვლა</option>
                        <option value="დანაკარგი">დანაკარგი</option>
                        <option value="სხვა">სხვა</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>დამატებითი ინფორმაცია:</label>
                    <input type="text" id="waste_notes" placeholder="დამატებითი ინფორმაცია">
                </div>
            </div>
            <button class="btn btn-red" id="saveWaste">✅ ჩამოწერის შენახვა</button>
            <button class="btn btn-gray" onclick="$('#wasteFormDiv').hide()">✖️ გაუქმება</button>
        </div>
    </div>

    <div class="table-container">
        <h2>📦 საწყობში არსებული პროდუქტები</h2>
        <table id="productTable" class="display compact">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>სახელი</th>
                    <th>ნაშთი</th>
                    <th>ზღვარი</th>
                    <th>ერთ.</th>
                    <th>ფასი</th>
                    <th>VAT</th>
                    <th>მოქმედება</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach($products as $p): 
                $vat = ($p['vat_status'] == 'დღგ-თი' || $p['vat_rate'] > 0) ? 1 : 0;
            ?>
                <tr data-id="<?= htmlspecialchars($p['id']) ?>" 
                    data-vat="<?= $vat ?>"
                    data-name="<?= htmlspecialchars($p['name']) ?>"
                    data-unit="<?= htmlspecialchars($p['unit']) ?>"
                    data-quantity="<?= htmlspecialchars($p['quantity']) ?>"
                    data-price="<?= htmlspecialchars($p['price']) ?>"
                    data-min_limit="<?= htmlspecialchars($p['min_quantity'] ?? 0) ?>">
                    <td><?= htmlspecialchars($p['id']) ?></td>
                    <td><?= htmlspecialchars($p['name']) ?></td>
                    <td><?= number_format((float)$p['quantity'], 3, '.', '') ?></td>
                    <td><?= number_format((float)($p['min_quantity'] ?? 0), 3, '.', '') ?></td>
                    <td><?= htmlspecialchars($p['unit']) ?></td>
                    <td><?= number_format((float)$p['price'], 2, '.', '') ?></td>
                    <td><input type="checkbox" disabled <?= $vat ? 'checked' : '' ?>></td>
                    <td>
                        <button class="btn btn-cyan editProduct">რედაქტირება</button>
                        <button class="btn btn-red deleteProduct">წაშლა</button>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
const products_js = <?= json_encode($products) ?>;
let selectedProduct = null;

function showProductForm(product=null){
    $('#productFormTitle').text('📦 ახალი პროდუქტი');
    $('#new_p_name').val('');
    $('#new_p_qty').val('0');
    $('#new_p_price').val('0');
    $('#new_p_limit').val('1');
    $('#new_p_unit').val('კგ');
    $('#qty_unit_display').text('კგ');
    $('#new_p_vat').prop('checked', false);
    $('#productFormDiv').show();
    $('#purchaseFormDiv').hide();
    $('#wasteFormDiv').hide();
    selectedProduct = null;

    if(product){
        $('#productFormTitle').text('📦 პროდუქტის რედაქტირება');
        $('#new_p_name').val(product.name);
        $('#new_p_unit').val(product.unit).trigger('change');
        $('#new_p_qty').val(product.quantity);
        $('#new_p_price').val(product.price);
        $('#new_p_limit').val(product.min_quantity || 0);
        $('#new_p_vat').prop('checked', product.vat_status == 'დღგ-თი' || product.vat_rate > 0);
        selectedProduct = product.id;
    }
}

$(document).ready(function(){
    // ინიციალიზაცია
    $('#qty_unit_display').text($('#new_p_unit').val());
    $('.select2').select2();
    
    // DataTable ინიციალიზაცია
    $('#productTable').DataTable({
        "pageLength": 25,
        "language": {
            "url": "//cdn.datatables.net/plug-ins/1.11.5/i18n/ka.json"
        }
    });

    // ერთეულის ცვლილება პროდუქტის ფორმაში
    $('#new_p_unit').on('change', function(){
        $('#qty_unit_display').text($(this).val());
    });

    // ერთეულის ცვლილება მიღების ფორმაში
    $('#pur_product_id').on('change', function(){
        const selected = $(this).find('option:selected');
        const unit = selected.data('unit') || 'კგ';
        const vat = selected.data('vat') || 0;
        $('#unit_display').text(unit);
        $('#pur_vat').prop('checked', vat == 1);
    });

    // ერთეულის ცვლილება ჩამოწერის ფორმაში
    $('#waste_product_id').on('change', function(){
        const selected = $(this).find('option:selected');
        const unit = selected.data('unit') || 'კგ';
        const currentQty = parseFloat(selected.data('current')) || 0;
        $('#waste_unit_display').text(unit);
        $('#max_waste_qty').text(currentQty.toFixed(3));
        $('#waste_qty').attr('max', currentQty);
    });

    // ძებნის სისტემა
    $('#new_p_name').on('input', function() {
        let term = $(this).val().toLowerCase();
        let suggestions = $('#productSuggestions');
        if(term.length < 2){ 
            suggestions.hide().empty(); 
            return; 
        }
        
        let filtered = products_js.filter(p => p.name.toLowerCase().includes(term));
        if(filtered.length > 0){
            let html = '<ul>';
            filtered.forEach(p => {
                html += `<li data-id="${p.id}" 
                           data-name="${p.name}" 
                           data-unit="${p.unit}" 
                           data-qty="${p.quantity}" 
                           data-price="${p.price}" 
                           data-limit="${p.min_quantity || 0}" 
                           data-vat="${(p.vat_status == 'დღგ-თი' || p.vat_rate > 0) ? 1 : 0}">
                           ${p.name} (${p.quantity} ${p.unit})
                        </li>`;
            });
            html += '</ul>';
            suggestions.html(html).show();
        } else {
            suggestions.hide().empty();
        }
    });

    // სუგესციების დაკლიკება
    $(document).on('click', '#productSuggestions li', function(){
        const el = $(this);
        const product = products_js.find(p => p.id == el.data('id'));
        if (product) {
            showProductForm(product);
        }
        $('#productSuggestions').hide().empty();
    });

    // რედაქტირების ღილაკი
    $(document).on('click', '.editProduct', function(){
        const tr = $(this).closest('tr');
        const id = tr.data('id');
        const product = products_js.find(p => p.id == id);
        if (product) {
            showProductForm(product);
        }
    });

    // ახალი პროდუქტის შენახვა
    $('#saveNewProduct').on('click', function(){
        const productData = {
            id: selectedProduct || 0,
            name: $('#new_p_name').val().trim(),
            unit: $('#new_p_unit').val(),
            quantity: parseFloat($('#new_p_qty').val()) || 0,
            price: parseFloat($('#new_p_price').val()) || 0,
            min_limit: parseFloat($('#new_p_limit').val()) || 0,
            vat: $('#new_p_vat').is(':checked') ? 1 : 0
        };

        if (!productData.name) {
            alert('გთხოვთ შეავსოთ პროდუქტის სახელი');
            return;
        }

        console.log('იგზავნება მონაცემები:', productData);

        $.ajax({
            url: 'save_product.php',
            type: 'POST',
            data: productData,
            dataType: 'json',
            success: function(response) {
                console.log('პასუხი:', response);
                if (response.success) {
                    alert(response.message);
                    location.reload();
                } else {
                    alert('შეცდომა: ' + response.message);
                }
            },
            error: function(xhr, status, error) {
                console.error('AJAX შეცდომა:', xhr.responseText);
                alert('სერვერთან დაკავშირების შეცდომა: ' + error);
            }
        });
    });

    // სუგესციების დამალვა ფოკუსის დაკარგვისას
    $(document).on('click', function(e) {
        if (!$(e.target).closest('#productSuggestions').length && 
            !$(e.target).is('#new_p_name')) {
            $('#productSuggestions').hide().empty();
        }
    });
});
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>
</body>
</html>