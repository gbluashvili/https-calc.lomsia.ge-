<?php
require_once __DIR__ . '/../config/db.php';

$product_id = $_POST['product_id'] ?? 0;
$quantity = $_POST['quantity'] ?? 0;
$total_amount = $_POST['total_amount'] ?? 0;
$supplier = $_POST['supplier'] ?? '';

if ($product_id <= 0 || $quantity <= 0 || $total_amount <= 0) {
    echo json_encode(['status' => 0, 'message' => 'არასწორი მონაცემები']);
    exit;
}

// დამატება purchases ცხრილში
$mysqli->query("INSERT INTO purchases (product_id, qty_base, total_amount, supplier) 
                VALUES ($product_id, $quantity, $total_amount, '$supplier')");

// პროდუქტის ნაშთის განახლება
$mysqli->query("UPDATE products SET quantity = quantity + $quantity WHERE id = $product_id");

echo json_encode(['status' => 1, 'message' => 'მიღება დაემატა']);
?>