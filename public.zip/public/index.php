<?php
require_once __DIR__ . '/../config/db.php';

$products = $mysqli->query("SELECT * FROM products ORDER BY name ASC")->fetch_all(MYSQLI_ASSOC);
$dishes   = $mysqli->query("SELECT * FROM dishes ORDER BY name ASC")->fetch_all(MYSQLI_ASSOC);
$low_stock = array_filter($products, function($p) {
    return $p['quantity'] <= $p['min_limit'] && $p['min_limit'] > 0;
});

// სტატისტიკა
$total_products = count($products);
$total_dishes = count($dishes);
$total_value = array_sum(array_map(function($p) {
    return $p['quantity'] * $p['price'];
}, $products));
$critical_items = count($low_stock);
?>
<!DOCTYPE html>
<html lang="ka">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Restaurant CMS - მთავარი</title>
    <?php 
    include '../includes/header.php';?>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link rel="stylesheet" href="../css/style.css">
    <style>
        .dashboard {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            margin: 20px 0;
        }
        
        .stat-card {
            background: white;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            border-top: 4px solid;
        }
        
        .stat-card h3 {
            margin-top: 0;
            color: #333;
        }
        
        .stat-value {
            font-size: 2em;
            font-weight: bold;
            margin: 10px 0;
        }
        
        .banner-container {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 40px 20px;
            border-radius: 10px;
            margin: 20px 0;
            text-align: center;
        }
        
        .banner-container h1 {
            margin: 0;
            font-size: 2.5em;
        }
        
        .banner-container p {
            font-size: 1.2em;
            opacity: 0.9;
        }
        
        .quick-actions {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
            margin: 20px 0;
        }
        
        .nav-menu {
            background: white;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin: 20px 0;
        }
        
        .nav-menu h2 {
            margin-top: 0;
            color: #333;
            border-bottom: 2px solid #f0f0f0;
            padding-bottom: 10px;
        }
        
        .nav-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-top: 20px;
        }
        
        .nav-item {
            background: #f8f9fa;
            border-radius: 8px;
            padding: 20px;
            text-align: center;
            transition: transform 0.3s, box-shadow 0.3s;
            text-decoration: none;
            color: #333;
        }
        
        .nav-item:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        
        .nav-item i {
            font-size: 2em;
            margin-bottom: 10px;
            display: block;
        }
        
        .alert-box {
            background: #fff3cd;
            border: 1px solid #ffeaa7;
            border-radius: 8px;
            padding: 15px;
            margin: 20px 0;
        }
    </style>
</head>
<body>


<div class="banner-container">
    <h1>კეთილი იყოს თქვენი მობრძანება!</h1>
    <p>მართეთ თქვენი რესტორნის ყველა ასპექტი ერთი ადგილიდან</p>
</div>

<?php if(!empty($low_stock)): ?>
<div class="alert-box">
    <strong>⚠️ ყურადღება! კრიტიკული ნაშთი:</strong> 
    <?php echo implode(', ', array_map(fn($p) => htmlspecialchars($p['name'])." (".$p['quantity']." ".$p['unit'].")", $low_stock)); ?>
</div>
<?php endif; ?>

<div class="dashboard">
    <div class="stat-card" style="border-color: #00c292;">
        <h3>📦 პროდუქტები</h3>
        <div class="stat-value"><?= $total_products ?></div>
        <p>საწყობში არსებული პროდუქტები</p>
    </div>
    
    <div class="stat-card" style="border-color: #6f42c1;">
        <h3>🍳 კერძები</h3>
        <div class="stat-value"><?= $total_dishes ?></div>
        <p>მენიუში არსებული კერძები</p>
    </div>
    
    <div class="stat-card" style="border-color: #28a745;">
        <h3>💰 ინვენტარის ღირებულება</h3>
        <div class="stat-value"><?= number_format($total_value, 2) ?> ₾</div>
        <p>მთლიანი თვითღირებულება</p>
    </div>
    
    <div class="stat-card" style="border-color: #ff6b6b;">
        <h3>⚠️ კრიტიკული</h3>
        <div class="stat-value"><?= $critical_items ?></div>
        <p>პროდუქტი მინიმალურ ზღვარს ქვემოთ</p>
    </div>
</div>

<div class="nav-menu">
    <h2>სწრაფი ნავიგაცია</h2>
    <div class="nav-grid">
        <a href="warehouse.php" class="nav-item">
            <div style="font-size: 2em;">📦</div>
            <strong>საწყობის მართვა</strong>
            <p>პროდუქტების ნახვა, დამატება, რედაქტირება</p>
        </a>
        
        <a href="menu.php" class="nav-item">
            <div style="font-size: 2em;">🍳</div>
            <strong>მენიუს მართვა</strong>
            <p>კერძების და რეცეპტების მართვა</p>
        </a>
        
        <a href="warehouse.php?action=purchase" class="nav-item">
            <div style="font-size: 2em;">📥</div>
            <strong>პროდუქტის მიღება</strong>
            <p>ახალი პროდუქტების შეტანა საწყობში</p>
        </a>
        
        <a href="warehouse.php?action=waste" class="nav-item">
            <div style="font-size: 2em;">🗑️</div>
            <strong>პროდუქტის ჩამოწერა</strong>
            <p>ნარჩენების ან დაზიანებული პროდუქტის ჩამოწერა</p>
        </a>
    </div>
</div>

<?php 
    include '../includes/footer.php';?>

</body>
</html>