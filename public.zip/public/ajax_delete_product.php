<?php
require_once __DIR__ . '/../config/db.php';

// ვამოწმებთ მოვიდა თუ არა ID
$id = isset($_POST['id']) ? intval($_POST['id']) : 0;

if ($id > 0) {
    // ვიწყებთ ტრანზაქციას, რომ ყველაფერი ერთად წაიშალოს
    $mysqli->begin_transaction();

    try {
        // 1. ვშლით რეცეპტებიდან (Dish Calculation)
        $mysqli->query("DELETE FROM dish_calc WHERE product_id = $id");

        // 2. ვშლით ინვენტარიზაციის ისტორიიდან (Inventory History)
        $mysqli->query("DELETE FROM inventory_counts WHERE product_id = $id");

        // 3. ვშლით შესყიდვებიდან (თუ გაქვთ ასეთი კავშირი)
        $mysqli->query("DELETE FROM purchases WHERE product_id = $id");
        
        // 4. ვშლით ჩამოწერებიდან (Waste)
        $mysqli->query("DELETE FROM waste WHERE product_id = $id");

        // 5. ბოლოს ვშლით თავად პროდუქტს
        $stmt = $mysqli->prepare("DELETE FROM products WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();

        // თუ ყველაფერმა კარგად ჩაიარა, ვადასტურებთ ცვლილებებს
        $mysqli->commit();
        echo json_encode(['status' => 1]);

    } catch (Exception $e) {
        // შეცდომის შემთხვევაში ვაუქმებთ ყველაფერს (Rollback)
        $mysqli->rollback();
        http_response_code(500);
        echo json_encode(['status' => 0, 'error' => $e->getMessage()]);
    }
} else {
    http_response_code(400);
    echo json_encode(['status' => 0, 'message' => 'Invalid ID']);
}