<?php
// upload_csv_fixed_final.php
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('max_execution_time', 300);
ini_set('memory_limit', '256M');

// 1. MySQL კავშირი
$db_host = 'localhost';
$db_user = 'mvpuufsr_calc';
$db_pass = 'Asd1986!@#'; // ⚠️ შეცვალე სწორი პაროლით!
$db_name = 'mvpuufsr_calc';

$conn = new mysqli($db_host, $db_user, $db_pass, $db_name);
if ($conn->connect_error) {
    die("<h3 style='color: red;'>MySQL შეცდომა: " . $conn->connect_error . "</h3>
         <p>შეამოწმე მომხმარებლის სახელი და პაროლი.</p>");
}
$conn->set_charset("utf8mb4");

echo "<div style='font-family: Arial, sans-serif; max-width: 1200px; margin: 0 auto; padding: 20px;'>";
echo "<h2 style='color: #2c3e50; border-bottom: 2px solid #3498db; padding-bottom: 10px;'>📦 CSV ფაილიდან პროდუქტების ატვირთვა</h2>";

// 2. CSV ფაილის პრეპროცესინგი
$csvFile = 'products.csv';
if (!file_exists($csvFile)) {
    die("<div style='background: #ffebee; color: #c62828; padding: 15px; border-radius: 5px;'>
            <h3>❌ CSV ფაილი არ მოიძებნა</h3>
            <p>გთხოვთ, ატვირთეთ 'products.csv' ფაილი ამ დირექტორიაში.</p>
         </div>");
}

// წაიკითხე და გაასუფთავე ფაილი
$content = file_get_contents($csvFile);
// მოაშორე UTF-8 BOM
$bom = pack('H*','EFBBBF');
$content = preg_replace("/^$bom/", '', $content);
// შეინახე დასუფთავებული ვერსია
$cleanFile = 'products_clean_' . time() . '.csv';
file_put_contents($cleanFile, $content);

echo "<div style='background: #e3f2fd; padding: 15px; border-radius: 5px; margin-bottom: 20px;'>
        <p>✅ ფაილი ჩაიტვირთა და გასუფთავდა (BOM მოიშორა)</p>
        <p>ფაილის ზომა: " . filesize($cleanFile) . " ბაიტი</p>
      </div>";

// 3. CSV წაკითხვა
$handle = fopen($cleanFile, 'r');
if (!$handle) {
    die("<p style='color: red;'>ფაილის გახსნა ვერ მოხერხდა</p>");
}

// წაიკითხე სათაური
$header = fgetcsv($handle, 0, ',');
echo "<div style='background: #f5f5f5; padding: 15px; border-radius: 5px; margin-bottom: 20px;'>
        <h4>CSV სტრუქტურა:</h4>
        <p>სვეტების რაოდენობა: " . count($header) . "</p>
        <pre>" . htmlspecialchars(print_r($header, true)) . "</pre>
      </div>";

// 4. დამუშავება
$updated = 0;
$added = 0;
$skipped = 0;
$processed = 0;
$errors = [];
$success_rows = [];

echo "<h3>🚀 მონაცემთა დამუშავება...</h3>";
echo "<div id='progress' style='height: 20px; background: #e0e0e0; border-radius: 10px; margin: 20px 0; overflow: hidden;'>
        <div id='progress-bar' style='height: 100%; width: 0%; background: #4CAF50; transition: width 0.3s;'></div>
      </div>";

while (($row = fgetcsv($handle, 0, ',')) !== false) {
    $processed++;
    
    // ცარიელი ხაზების გამოტოვება
    if (count(array_filter($row, 'strlen')) == 0) {
        $skipped++;
        continue;
    }
    
    // აუცილებელი სვეტების შემოწმება
    if (count($row) < 4) {
        $errors[] = "მწკრივი $processed: არასაკმარისი სვეტები (" . count($row) . ")";
        $skipped++;
        continue;
    }
    
    // მონაცემების ამოღება
    $name = trim($row[0] ?? '');
    $price_raw = trim($row[1] ?? '');
    $vat_text = trim($row[2] ?? '');
    $quantity_raw = trim($row[3] ?? '100'); // დეფოლტი 100
    
    // ფასის დამუშავება
    $price = 0;
    if (!empty($price_raw)) {
        // თუ ფასი არის დიაპაზონი (მაგ: "25-30"), აიღე საშუალო
        if (strpos($price_raw, '-') !== false) {
            $parts = explode('-', $price_raw);
            $num1 = floatval(str_replace(',', '.', trim($parts[0])));
            $num2 = floatval(str_replace(',', '.', trim($parts[1] ?? $parts[0])));
            $price = ($num1 + $num2) / 2;
        } elseif (is_numeric(str_replace(',', '.', $price_raw))) {
            $price = floatval(str_replace(',', '.', $price_raw));
        }
    }
    
    // რაოდენობის დამუშავება
    $quantity = 100; // დეფოლტი
    if (!empty($quantity_raw) && is_numeric(str_replace(',', '.', $quantity_raw))) {
        $quantity = floatval(str_replace(',', '.', $quantity_raw));
    }
    
    // ვალიდაცია
    if (empty($name) || $name === 'დასახელება') {
        $skipped++;
        continue;
    }
    
    // თუ ფასი 0-ია, გამოტოვე (მაგ: "სანდორა ატმის 950მლ")
    if ($price == 0) {
        $errors[] = "მწკრივი $processed: '$name' - ფასი არ არის მითითებული ან 0-ია";
        $skipped++;
        continue;
    }
    
    // დღგ-ს სტატუსის განსაზღვრა
    if (stripos($vat_text, 'დღგ-ჩათვლით') !== false) {
        $vat_status = 'დღგ-თი';
    } elseif (stripos($vat_text, 'დღგ-გარეშე') !== false) {
        $vat_status = 'დღგ-გარეშე';
    } else {
        $vat_status = '';
    }
    
    // ესკეიპინგი
    $name_esc = $conn->real_escape_string($name);
    $vat_status_esc = $conn->real_escape_string($vat_status);
    $price = round($price, 2);
    
    // ერთეულის ავტო-დეტექტი
    $unit = 'კგ';
    if (preg_match('/(\d+)\s*(ლ|მლ|ლიტრი)/ui', $name)) {
        $unit = 'ლიტრი';
    } elseif (preg_match('/(\d+)\s*ც/ui', $name) || strpos($name, 'ცალი') !== false) {
        $unit = 'ცალი';
    } elseif (preg_match('/(\d+)\s*გრ/ui', $name) || preg_match('/(\d+)\s*კგ/ui', $name)) {
        $unit = 'კგ';
    }
    
    try {
        // UPSERT ოპერაცია
        $sql = "INSERT INTO products 
                (name, unit, price, vat_rate, vat_status, stock_quantity, 
                 min_quantity, min_limit, created_at) 
                VALUES 
                ('$name_esc', '$unit', '$price', '18.00', '$vat_status_esc', 
                 '$quantity', '1.000', '1.000', NOW())
                ON DUPLICATE KEY UPDATE
                price = VALUES(price),
                vat_status = VALUES(vat_status),
                stock_quantity = VALUES(stock_quantity),
                updated_at = NOW()";
        
        if ($conn->query($sql)) {
            if ($conn->affected_rows == 1) {
                $added++;
                $success_rows[] = "<span style='color: green;'>+ $name</span>";
            } elseif ($conn->affected_rows == 2) {
                $updated++;
                $success_rows[] = "<span style='color: blue;'>✓ $name</span>";
            }
        } else {
            $errors[] = "SQL შეცდომა '$name': " . $conn->error;
        }
        
    } catch (Exception $e) {
        $errors[] = "შეცდომა '$name': " . $e->getMessage();
    }
    
    // პროგრეს ბარის განახლება
    if ($processed % 10 == 0) {
        $percent = min(100, round(($processed / 252) * 100));
        echo "<script>document.getElementById('progress-bar').style.width = '$percent%';</script>";
        flush();
    }
}

fclose($handle);

// 5. შედეგების ჩვენება
echo "<script>document.getElementById('progress-bar').style.width = '100%';</script>";

echo "<div style='background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); 
                 color: white; padding: 25px; border-radius: 15px; margin: 20px 0;'>";
echo "<h2 style='color: white; margin-top: 0;'>🎉 ატვირთვა დასრულებულია!</h2>";
echo "<div style='display: flex; justify-content: space-around; text-align: center; flex-wrap: wrap;'>";
echo "<div style='padding: 15px;'><div style='font-size: 2.5em; font-weight: bold;'>$added</div><div>ახალი</div></div>";
echo "<div style='padding: 15px;'><div style='font-size: 2.5em; font-weight: bold;'>$updated</div><div>განახლებული</div></div>";
echo "<div style='padding: 15px;'><div style='font-size: 2.5em; font-weight: bold;'>$skipped</div><div>გამოტოვებული</div></div>";
echo "<div style='padding: 15px;'><div style='font-size: 2.5em; font-weight: bold;'>$processed</div><div>სულ დამუშავდა</div></div>";
echo "</div>";
echo "</div>";

// 6. წარმატებული ჩანაწერები
if (!empty($success_rows)) {
    echo "<h3>✅ წარმატებით დამუშავდა (" . count($success_rows) . "):</h3>";
    echo "<div style='columns: 2; column-gap: 30px;'>";
    foreach (array_slice($success_rows, 0, 100) as $item) {
        echo "<div style='margin-bottom: 5px; padding: 3px 0; border-bottom: 1px dotted #eee;'>$item</div>";
    }
    if (count($success_rows) > 100) {
        echo "<div style='color: #666; font-style: italic;'>... და კიდევ " . (count($success_rows) - 100) . " პროდუქტი</div>";
    }
    echo "</div>";
}

// 7. შეცდომები
if (!empty($errors)) {
    echo "<h3 style='color: #d32f2f;'>❌ შეცდომები (" . count($errors) . "):</h3>";
    echo "<div style='max-height: 200px; overflow-y: auto; background: #ffebee; padding: 15px; border-radius: 5px;'>";
    echo "<ul style='margin: 0; padding-left: 20px;'>";
    foreach (array_slice($errors, 0, 20) as $error) {
        echo "<li style='margin-bottom: 5px;'>$error</li>";
    }
    if (count($errors) > 20) {
        echo "<li>... და კიდევ " . (count($errors) - 20) . " შეცდომა</li>";
    }
    echo "</ul>";
    echo "</div>";
}

// 8. ბაზის სტატისტიკა
echo "<h3>📊 ბაზის მდგომარეობა:</h3>";

$stats = [
    "სულ პროდუქტები" => "SELECT COUNT(*) as total FROM products",
    "დღგ-თი" => "SELECT COUNT(*) as count FROM products WHERE vat_status = 'დღგ-თი'",
    "დღგ-გარეშე" => "SELECT COUNT(*) as count FROM products WHERE vat_status = 'დღგ-გარეშე'",
    "უადღგო" => "SELECT COUNT(*) as count FROM products WHERE vat_status IS NULL OR vat_status = ''",
    "საშუალო ფასი" => "SELECT ROUND(AVG(price), 2) as avg_price FROM products WHERE price > 0",
    "უკანასკნელი განახლება" => "SELECT MAX(updated_at) as last_update FROM products WHERE updated_at IS NOT NULL"
];

echo "<div style='display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 15px; margin: 20px 0;'>";
foreach ($stats as $label => $sql) {
    $result = $conn->query($sql);
    if ($result && $row = $result->fetch_assoc()) {
        $value = reset($row);
        echo "<div style='background: #f8f9fa; padding: 15px; border-radius: 8px; border-left: 4px solid #3498db;'>
                <div style='font-weight: bold; color: #2c3e50;'>$label</div>
                <div style='font-size: 1.2em; color: #2980b9;'>$value</div>
              </div>";
    }
}
echo "</div>";

// 9. უახლესი ცვლილებები
$sql_recent = "SELECT name, price, vat_status, stock_quantity, 
               COALESCE(updated_at, created_at) as last_change
               FROM products 
               ORDER BY last_change DESC 
               LIMIT 15";
$result = $conn->query($sql_recent);

if ($result && $result->num_rows > 0) {
    echo "<h3>🕒 უახლესი ცვლილებები:</h3>";
    echo "<div style='overflow-x: auto;'>";
    echo "<table style='width: 100%; border-collapse: collapse;'>";
    echo "<thead><tr style='background: #2c3e50; color: white;'>
            <th style='padding: 12px; text-align: left;'>პროდუქტი</th>
            <th style='padding: 12px; text-align: left;'>ფასი</th>
            <th style='padding: 12px; text-align: left;'>დღგ</th>
            <th style='padding: 12px; text-align: left;'>რაოდენობა</th>
            <th style='padding: 12px; text-align: left;'>განახლდა</th>
          </tr></thead><tbody>";
    
    while ($row = $result->fetch_assoc()) {
        $bg_color = $row['vat_status'] == 'დღგ-თი' ? '#e8f5e9' : ($row['vat_status'] == 'დღგ-გარეშე' ? '#fff3e0' : '#f5f5f5');
        echo "<tr style='background: $bg_color;'>
                <td style='padding: 10px; border-bottom: 1px solid #ddd;'>" . htmlspecialchars($row['name']) . "</td>
                <td style='padding: 10px; border-bottom: 1px solid #ddd;'>" . number_format($row['price'], 2) . " ₾</td>
                <td style='padding: 10px; border-bottom: 1px solid #ddd;'>" . ($row['vat_status'] ?: '-') . "</td>
                <td style='padding: 10px; border-bottom: 1px solid #ddd;'>" . number_format($row['stock_quantity'], 3) . "</td>
                <td style='padding: 10px; border-bottom: 1px solid #ddd;'>" . date('H:i d/m', strtotime($row['last_change'])) . "</td>
              </tr>";
    }
    echo "</tbody></table>";
    echo "</div>";
}

$conn->close();

// 10. დამატებითი ბმულები
echo "<div style='margin-top: 40px; padding: 20px; background: #f8f9fa; border-radius: 10px;'>";
echo "<h4>🔗 დამატებითი ფუნქციები:</h4>";
echo "<p><a href='$cleanFile' download style='display: inline-block; background: #4CAF50; color: white; padding: 10px 20px; border-radius: 5px; text-decoration: none; margin-right: 10px;'>📥 ჩამოტვირთე გასუფთავებული CSV</a>";
echo "<a href='javascript:location.reload()' style='display: inline-block; background: #2196F3; color: white; padding: 10px 20px; border-radius: 5px; text-decoration: none; margin-right: 10px;'>🔄 განაახლე გვერდი</a>";
echo "<a href='products.csv' style='display: inline-block; background: #9C27B0; color: white; padding: 10px 20px; border-radius: 5px; text-decoration: none;'>📄 ნახე ორიგინალური CSV</a></p>";
echo "</div>";

echo "</div>"; // დახურვა მთავარი container-ის

// JavaScript ალერტი
echo "<script>
    setTimeout(function() {
        alert('ატვირთვა დასრულდა!\\\\n\\\\nახალი: $added\\\\nგანახლებული: $updated\\\\nგამოტოვებული: $skipped\\\\nსულ დამუშავდა: $processed');
    }, 100);
</script>";
?>