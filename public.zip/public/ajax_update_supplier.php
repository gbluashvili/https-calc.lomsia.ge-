<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../config/db.php';

$id    = $_POST['id'] ?? 0;
$name  = $_POST['name'] ?? '';
$phone = $_POST['phone'] ?? '';

if ($id > 0 && !empty($name)) {
    $stmt = $mysqli->prepare("UPDATE suppliers SET name = ?, phone = ? WHERE id = ?");
    $stmt->bind_param("ssi", $name, $phone, $id);
    
    if ($stmt->execute()) {
        echo json_encode(['status' => 'success']);
    } else {
        echo json_encode(['status' => 'error', 'message' => $mysqli->error]);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Invalid data']);
}