<?php
header('Content-Type: application/json');
require_once __DIR__.'/../config/db.php';
require_once __DIR__.'/../functions/getDishes.php';

$sql = "SELECT id, name, enable_vat FROM dishes WHERE active = 1 ORDER BY id DESC";
$res = $mysqli->query($sql);

$data = [];
while($row = $res->fetch_assoc()){
    $data[] = $row;
}

echo json_encode([
    'status' => 1,
    'data'   => $data
]);
