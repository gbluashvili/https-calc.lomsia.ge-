<?php
require_once __DIR__ . '/../config/db.php';

$id = isset($_POST['id']) ? intval($_POST['id']) : 0;

if ($id > 0) {
    // 1. ვშლით რეცეპტს
    $mysqli->query("DELETE FROM dish_calc WHERE dish_id = $id");

    // 2. ვშლით გაყიდვების ისტორიას (თუ ბაზა არ გაძლევთ წაშლის უფლებას)
    $mysqli->query("DELETE FROM sales WHERE dish_id = $id");

    // 3. ვშლით კერძს
    $stmt = $mysqli->prepare("DELETE FROM dishes WHERE id = ?");
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        echo json_encode(['status' => 1]);
    } else {
        http_response_code(500);
        echo json_encode(['status' => 0, 'error' => $mysqli->error]);
    }
} else {
    http_response_code(400);
    echo json_encode(['status' => 0, 'message' => 'Invalid ID']);
}