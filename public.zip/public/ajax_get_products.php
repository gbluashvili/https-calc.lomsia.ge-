<?php
header('Content-Type: application/json');
require_once __DIR__.'/../config/db.php';
require_once __DIR__.'/../functions/product.php';

$products = getProducts($mysqli);

echo json_encode([
    'status' => 1,
    'data'   => $products
]);
