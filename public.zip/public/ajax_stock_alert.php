<?php
header('Content-Type: application/json');
require_once '../config/db.php';
require_once '../functions/checkStockAlert.php';

$alerts = checkStockAlert($mysqli);
echo json_encode(['status'=>1,'data'=>$alerts]);
