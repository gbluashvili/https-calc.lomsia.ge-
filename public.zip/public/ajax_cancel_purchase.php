<?php
require_once __DIR__ . '/../config/db.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id'])) {
    $purchase_id = intval($_POST['id']);

    // 1. მოვიძიოთ ინფორმაცია შესყიდვის შესახებ, სანამ წავშლით
    $stmt = $mysqli->prepare("SELECT product_id, qty_base FROM purchases WHERE id = ?");
    $stmt->bind_param("i", $purchase_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $purchase = $result->fetch_assoc();

    if ($purchase) {
        $product_id = $purchase['product_id'];
        $qty_to_subtract = $purchase['qty_base'];

        // ტრანზაქციის დაწყება, რომ მონაცემები სინქრონულად განახლდეს
        $mysqli->begin_transaction();

        try {
            // 2. შევამციროთ ნაშთი პროდუქტების ცხრილში
            $update_stmt = $mysqli->prepare("UPDATE products SET quantity = quantity - ? WHERE id = ?");
            $update_stmt->bind_param("di", $qty_to_subtract, $product_id);
            $update_stmt->execute();

            // 3. წავშალოთ ჩანაწერი შესყიდვების ცხრილიდან
            $delete_stmt = $mysqli->prepare("DELETE FROM purchases WHERE id = ?");
            $delete_stmt->bind_param("i", $purchase_id);
            $delete_stmt->execute();

            // თუ ყველაფერი კარგადაა, დავასრულოთ ტრანზაქცია
            $mysqli->commit();

            echo json_encode(['status' => true, 'message' => 'შესყიდვა გაუქმდა და ნაშთი განახლდა.']);
        } catch (Exception $e) {
            // შეცდომის შემთხვევაში დავაბრუნოთ ცვლილებები
            $mysqli->rollback();
            echo json_encode(['status' => false, 'message' => 'შეცდომა ბაზაში: ' . $e->getMessage()]);
        }
    } else {
        echo json_encode(['status' => false, 'message' => 'შესყიდვა ვერ მოიძებნა.']);
    }
} else {
    echo json_encode(['status' => false, 'message' => 'არასწორი მოთხოვნა.']);
}