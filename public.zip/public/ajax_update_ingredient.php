<?php
// ajax_update_ingredient.php
error_reporting(E_ALL);
ini_set('display_errors', 0);
header('Content-Type: application/json');

require_once __DIR__ . '/../config/db.php';

$res = ['status' => 0, 'message' => 'უცნობი შეცდომა'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = isset($_POST['id']) ? intval($_POST['id']) : 0;
    $quantity = isset($_POST['quantity']) ? floatval($_POST['quantity']) : 0;
    
    // ვალიდაცია
    if ($id <= 0) {
        $res['message'] = 'არასწორი ინგრედიენტის ID';
        echo json_encode($res);
        exit;
    }
    
    if ($quantity <= 0) {
        $res['message'] = 'რაოდენობა უნდა იყოს 0-ზე მეტი';
        echo json_encode($res);
        exit;
    }
    
    try {
        // შეამოწმეთ არსებობს თუ არა ინგრედიენტი
        $check_stmt = $mysqli->prepare("SELECT dc.*, d.name as dish_name, p.name as product_name 
                                       FROM dish_calc dc
                                       JOIN dishes d ON dc.dish_id = d.id
                                       JOIN products p ON dc.product_id = p.id
                                       WHERE dc.id = ?");
        $check_stmt->bind_param("i", $id);
        $check_stmt->execute();
        $check_result = $check_stmt->get_result();
        
        if ($check_result->num_rows === 0) {
            throw new Exception('ინგრედიენტი არ მოიძებნა');
        }
        
        $ingredient = $check_result->fetch_assoc();
        $check_stmt->close();
        
        // განაახლეთ რაოდენობა
        $update_stmt = $mysqli->prepare("UPDATE dish_calc SET quantity = ? WHERE id = ?");
        $update_stmt->bind_param("di", $quantity, $id);
        
        if ($update_stmt->execute()) {
            $res['status'] = 1;
            $res['message'] = 'ინგრედიენტი წარმატებით განახლდა';
            $res['ingredient'] = [
                'id' => $id,
                'dish_id' => $ingredient['dish_id'],
                'dish_name' => $ingredient['dish_name'],
                'product_id' => $ingredient['product_id'],
                'product_name' => $ingredient['product_name'],
                'quantity' => $quantity
            ];
        } else {
            throw new Exception('ბაზის შეცდომა: ' . $update_stmt->error);
        }
        
        $update_stmt->close();
        
    } catch (Exception $e) {
        $res['message'] = $e->getMessage();
        $res['debug'] = [
            'id' => $id,
            'quantity' => $quantity
        ];
    }
} else {
    $res['message'] = 'არასწორი მოთხოვნის მეთოდი';
}

echo json_encode($res);
?>