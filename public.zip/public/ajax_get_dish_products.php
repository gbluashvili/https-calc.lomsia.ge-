<?php
header('Content-Type: application/json');
require_once __DIR__.'/../config/db.php';

$dish_id = intval($_POST['dish_id'] ?? 0);

if ($dish_id <= 0) {
    echo json_encode(['status'=>0,'message'=>'Invalid dish ID']);
    exit;
}

// წამოვიღოთ კერძში ჩართული პროდუქტები
$sql = "
    SELECT 
        dp.product_id,
        p.name AS product_name,
        dp.quantity,
        p.unit,
        p.price,
        p.vat_rate
    FROM dish_products dp
    INNER JOIN products p ON dp.product_id = p.id
    WHERE dp.dish_id = ?
";
$stmt = $mysqli->prepare($sql);
$stmt->bind_param("i", $dish_id);
$stmt->execute();
$result = $stmt->get_result();

$items = [];
while($row = $result->fetch_assoc()){
    $items[] = [
        'product_id' => $row['product_id'],
        'product_name' => $row['product_name'],
        'quantity' => $row['quantity'],
        'unit' => $row['unit'],
        'price' => $row['price'],
        'vat_rate' => $row['vat_rate']
    ];
}

echo json_encode([
    'status'=>1,
    'data'=>$items
]);
