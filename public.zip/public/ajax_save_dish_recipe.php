<?php
require_once __DIR__ . '/../config/db.php';

header('Content-Type: application/json; charset=utf-8');

$dish_id = isset($_POST['dish_id']) ? intval($_POST['dish_id']) : 0;
$ingredients_json = isset($_POST['ingredients']) ? $_POST['ingredients'] : '[]';
$ingredients = json_decode($ingredients_json, true);

if ($dish_id > 0) {
    // ჯერ შევამოწმოთ არსებობს თუ არა dish_recipe ცხრილი
    $check_table = $mysqli->query("SHOW TABLES LIKE 'dish_recipe'");
    if ($check_table->num_rows == 0) {
        // თუ ცხრილი არ არსებობს, შევქმნათ
        $create_table = "CREATE TABLE IF NOT EXISTS dish_recipe (
            id INT AUTO_INCREMENT PRIMARY KEY,
            dish_id INT NOT NULL,
            product_id INT NOT NULL,
            quantity DECIMAL(10,3) NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (dish_id) REFERENCES dishes(id) ON DELETE CASCADE,
            FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
            UNIQUE KEY unique_dish_product (dish_id, product_id)
        )";
        
        if (!$mysqli->query($create_table)) {
            echo json_encode([
                'status' => 0,
                'message' => 'ცხრილის შექმნის შეცდომა: ' . $mysqli->error
            ], JSON_UNESCAPED_UNICODE);
            exit;
        }
    }
    
    // დაიწყე ტრანზაქცია
    $mysqli->begin_transaction();
    
    try {
        // წაშალე ძველი რეცეპტი
        $delete_query = "DELETE FROM dish_recipe WHERE dish_id = ?";
        $delete_stmt = $mysqli->prepare($delete_query);
        $delete_stmt->bind_param("i", $dish_id);
        $delete_stmt->execute();
        $delete_stmt->close();
        
        // ჩასვა ახალი რეცეპტი
        if (!empty($ingredients) && is_array($ingredients)) {
            $insert_query = "INSERT INTO dish_recipe (dish_id, product_id, quantity) VALUES (?, ?, ?)";
            $insert_stmt = $mysqli->prepare($insert_query);
            
            foreach ($ingredients as $ingredient) {
                if (isset($ingredient['product_id']) && isset($ingredient['quantity'])) {
                    $product_id = intval($ingredient['product_id']);
                    $quantity = floatval($ingredient['quantity']);
                    
                    $insert_stmt->bind_param("iid", $dish_id, $product_id, $quantity);
                    $insert_stmt->execute();
                }
            }
            $insert_stmt->close();
        }
        
        // დაადასტურე ტრანზაქცია
        $mysqli->commit();
        
        echo json_encode([
            'status' => 1,
            'message' => 'რეცეპტი წარმატებით შეინახა'
        ], JSON_UNESCAPED_UNICODE);
        
    } catch (Exception $e) {
        // გააუქმე ტრანზაქცია შეცდომის შემთხვევაში
        $mysqli->rollback();
        
        echo json_encode([
            'status' => 0,
            'message' => 'შეცდომა რეცეპტის შენახვისას: ' . $e->getMessage()
        ], JSON_UNESCAPED_UNICODE);
    }
} else {
    echo json_encode([
        'status' => 0,
        'message' => 'არასწორი მონაცემები'
    ], JSON_UNESCAPED_UNICODE);
}

$mysqli->close();
?>