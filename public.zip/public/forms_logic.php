<div id="formsContainer">
    <div id="productFormDiv" class="form-container" style="display: none; border-top: 5px solid #00c292;">
        <h3 id="productFormTitle">📦 პროდუქტის მართვა</h3>
        <div class="form-body">
            <div class="pur-grid">
                <input type="hidden" id="edit_p_id">
                <div class="form-group"><label>დასახელება:</label><input type="text" id="new_p_name"></div>
                <div class="form-group">
                    <label>ერთეული:</label>
                    <select id="new_p_unit">
                        <option value="კგ">კგ</option><option value="გრ">გრ</option>
                        <option value="ლიტრი">ლიტრი</option><option value="ცალი">ცალი</option>
                    </select>
                </div>
                <div class="form-group"><label>ნაშთი:</label><input type="number" id="new_p_qty" step="0.001"></div>
                <div class="form-group"><label>ფასი:</label><input type="number" id="new_p_price" step="0.01"></div>
                <div class="form-group"><label>ზღვარი:</label><input type="number" id="new_p_limit" step="0.001"></div>
            </div>
            <button class="btn btn-blue" id="saveNewProduct" style="width:100%; margin-top:10px;">✅ შენახვა</button>
        </div>
    </div>

    </div>

<script>
    // ყველა ფუნქცია, რომელიც ფორმების გამოჩენა-დამალვას ეხება
    function showProductForm() {
        $('#productFormDiv').show();
        $('#productFormTitle').text('📦 ახალი პროდუქტის დამატება');
        $('#saveNewProduct').text('✅ ბაზაში შენახვა').removeAttr('data-edit-id');
        // ველების გასუფთავება
        $('#new_p_name, #new_p_qty, #new_p_price').val('');
    }

    $(document).on('click', '.editProduct', function() {
    let row = $(this).closest('tr');
    let id = row.data('id');
    
    // სათაურის და ღილაკის ტექსტის შეცვლა
    $('#productFormTitle').text('📝 რედაქტირება');
    $('#saveNewProduct').text('✅ ცვლილების შენახვა').attr('data-edit-id', id);
    
    // მონაცემების ამოღება და მძიმეების მოცილება (რომ JS-მა რიცხვად აღიქვას)
    let name = row.find('.cell-pname').text().trim();
    let qty = row.find('.cell-qty').text().replace(/,/g, ''); 
    let limit = row.find('.cell-plimit').text().trim();
    let unit = row.find('.cell-punit').text().trim();
    let price = row.find('.cell-pprice').text().replace(/[^\d.]/g, ''); // მხოლოდ ციფრები და წერტილი

    // ფორმის შევსება
    $('#edit_product_id').val(id); // დამალული ID
    $('#new_p_name').val(name);
    $('#new_p_unit').val(unit);
    $('#new_p_qty').val(qty);
    $('#new_p_price').val(price);
    $('#new_p_limit').val(limit);
    
    // ფორმის გამოჩენა და ასვლა ზემოთ
    $('#productFormDiv').fadeIn();
    $('.form-container').not('#productFormDiv').hide();
    window.scrollTo({ top: 0, behavior: 'smooth' });
});
</script>