<?php
// ajax_save_product.php
error_reporting(E_ALL);
ini_set('display_errors', 0);

header('Content-Type: application/json');

require_once __DIR__ . '/../config/db.php';

$res = ['status' => 0, 'message' => 'უცნობი შეცდომა'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    // მონაცემების მიღება (გამოიყენეთ ის სახელები, რაც warehouse.php-დან მოდის)
    $id       = isset($_POST['id']) ? intval($_POST['id']) : 0;
    $name     = isset($_POST['name']) ? $mysqli->real_escape_string(trim($_POST['name'])) : '';
    $unit     = isset($_POST['unit']) ? $mysqli->real_escape_string(trim($_POST['unit'])) : '';
    $quantity = isset($_POST['quantity']) ? floatval($_POST['quantity']) : 0;
    $price    = isset($_POST['price']) ? floatval($_POST['price']) : 0;
    // შეცვალე 'limit' -> 'min_limit'
    $limit    = isset($_POST['min_limit']) ? floatval($_POST['min_limit']) : 0;
    // დამატე vat ველი
    $vat      = isset($_POST['vat']) ? intval($_POST['vat']) : 0;

    if (empty($name)) {
        $res['message'] = 'დასახელება აუცილებელია!';
        echo json_encode($res);
        exit;
    }

    if ($id > 0) {
        // 1. რედაქტირება (UPDATE) - დამატე vat ველიც
        $sql = "UPDATE products SET 
                name = '$name', 
                unit = '$unit', 
                quantity = '$quantity', 
                price = '$price', 
                min_limit = '$limit',
                vat = '$vat' 
                WHERE id = $id";
        
        if ($mysqli->query($sql)) {
            $res['status'] = 1;
            $res['message'] = 'მონაცემები წარმატებით განახლდა';
        } else {
            $res['message'] = 'ბაზის შეცდომა განახლებისას: ' . $mysqli->error;
        }

    } else {
        // 2. ახლის დამატება (INSERT) - დამატე vat ველიც
        $sql = "INSERT INTO products (name, unit, quantity, price, min_limit, vat) 
                VALUES ('$name', '$unit', '$quantity', '$price', '$limit', '$vat')";
        
        if ($mysqli->query($sql)) {
            $res['status'] = 1;
            $res['message'] = 'პროდუქტი წარმატებით დაემატა';
            $res['insert_id'] = $mysqli->insert_id;
        } else {
            $res['message'] = 'ბაზის შეცდომა დამატებისას: ' . $mysqli->error;
        }
    }
} else {
    $res['message'] = 'არასწორი მოთხოვნის მეთოდი';
}

echo json_encode($res);
?>