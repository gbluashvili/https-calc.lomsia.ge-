<?php
require_once __DIR__ . '/../config/db.php';

header('Content-Type: application/json');

// მონაცემების მიღება POST მოთხოვნიდან
$id         = intval($_POST['id']);
$name       = $_POST['name'];
$quantity   = floatval($_POST['quantity']);
$min_limit  = floatval($_POST['min_limit']);
$unit       = $_POST['unit'];
$price      = floatval($_POST['price']);
$vat_status = $_POST['vat_status'] ?? 'დღგ-თი'; // ახალი ველი დღგ-სთვის

if ($id > 0) {
    // მონაცემების განახლება (UPDATE)
    // სტრუქტურა: name(s), quantity(d), min_limit(d), unit(s), price(d), vat_status(s), id(i)
    $stmt = $mysqli->prepare("UPDATE products SET name=?, quantity=?, min_limit=?, unit=?, price=?, vat_status=? WHERE id=?");
    $stmt->bind_param("sddsdsi", $name, $quantity, $min_limit, $unit, $price, $vat_status, $id);
} else {
    // ახალი პროდუქტის დამატება (INSERT)
    // სტრუქტურა: name(s), quantity(d), min_limit(d), unit(s), price(d), vat_status(s)
    $stmt = $mysqli->prepare("INSERT INTO products (name, quantity, min_limit, unit, price, vat_status) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sddssd", $name, $quantity, $min_limit, $unit, $price, $vat_status);
}

if ($stmt->execute()) {
    echo json_encode(['status' => 'success']);
} else {
    echo json_encode(['status' => 'error', 'message' => $mysqli->error]);
}