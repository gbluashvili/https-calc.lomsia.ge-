<?php
require_once __DIR__ . '/../config/db.php';

if (isset($_POST['import'])) {
    $file = $_FILES['csv_file']['tmp_name'];
    $handle = fopen($file, "r");
    
    $imported = 0;
    $updated = 0;
    $errors = [];

    // პირველი ხაზის გამოტოვება (თუ სათაურები გაქვთ ექსელში)
    fgetcsv($handle, 1000, ",");

    while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
        // სვეტების გადანაწილება: 0=ID(თუ გაქვთ), 1=სახელი, 2=ფასი, 3=დღგ(1 ან 0)
        $name = trim($mysqli->real_escape_string($data[1])); 
        $price = floatval($data[2]);
        $vat_status = (isset($data[3]) && intval($data[3]) == 1) ? 1 : 0;

        if (!empty($name) && $price >= 0) {
            // ვამოწმებთ არსებობს თუ არა კერძი სახელით
            $check = $mysqli->query("SELECT id FROM dishes WHERE name = '$name'");
            
            if ($check->num_rows > 0) {
                // არსებულის განახლება
                $sql = "UPDATE dishes SET sale_price = $price, enable_vat = $vat_status WHERE name = '$name'";
                if($mysqli->query($sql)) $updated++;
            } else {
                // ახალი კერძის დამატება
                $sql = "INSERT INTO dishes (name, sale_price, enable_vat) VALUES ('$name', $price, $vat_status)";
                if($mysqli->query($sql)) $imported++;
            }
        } else {
            $errors[] = "ხაზი გამოტოვებულია: არასწორი მონაცემები ($name)";
        }
    }
    fclose($handle);
    $msg = "დასრულდა! დაემატა: $imported, განახლდა: $updated.";
}
?>

<!DOCTYPE html>
<html lang="ka">
<head>
    <meta charset="UTF-8">
    <title>მენიუს იმპორტი</title>
    <style>
        body { font-family: 'Segoe UI', sans-serif; background: #f4f7f6; display: flex; justify-content: center; padding: 50px; }
        .card { background: white; padding: 30px; border-radius: 15px; box-shadow: 0 10px 25px rgba(0,0,0,0.1); width: 100%; max-width: 550px; }
        .btn { background: #6f42c1; color: white; border: none; padding: 12px 25px; border-radius: 5px; width: 100%; cursor: pointer; font-size: 16px; transition: 0.3s; }
        .btn:hover { background: #5a32a3; }
        .success-msg { color: #155724; background: #d4edda; padding: 15px; border-radius: 5px; margin-bottom: 20px; border-left: 5px solid #28a745; }
        .info-box { background: #e9ecef; padding: 15px; border-radius: 8px; font-size: 13px; color: #495057; margin-bottom: 20px; }
        table { width: 100%; font-size: 12px; margin-top: 10px; border-collapse: collapse; }
        th, td { border: 1px solid #dee2e6; padding: 5px; text-align: center; }
    </style>
</head>
<body>

<div class="card">
    <h2>📥 მენიუს იმპორტი (Excel/CSV)</h2>
    
    <?php if(isset($msg)) echo "<div class='success-msg'>$msg</div>"; ?>

    <div class="info-box">
        <strong>ფაილის სტრუქტურა (CSV):</strong>
        <table>
            <tr><th>სვეტი 1</th><th>სვეტი 2</th><th>სვეტი 3</th><th>სვეტი 4</th></tr>
            <tr><td>(ნებისმიერი)</td><td>სახელი</td><td>ფასი</td><td>დღგ (1 ან 0)</td></tr>
        </table>
        <p style="margin-top:10px;">* დარწმუნდით, რომ ფაილი შენახულია <strong>CSV (Comma delimited)</strong> ფორმატში.</p>
    </div>
    
    <form method="POST" enctype="multipart/form-data">
        <input type="file" name="csv_file" accept=".csv" required style="margin-bottom: 20px; display: block;">
        <button type="submit" name="import" class="btn">მონაცემების დამუშავება</button>
    </form>
    
    <br>
    <a href="index.php" style="color: #666; text-decoration: none; font-size: 14px;">← მთავარ პანელზე დაბრუნება</a>
</div>

</body>
</html>