<?php
header('Content-Type: application/json');
require_once '../config/db.php';
require_once '../functions/getSalesReport.php';

$start = $_GET['start'] ?? null;
$end   = $_GET['end'] ?? null;
$dish  = $_GET['dish_id'] ?? null;

$data = getSalesReport($mysqli, $start, $end, $dish);
echo json_encode(['status'=>1,'data'=>$data]);
