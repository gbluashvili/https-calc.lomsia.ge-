<?php
require_once __DIR__ . '/../config/db.php';
require_once '../includes/functions.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ფილტრების პარამეტრები
$date_from = $_GET['date_from'] ?? date('Y-m-d', strtotime('-7 days'));
$date_to = $_GET['date_to'] ?? date('Y-m-d');

// ცვლადები ანალიტიკისთვის
$sales_history = [];
$total_revenue = 0;
$total_cost_with_vat = 0;
$total_cost_excluding_vat = 0;
$total_profit = 0;
$total_quantity = 0;
$total_with_vat = 0;
$total_vat = 0;

try {
    // SQL მოთხოვნა ახალი ველებით - გასწორებული
    $query = "
        SELECT 
            s.*, 
            d.name as dish_name,
            d.sale_price as dish_sale_price,
            -- ველები cost_with_vat და cost_excluding_vat უკვე არსებობს ცხრილში
            s.cost_with_vat,
            s.cost_excluding_vat,
            s.profit,
            s.margin_percent,
            s.total_with_vat,
            s.unit_cost_with_vat,
            s.unit_cost_excluding_vat,
            s.unit_profit,
            -- სწორი გამოთვლები
            s.net_amount,
            s.vat_amount,
            -- total_amount არის თვითღირებულება (cost) - ეს არის მცდარი სახელი!
            s.total_amount as cost_with_vat_old, -- ეს არის თვითღირებულება!
            -- გასაყიდი ფასი დღგ-თი
            s.sale_price * s.quantity as total_sale_price_with_vat,
            -- სწორი გამოთვლები თავსებადობისთვის
            COALESCE(s.profit, s.net_amount - s.cost_excluding_vat) as calculated_profit,
            COALESCE(s.margin_percent, 
                CASE 
                    WHEN s.cost_excluding_vat > 0 THEN 
                        ((s.net_amount - s.cost_excluding_vat) / s.cost_excluding_vat) * 100
                    ELSE 0 
                END
            ) as calculated_margin
        FROM sales s 
        LEFT JOIN dishes d ON s.dish_id = d.id 
        WHERE DATE(s.sale_date) BETWEEN ? AND ?
        ORDER BY s.sale_date DESC, s.id DESC
    ";
    
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param("ss", $date_from, $date_to);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result) {
        $sales_history = $result->fetch_all(MYSQLI_ASSOC);
        
        // გამოვთვალოთ ჯამური მაჩვენებლები - გასწორებული
        if (!empty($sales_history)) {
            foreach ($sales_history as $sale) {
                // გაყიდვები (შემოსავალი)
                $total_revenue += floatval($sale['net_amount'] ?? 0);
                
                // თვითღირებულება - ვიყენებთ სწორ ველს
                $cost_with_vat = floatval($sale['cost_with_vat'] ?? $sale['cost_with_vat_old'] ?? 0);
                $cost_excluding_vat = floatval($sale['cost_excluding_vat'] ?? 0);
                
                $total_cost_with_vat += $cost_with_vat;
                $total_cost_excluding_vat += $cost_excluding_vat;
                
                // მოგება
                $profit = floatval($sale['profit'] ?? $sale['calculated_profit'] ?? 0);
                $total_profit += $profit;
                
                // სხვა მაჩვენებლები
                $total_quantity += floatval($sale['quantity'] ?? 0);
                $total_with_vat += floatval($sale['total_with_vat'] ?? 
                    ($sale['net_amount'] + $sale['vat_amount']));
                $total_vat += floatval($sale['vat_amount'] ?? 0);
            }
        }
    }
    
    // დამატებითი შემოწმება - გასწორებული
    $check_query = $mysqli->prepare("
        SELECT 
            COUNT(*) as record_count,
            SUM(quantity) as total_quantity,
            SUM(net_amount) as total_net,
            -- cost_with_vat და total_amount არის ერთი და იგივე!
            SUM(cost_with_vat) as total_cost_with_vat,
            SUM(cost_excluding_vat) as total_cost_excluding_vat,
            SUM(profit) as total_profit,
            SUM(vat_amount) as total_vat,
            SUM(total_with_vat) as total_with_vat
        FROM sales
        WHERE DATE(sale_date) BETWEEN ? AND ?
    ");
    $check_query->bind_param("ss", $date_from, $date_to);
    $check_query->execute();
    $check_result = $check_query->get_result()->fetch_assoc();
    
} catch (Exception $e) {
    $db_error = $e->getMessage();
}

$page_title = "გაყიდვების ისტორია";
include '../includes/header.php';
?>
<link rel="stylesheet" href="../css/style_sales_history.css">
<script>
// Global variable to store selected sale IDs
let selectedSales = [];

function toggleSelectAll() {
    const selectAllCheckbox = document.getElementById('selectAll');
    const checkboxes = document.querySelectorAll('.sale-checkbox');
    const isChecked = selectAllCheckbox.checked;
    
    selectedSales = [];
    
    checkboxes.forEach(checkbox => {
        checkbox.checked = isChecked;
        if (isChecked) {
            selectedSales.push(parseInt(checkbox.value));
        }
    });
    
    updateSelectedCount();
    updateBulkActions();
}

function toggleSale(saleId) {
    const checkbox = document.querySelector(`.sale-checkbox[value="${saleId}"]`);
    
    if (checkbox.checked) {
        selectedSales.push(saleId);
    } else {
        const index = selectedSales.indexOf(saleId);
        if (index > -1) {
            selectedSales.splice(index, 1);
        }
    }
    
    // Update "Select All" checkbox
    const checkboxes = document.querySelectorAll('.sale-checkbox');
    const allChecked = Array.from(checkboxes).every(cb => cb.checked);
    document.getElementById('selectAll').checked = allChecked;
    
    updateSelectedCount();
    updateBulkActions();
}

function updateSelectedCount() {
    const countElement = document.getElementById('selectedCount');
    if (countElement) {
        countElement.textContent = selectedSales.length;
    }
}

function updateBulkActions() {
    const deleteSelectedBtn = document.getElementById('deleteSelectedBtn');
    if (deleteSelectedBtn) {
        deleteSelectedBtn.disabled = selectedSales.length === 0;
    }
}

function deleteSelectedSales() {
    if (selectedSales.length === 0) {
        alert('გთხოვთ აირჩიოთ ჩანაწერები წასაშლელად');
        return;
    }
    
    const confirmMsg = `ნამდვილად გსურთ წაშალოთ ${selectedSales.length} არჩეული ჩანაწერი?`;
    
    if (confirm(confirmMsg)) {
        $.ajax({
            url: 'delete_sales.php',
            type: 'POST',
            data: {
                action: 'delete_selected',
                ids: JSON.stringify(selectedSales)
            },
            dataType: 'json',
            success: function(response) {
                if (response.status === 1) {
                    alert(`✅ ${response.message}`);
                    location.reload();
                } else {
                    alert('❌ შეცდომა: ' + (response.message || 'გაურკვეველი შეცდომა'));
                }
            },
            error: function() {
                alert('❌ სერვერული შეცდომა');
            }
        });
    }
}

function deleteAllSales() {
    const date_from = document.getElementById('date_from').value;
    const date_to = document.getElementById('date_to').value;
    
    if (!date_from || !date_to) {
        alert('გთხოვთ აირჩიოთ პერიოდი წაშლისთვის');
        return;
    }
    
    const confirmMsg = `ნამდვილად გსურთ წაშალოთ ყველა გაყიდვა ${date_from}-დან ${date_to}-მდე?`;
    
    if (confirm(confirmMsg)) {
        $.ajax({
            url: 'delete_sales.php',
            type: 'POST',
            data: {
                action: 'delete_all',
                date_from: date_from,
                date_to: date_to
            },
            dataType: 'json',
            success: function(response) {
                if (response.status === 1) {
                    alert('✅ ' + response.message);
                    location.reload();
                } else {
                    alert('❌ შეცდომა: ' + response.message);
                }
            },
            error: function() {
                alert('❌ სერვერული შეცდომა');
            }
        });
    }
}
</script>

<div class="container" style="width: 100%; max-width: 100%; margin: 0 auto; padding: 0 10px;">
    
    <!-- ფილტრის ფორმა -->
    <div class="filter-bar" style="background: white; padding: 20px; border-radius: 12px; margin-bottom: 25px; box-shadow: 0 2px 10px rgba(0,0,0,0.05);">
        <h3 style="margin-top: 0; margin-bottom: 15px; color: #333; font-size: 1.3em;">🔍 ფილტრაცია პერიოდის მიხედვით</h3>
        <form method="GET" style="display: flex; align-items: center; gap: 15px; flex-wrap: wrap;">
            <div style="display: flex; align-items: center; gap: 8px;">
                <label style="font-weight: 600; color: #555; min-width: 60px;">დაწყება:</label>
                <input type="date" id="date_from" name="date_from" value="<?= $date_from ?>" 
                       style="padding: 10px 15px; border: 2px solid #ddd; border-radius: 8px; font-size: 14px; min-width: 150px;">
            </div>
            <div style="display: flex; align-items: center; gap: 8px;">
                <label style="font-weight: 600; color: #555; min-width: 60px;">დამთავრება:</label>
                <input type="date" id="date_to" name="date_to" value="<?= $date_to ?>" 
                       style="padding: 10px 15px; border: 2px solid #ddd; border-radius: 8px; font-size: 14px; min-width: 150px;">
            </div>
            <button type="submit" class="btn btn-blue" style="padding: 10px 20px;">
                🔍 გაფილტვრა
            </button>
            <a href="sales_history.php" class="btn btn-gray" style="padding: 10px 20px;">
                🗑️ გასუფთავება
            </a>
        </form>
    </div>

    <!-- სტატისტიკის ბარათები - გასწორებული -->
    <div class="stat-cards" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px; margin-bottom: 30px;">
        <div class="stat-card" style="border-color: #007bff; background: white;">
            <h4 style="color: #007bff; font-size: 14px; margin-bottom: 10px;">📊 ჩანაწერები</h4>
            <div class="stat-value" style="color: #007bff; font-size: 2.2em;">
                <?= count($sales_history) ?>
            </div>
            <p style="color: #666; font-size: 13px; margin-top: 5px;">გაყიდვების რაოდენობა</p>
        </div>
        
        <div class="stat-card" style="border-color: #17a2b8; background: white;">
            <h4 style="color: #17a2b8; font-size: 14px; margin-bottom: 10px;">💵 გაყიდვების შემოსავალი</h4>
            <div class="stat-value" style="color: #17a2b8; font-size: 2.2em;">
                <?= number_format($total_revenue, 2) ?> ₾
            </div>
            <p style="color: #666; font-size: 13px; margin-top: 5px;">დღგ-ს გარეშე</p>
            <p style="color: #999; font-size: 11px; margin-top: 3px;">დღგ-ით: <?= number_format($total_revenue * 1.18, 2) ?> ₾</p>
        </div>
        
        <div class="stat-card" style="border-color: #dc3545; background: white;">
            <h4 style="color: #dc3545; font-size: 14px; margin-bottom: 10px;">💰 თვითღირებულება</h4>
            <div class="stat-value" style="color: #dc3545; font-size: 2.2em;">
                <?= number_format($total_cost_with_vat, 2) ?> ₾
            </div>
            <p style="color: #666; font-size: 13px; margin-top: 5px;">დღგ-ით</p>
            <p style="color: #999; font-size: 11px; margin-top: 3px;">დღგ-ს გარეშე: <?= number_format($total_cost_excluding_vat, 2) ?> ₾</p>
        </div>
        
        <div class="stat-card" style="border-color: <?= $total_profit >= 0 ? '#28a745' : '#dc3545' ?>; background: white;">
            <h4 style="color: <?= $total_profit >= 0 ? '#28a745' : '#dc3545' ?>; font-size: 14px; margin-bottom: 10px;">
                <?= $total_profit >= 0 ? '📈 წმინდა მოგება' : '📉 ზარალი' ?>
            </h4>
            <div class="stat-value" style="color: <?= $total_profit >= 0 ? '#28a745' : '#dc3545' ?>; font-size: 2.2em;">
                <?= number_format($total_profit, 2) ?> ₾
            </div>
            <p style="color: #666; font-size: 13px; margin-top: 5px;">
                მომგებიანობა: 
                <?php 
                if ($total_revenue > 0) {
                    $profitability = ($total_profit / $total_revenue) * 100;
                    echo number_format($profitability, 1) . '%';
                } else {
                    echo '0%';
                }
                ?>
            </p>
            <p style="color: #666; font-size: 13px; margin-top: 5px;">
                მარჟა: 
                <?php 
                if ($total_cost_excluding_vat > 0) {
                    $profit_margin = ($total_profit / $total_cost_excluding_vat) * 100;
                    echo number_format($profit_margin, 1) . '%';
                } else {
                    echo '0%';
                }
                ?>
            </p>
        </div>
    </div>

    <?php if (empty($sales_history)): ?>
    <div class="empty-message" style="text-align: center; padding: 60px; background: white; border-radius: 12px; box-shadow: 0 2px 10px rgba(0,0,0,0.05); margin: 30px 0;">
        <div style="font-size: 60px; color: #ddd; margin-bottom: 20px;">📭</div>
        <h3 style="color: #666; margin-bottom: 15px; font-size: 1.5em;">გაყიდვების ისტორია ცარიელია</h3>
        <p style="color: #888; font-size: 16px; margin-bottom: 10px;">არჩეულ პერიოდში არ არის გაყიდვების ჩანაწერები</p>
    </div>
    <?php else: ?>

    <!-- გაყიდვების ცხრილი - გასწორებული -->
    <div class="table-container" style="background: white; border-radius: 12px; padding: 25px; box-shadow: 0 2px 10px rgba(0,0,0,0.05);">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
            <h2 style="margin: 0; color: #333; font-size: 1.5em;">📈 გაყიდვების ისტორია</h2>
            <div style="display: flex; gap: 10px;">
                <button onclick="exportToCSV()" class="btn btn-green" style="padding: 8px 15px; font-size: 14px;">
                    📥 CSV ექსპორტი
                </button>
            </div>
        </div>
        
        <!-- მასობრივი მოქმედებები -->
        <div class="bulk-actions">
            <div style="display: flex; align-items: center; gap: 10px;">
                <input type="checkbox" id="selectAll" onchange="toggleSelectAll()" 
                       style="width: 18px; height: 18px; cursor: pointer;">
                <label for="selectAll" style="font-weight: 600; cursor: pointer;">აირჩიე ყველა</label>
                <span id="selectedCount" class="selected-count">0</span>
            </div>
            
            <div style="display: flex; gap: 10px;">
                <button id="deleteSelectedBtn" onclick="deleteSelectedSales()" 
                        disabled
                        class="btn btn-orange" style="padding: 8px 15px; font-size: 14px;">
                    🗑️ წაშალე არჩეული
                </button>
                
                <button onclick="deleteAllSales()" class="btn btn-red" style="padding: 8px 15px; font-size: 14px;">
                    🗑️ წაშალე ყველა (პერიოდში)
                </button>
            </div>
        </div>
              <table id="salesHistoryTable" class="display compact" style="width:100%">
            <thead>
                <tr style="background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 1200px);">
                    <th class="checkbox-column">
                        <input type="checkbox" id="selectAllHeader" onchange="toggleSelectAll()" 
                               style="width: 16px; height: 16px;">
                    </th>
                    <th>ID</th>
                    <th>თარიღი</th>
                    <th>კერძი</th>
                    <th>რაოდ.</th>
                    <th>თვითღირ. (დღგ-თი)</th>
                    <th>თვითღირ. (Ex.VAT)</th>
                    <th>გაყიდვა (დღგ-თი)</th>
                    <th>გაყიდვა (Ex.VAT)</th>
                    <th>დღგ</th>
                    <th>ამონაგები</th>
                    <th>მარჟა %</th>
                    <th style="width: 100px;">მოქმედება</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                $counter = 0;
                foreach($sales_history as $sale): 
                    $counter++;
                    $dish_name = $sale['dish_name'] ?? 'კერძი';
                    $quantity = $sale['quantity'] ?? 0;
                    
                    // თვითღირებულება - ვიყენებთ სწორ ველებს
                    $cost_with_vat = floatval($sale['cost_with_vat'] ?? $sale['cost_with_vat_old'] ?? 0);
                    $cost_excluding_vat = floatval($sale['cost_excluding_vat'] ?? 0);
                    
                    // გაყიდვების შემოსავალი
                    $net_amount = $sale['net_amount'] ?? 0;
                    $vat_amount = $sale['vat_amount'] ?? 0;
                    $total_with_vat = $sale['total_with_vat'] ?? ($net_amount + $vat_amount);
                    
                    // მოგება
                    $profit = $sale['profit'] ?? $sale['calculated_profit'] ?? 0;
                    $margin_percent = $sale['margin_percent'] ?? $sale['calculated_margin'] ?? 0;
                    $sale_date = $sale['sale_date'] ?? '';
                    
                    // ერთეულის გამოთვლები
                    $unit_cost_with_vat = $quantity > 0 ? $cost_with_vat / $quantity : 0;
                    $unit_cost_excluding_vat = $quantity > 0 ? $cost_excluding_vat / $quantity : 0;
                    $unit_revenue = $quantity > 0 ? $net_amount / $quantity : 0;
                    $unit_profit = $quantity > 0 ? $profit / $quantity : 0;
                ?>
                <tr data-id="<?= $sale['id'] ?>">
                    <td class="checkbox-column">
                        <input type="checkbox" class="sale-checkbox" 
                               value="<?= $sale['id'] ?>" 
                               onchange="toggleSale(<?= $sale['id'] ?>)"
                               style="width: 16px; height: 16px; cursor: pointer;">
                    </td>
                    <td style="font-weight: 600; color: #666;">
                        #<?= $sale['id'] ?>
                    </td>
                    <td>
                        <div style="font-weight: 600; color: #333;"><?= date('d.m.Y', strtotime($sale_date)) ?></div>
                        <div style="font-size: 12px; color: #888;"><?= date('H:i', strtotime($sale_date)) ?></div>
                    </td>
                    <td>
                        <div style="font-weight: 600; color: #333;"><?= htmlspecialchars($dish_name) ?></div>
                        <div style="font-size: 11px; color: #888;">ID: <?= $sale['dish_id'] ?></div>
                    </td>
                    <td style="text-align: center; font-weight: 600; color: #495057;">
                        <?= number_format($quantity, 3) ?>
                    </td>
                    <td style="text-align: right;">
                        <div style="color: #dc3545; font-weight: 700;">
                            <?= number_format($cost_with_vat, 2) ?> ₾
                        </div>
                        <div style="font-size: 11px; color: #dc3545;">
                            <?= number_format($unit_cost_with_vat, 2) ?> ₾/ერთ.
                        </div>
                    </td>
                    <td style="text-align: right;">
                        <div style="color: #dc3545; font-weight: 700;">
                            <?= number_format($cost_excluding_vat, 2) ?> ₾
                        </div>
                        <div style="font-size: 11px; color: #dc3545;">
                            <?= number_format($unit_cost_excluding_vat, 2) ?> ₾/ერთ.
                        </div>
                    </td>
                    <td style="text-align: right; background: #e8f4fd; font-weight: 700; color: #17a2b8;">
                        <?= number_format($total_with_vat, 2) ?> ₾
                    </td>
                    <td style="text-align: right; background: #e8f4fd; font-weight: 700; color: #17a2b8;">
                        <?= number_format($net_amount, 2) ?> ₾
                        <div style="font-size: 11px; color: #17a2b8;">
                            <?= number_format($unit_revenue, 2) ?> ₾/ერთ.
                        </div>
                    </td>
                    <td style="text-align: right; color: #6f42c1; font-weight: 600;">
                        <?= number_format($vat_amount, 2) ?> ₾
                    </td>
                    <td style="text-align: right;">
                        <div style="font-weight: 700; color: <?= $profit >= 0 ? '#28a745' : '#dc3545' ?>;">
                            <?= number_format($profit, 2) ?> ₾
                        </div>
                        <div style="font-size: 11px; color: <?= $profit >= 0 ? '#28a745' : '#dc3545' ?>;">
                            <?= number_format($unit_profit, 2) ?> ₾/ერთ.
                        </div>
                    </td>
                    <td style="text-align: right; font-weight: 700; color: <?= $margin_percent >= 0 ? '#28a745' : '#dc3545' ?>;">
                        <?= number_format($margin_percent, 1) ?>%
                    </td>
                    <td style="text-align: center;">
                        <button class="btn btn-sm btn-red delete-single" 
                                data-id="<?= $sale['id'] ?>" 
                                data-name="<?= htmlspecialchars($dish_name) ?>"
                                style="padding: 5px 10px; font-size: 12px; background: #dc3545; color: white; border: none; border-radius: 4px; cursor: pointer;">
                            🗑️ წაშლა
                        </button>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
            <tfoot>
                <tr style="background: #f8f9fa; font-weight: bold; border-top: 2px solid #ddd;">
                    <td colspan="4" style="text-align: right; padding: 15px; font-size: 15px;">ჯამური მაჩვენებლები:</td>
                    <td style="text-align: center; padding: 15px; font-size: 15px;"><?= number_format($total_quantity, 3) ?></td>
                    <td style="text-align: right; padding: 15px; font-size: 15px; color: #dc3545;">
                        <?= number_format($total_cost_with_vat, 2) ?> ₾
                    </td>
                    <td style="text-align: right; padding: 15px; font-size: 15px; color: #dc3545;">
                        <?= number_format($total_cost_excluding_vat, 2) ?> ₾
                    </td>
                    <td style="text-align: right; padding: 15px; font-size: 15px; color: #17a2b8;">
                        <?= number_format($total_with_vat, 2) ?> ₾
                    </td>
                    <td style="text-align: right; padding: 15px; font-size: 15px; color: #17a2b8;">
                        <?= number_format($total_revenue, 2) ?> ₾
                    </td>
                    <td style="text-align: right; padding: 15px; font-size: 15px; color: #6f42c1;">
                        <?= number_format($total_vat, 2) ?> ₾
                    </td>
                    <td style="text-align: right; padding: 15px; font-size: 15px; color: <?= $total_profit >= 0 ? '#28a745' : '#dc3545' ?>;">
                        <?= number_format($total_profit, 2) ?> ₾
                    </td>
                    <td style="text-align: right; padding: 15px; font-size: 15px; color: <?= $total_profit >= 0 ? '#28a745' : '#dc3545' ?>;">
                        <?php 
                        if ($total_cost_excluding_vat > 0) {
                            $total_margin = ($total_profit / $total_cost_excluding_vat) * 100;
                            echo number_format($total_margin, 1) . '%';
                        } else {
                            echo '0%';
                        }
                        ?>
                    </td>
                    <td></td>
                </tr>
            </tfoot>
        </table>
    </div>

    <?php endif; ?>
</div>

<script>
$(document).ready(function() {
    <?php if(!empty($sales_history)): ?>
    // DataTable ინიციალიზაცია
    $('#salesHistoryTable').DataTable({
        "pageLength": 25,
        "lengthMenu": [10, 25, 50, 100],
        "language": {
            "url": "//cdn.datatables.net/plug-ins/1.11.5/i18n/ka.json"
        },
        "order": [[2, "desc"]], // თარიღის მიხედვით დალაგება
        "responsive": true,
        "stateSave": true,
        "columnDefs": [
            { "orderable": false, "targets": [0, 12] }, // არასორტირებადი სვეტები
            { "searchable": false, "targets": [0] } // არასაძიებო სვეტები
        ]
    });
    
    // ერთი ჩანაწერის წაშლა
    $(document).on('click', '.delete-single', function() {
        const saleId = $(this).data('id');
        const saleName = $(this).data('name');
        
        if (confirm(`ნამდვილად გსურთ წაშალოთ გაყიდვა: "${saleName}"?`)) {
            $.ajax({
                url: 'delete_sales.php',
                type: 'POST',
                data: {
                    action: 'delete_single',
                    id: saleId
                },
                dataType: 'json',
                success: function(response) {
                    if (response.status === 1) {
                        alert('✅ ჩანაწერი წარმატებით წაიშალა!');
                        location.reload();
                    } else {
                        alert('❌ შეცდომა: ' + (response.message || 'გაურკვეველი შეცდომა'));
                    }
                },
                error: function() {
                    alert('❌ სერვერული შეცდომა');
                }
            });
        }
    });
    
    // CSV ექსპორტის ფუნქცია
    window.exportToCSV = function() {
        let csv = [];
        let rows = document.querySelectorAll("#salesHistoryTable tr");
        
        // თავების დამატება (გამოვტოვოთ ჩეკბოქსის სვეტი)
        let headers = [];
        document.querySelectorAll("#salesHistoryTable thead th").forEach((th, index) => {
            if (index !== 0) { // გამოვტოვოთ პირველი სვეტი (ჩეკბოქსი)
                headers.push(th.innerText.replace(/\n/g, ' ').trim());
            }
        });
        csv.push(headers.join(","));
        
        // მონაცემების დამატება (გამოვტოვოთ ფუტერი და პირველი სვეტი)
        for (let i = 1; i < rows.length - 1; i++) {
            let row = [], cols = rows[i].querySelectorAll("td");
            
            for (let j = 1; j < cols.length; j++) { // j=1 რადგან გამოვტოვოთ პირველი სვეტი
                let text = cols[j].innerText.replace(/\n/g, ' ').trim();
                row.push('"' + text.replace(/"/g, '""') + '"');
            }
            
            csv.push(row.join(","));
        }
        
        let csvContent = csv.join("\n");
        let blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        let link = document.createElement("a");
        let url = URL.createObjectURL(blob);
        
        link.setAttribute("href", url);
        link.setAttribute("download", "გაყიდვების_ისტორია_<?= date('Y-m-d', strtotime($date_from)) ?>_<?= date('Y-m-d', strtotime($date_to)) ?>.csv");
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };
    <?php endif; ?>
});
</script>

<?php
include '../includes/footer.php';
?>