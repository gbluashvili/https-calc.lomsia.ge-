<?php
require_once __DIR__.'/../config/db.php';
require_once __DIR__.'/../functions/getProducts.php';

$dish_id = (int)($_GET['dish_id'] ?? 0);
if ($dish_id <= 0) die('Invalid dish');

$products = getProducts($mysqli);
?>
<!DOCTYPE html>
<html lang="ka">
<head>
<meta charset="UTF-8">
<title>კერძის რეცეპტი</title>
<style>
table { border-collapse: collapse; width:70%; }
th,td { border:1px solid #ccc; padding:8px; text-align:center; }
</style>
</head>
<body>

<h2>კერძის რეცეპტი (Dish ID: <?= $dish_id ?>)</h2>

<select id="product_id">
    <option value="">პროდუქტი</option>
    <?php foreach($products as $p): ?>
        <option value="<?= $p['id'] ?>">
            <?= $p['name'] ?> (<?= $p['unit'] ?>)
        </option>
    <?php endforeach; ?>
</select>

<input type="number" id="quantity" step="0.001" placeholder="რაოდენობა">

<button onclick="addProduct()">დამატება</button>

<table id="recipeTable"></table>

<script>
function loadRecipe(){
    fetch('ajax_get_dish_products.php?dish_id=<?= $dish_id ?>')
    .then(r=>r.json())
    .then(res=>{
        let html='<tr><th>პროდუქტი</th><th>რაოდენობა</th></tr>';
        res.data.forEach(r=>{
            html+=`<tr>
                <td>${r.name}</td>
                <td>${r.quantity}</td>
            </tr>`;
        });
        document.getElementById('recipeTable').innerHTML=html;
    });
}

function addProduct(){
    let pid=document.getElementById('product_id').value;
    let qty=document.getElementById('quantity').value;

    fetch('ajax_save_dish_products.php',{
        method:'POST',
        headers:{'Content-Type':'application/x-www-form-urlencoded'},
        body:`dish_id=<?= $dish_id ?>&product_id=${pid}&quantity=${qty}`
    }).then(()=>loadRecipe());
}

loadRecipe();
</script>

</body>
</html>
