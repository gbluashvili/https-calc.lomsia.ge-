<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once '../config/db.php';
require_once '../includes/functions.php';

$dish_id = 20;
$cost = calculateDishCost($conn, $dish_id);

echo "კერძის თვითღირებულება: " . $cost . " ₾";
