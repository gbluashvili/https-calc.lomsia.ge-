<?php
require_once __DIR__ . '/../config/db.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

// ჩაამატეთ ეს დასაწყისში შეცდომების ნახვისთვის
error_reporting(E_ALL);
ini_set('display_errors', 1);

$response = ['status' => 0, 'message' => ''];

// ლოგირებისთვის (დროებით)
file_put_contents('dish_log.txt', date('Y-m-d H:i:s') . " - მეთოდი: " . $_SERVER['REQUEST_METHOD'] . "\n", FILE_APPEND);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    $response['message'] = 'მოთხოვნის მეთოდი უნდა იყოს POST, მიღებულია: ' . $_SERVER['REQUEST_METHOD'];
    echo json_encode($response);
    exit;
}

// მიღებული მონაცემების ლოგირება
$postData = file_get_contents('php://input');
file_put_contents('dish_log.txt', "POST data: " . $postData . "\n", FILE_APPEND);

// ჩვეულებრივი POST მონაცემების მიღება
$id = isset($_POST['id']) ? intval($_POST['id']) : 0;
$name = isset($_POST['name']) ? trim($_POST['name']) : '';
$price = isset($_POST['price']) ? floatval($_POST['price']) : 0;

// ალტერნატიულად, თუ JSON მოდის
if (empty($name) && !empty($postData)) {
    $jsonData = json_decode($postData, true);
    if ($jsonData) {
        $id = isset($jsonData['id']) ? intval($jsonData['id']) : 0;
        $name = isset($jsonData['name']) ? trim($jsonData['name']) : '';
        $price = isset($jsonData['price']) ? floatval($jsonData['price']) : 0;
    }
}

file_put_contents('dish_log.txt', "Parsed: id=$id, name=$name, price=$price\n", FILE_APPEND);

if (empty($name)) {
    $response['message'] = 'კერძის დასახელება არ არის მითითებული';
    echo json_encode($response);
    exit;
}

if ($price <= 0) {
    $response['message'] = 'კერძის ფასი არასწორია: ' . $price;
    echo json_encode($response);
    exit;
}

try {
    if ($id > 0) {
        // რედაქტირება
        $stmt = $mysqli->prepare("UPDATE dishes SET name = ?, sale_price = ? WHERE id = ?");
        $stmt->bind_param('sdi', $name, $price, $id);
    } else {
        // ახალი კერძი
        $stmt = $mysqli->prepare("INSERT INTO dishes (name, sale_price) VALUES (?, ?)");
        $stmt->bind_param('sd', $name, $price);
    }
    
    if ($stmt->execute()) {
        $response['status'] = 1;
        $response['message'] = $id > 0 ? 'კერძი განახლდა წარმატებით' : 'კერძი დაემატა წარმატებით';
        if ($id == 0) {
            $response['new_id'] = $stmt->insert_id;
        }
    } else {
        $response['message'] = 'შეცდომა მონაცემთა ბაზაში: ' . $stmt->error;
    }
    
    $stmt->close();
    
} catch (Exception $e) {
    $response['message'] = 'გაუთვალისწინებელი შეცდომა: ' . $e->getMessage();
}

echo json_encode($response);
exit;
?>