<?php
require_once __DIR__ . '/../config/db.php';

// მონაცემების წამოღება
$sql = "SELECT s.*, 
        (SELECT SUM(total_amount) FROM purchases WHERE supplier = s.name) as turnover,
        (SELECT MAX(purchase_date) FROM purchases WHERE supplier = s.name) as last_order,
        (SELECT GROUP_CONCAT(DISTINCT p.name SEPARATOR ', ') 
         FROM purchases pr 
         JOIN products p ON pr.product_id = p.id 
         WHERE pr.supplier = s.name) as provided_products
        FROM suppliers s 
        ORDER BY turnover DESC";

$suppliers = $mysqli->query($sql)->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="ka">
<head>
    <meta charset="UTF-8">
    <title>მომწოდებლების რეესტრი</title>
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.js"></script>
    <style>
        body { font-family: sans-serif; padding: 20px; background: #f4f7f6; }
        .card { background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); margin-bottom: 20px; }
        .btn { padding: 8px 12px; border-radius: 4px; border: none; cursor: pointer; text-decoration: none; display: inline-block; font-size: 13px; }
        .btn-back { background: #6c757d; color: white; margin-bottom: 20px; }
        .btn-edit { background: #ffc107; color: black; }
        .btn-save { background: #28a745; color: white; }
        .btn-cancel { background: #dc3545; color: white; }
        #editFormContainer { display: none; border-left: 5px solid #ffc107; }
        .form-group { margin-bottom: 10px; display: inline-block; margin-right: 10px; }
        .form-group label { display: block; font-size: 12px; color: #666; }
        .form-group input { padding: 8px; border: 1px solid #ddd; border-radius: 4px; }
        table { width: 100%; border-collapse: collapse; }
    </style>
</head>
<body>

    <a href="index.php" class="btn btn-back">⬅ უკან დაბრუნება</a>

    <div id="editFormContainer" class="card">
        <h3>✏️ მომწოდებლის რედაქტირება</h3>
        <input type="hidden" id="edit_s_id">
        <div class="form-group">
            <label>დასახელება</label>
            <input type="text" id="edit_s_name">
        </div>
        <div class="form-group">
            <label>ტელეფონი</label>
            <input type="text" id="edit_s_phone">
        </div>
        <div style="margin-top: 10px;">
            <button class="btn btn-save" id="saveSupplierUpdate">ცვლილების შენახვა</button>
            <button class="btn btn-cancel" onclick="$('#editFormContainer').hide()">გაუქმება</button>
        </div>
    </div>
    
    <div class="card">
        <h2>🤝 მომწოდებლების რეესტრი</h2>
        <table id="supplierTable" class="display">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>მომწოდებელი</th>
                    <th>ტელეფონი</th>
                    <th>ბრუნვა</th>
                    <th>მოქმედება</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($suppliers as $s): ?>
                <tr data-id="<?= $s['id'] ?>">
                    <td><?= $s['id'] ?></td>
                    <td class="s-name"><strong><?= htmlspecialchars($s['name']) ?></strong></td>
                    <td class="s-phone"><?= htmlspecialchars($s['phone'] ?? '-') ?></td>
                    <td><?= number_format($s['turnover'] ?? 0, 2) ?> ₾</td>
                    <td>
                        <button class="btn btn-edit openEdit">შეცვლა</button>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <script>
    $(document).ready(function() {
        // ცხრილის ინიციალიზაცია
        $('#supplierTable').DataTable({
            "language": { "url": "//cdn.datatables.net/plug-ins/1.11.5/i18n/ka.json" }
        });

        // რედაქტირების პანელის გახსნა
        $(document).on('click', '.openEdit', function() {
            let row = $(this).closest('tr');
            let id = row.data('id');
            let name = row.find('.s-name').text();
            let phone = row.find('.s-phone').text();

            $('#edit_s_id').val(id);
            $('#edit_s_name').val(name);
            $('#edit_s_phone').val(phone === '-' ? '' : phone);
            
            $('#editFormContainer').show();
            window.scrollTo(0, 0);
        });

        // შენახვის ღილაკი
        $('#saveSupplierUpdate').on('click', function() {
            let sData = {
                id: $('#edit_s_id').val(),
                name: $('#edit_s_name').val(),
                phone: $('#edit_s_phone').val()
            };

            if(!sData.name) {
                alert('სახელი აუცილებელია!');
                return;
            }

            $.ajax({
                url: 'ajax_update_supplier.php',
                type: 'POST',
                data: sData,
                dataType: 'json',
                success: function(res) {
                    if(res.status === 'success') {
                        alert('წარმატებით განახლდა');
                        location.reload();
                    } else {
                        alert('შეცდომა: ' + res.message);
                    }
                },
                error: function(xhr) {
                    alert('კავშირის შეცდომა! შეამოწმეთ Console.');
                    console.log(xhr.responseText);
                }
            });
        });
    }); // <-- აქ სრულდება ready ფუნქცია
    </script>
</body>
</html>