<?php
// delete_sales.php - მარტივი ვერსია
require_once __DIR__ . '/../config/db.php';

header('Content-Type: application/json');

try {
    $action = $_POST['action'] ?? '';
    $response = ['status' => 0, 'message' => 'არასწორი მოქმედება'];
    
    switch ($action) {
        case 'delete_single':
            $id = intval($_POST['id'] ?? 0);
            
            if ($id > 0) {
                $delete_stmt = $mysqli->prepare("DELETE FROM sales WHERE id = ?");
                $delete_stmt->bind_param("i", $id);
                
                if ($delete_stmt->execute()) {
                    $response = [
                        'status' => 1,
                        'message' => 'გაყიდვა წარმატებით წაიშალა'
                    ];
                } else {
                    $response = [
                        'status' => 0,
                        'message' => 'წაშლის დროს მოხდა შეცდომა'
                    ];
                }
            }
            break;
            
        case 'delete_selected':
            $ids_json = $_POST['ids'] ?? '[]';
            $ids = json_decode($ids_json, true);
            
            if (!empty($ids) && is_array($ids)) {
                $ids = array_map('intval', $ids);
                $ids = array_filter($ids, function($id) {
                    return $id > 0;
                });
                
                if (!empty($ids)) {
                    $placeholders = str_repeat('?,', count($ids) - 1) . '?';
                    $stmt = $mysqli->prepare("DELETE FROM sales WHERE id IN ($placeholders)");
                    
                    $types = str_repeat('i', count($ids));
                    $stmt->bind_param($types, ...$ids);
                    
                    if ($stmt->execute()) {
                        $deleted_count = $stmt->affected_rows;
                        $response = [
                            'status' => 1,
                            'message' => "{$deleted_count} ჩანაწერი წარმატებით წაიშალა"
                        ];
                    }
                }
            }
            break;
            
        case 'delete_all':
            $date_from = $_POST['date_from'] ?? '';
            $date_to = $_POST['date_to'] ?? '';
            
            if (!empty($date_from) && !empty($date_to)) {
                $stmt = $mysqli->prepare("DELETE FROM sales WHERE DATE(sale_date) BETWEEN ? AND ?");
                $stmt->bind_param("ss", $date_from, $date_to);
                
                if ($stmt->execute()) {
                    $deleted_count = $stmt->affected_rows;
                    $response = [
                        'status' => 1,
                        'message' => "პერიოდში {$date_from}-დან {$date_to}-მდე წაიშალა {$deleted_count} ჩანაწერი"
                    ];
                }
            }
            break;
    }
    
    echo json_encode($response);
    
} catch (Exception $e) {
    echo json_encode([
        'status' => 0,
        'message' => 'სერვერული შეცდომა'
    ]);
}