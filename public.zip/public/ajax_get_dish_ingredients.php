<?php
// ajax_save_recipe.php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';

header('Content-Type: application/json');

// მონაცემთა ვალიდაცია
$dish_id = isset($_POST['dish_id']) ? intval($_POST['dish_id']) : 0;
$ingredients = isset($_POST['ingredients']) ? $_POST['ingredients'] : [];

if ($dish_id <= 0) {
    echo json_encode([
        'status' => 0,
        'message' => 'არასწორი კერძის ID'
    ]);
    exit;
}

// ვალიდაცია: უნდა იყოს მინიმუმ ერთი ინგრედიენტი
if (!is_array($ingredients) || count($ingredients) === 0) {
    echo json_encode([
        'status' => 0,
        'message' => 'დაამატეთ მინიმუმ ერთი ინგრედიენტი'
    ]);
    exit;
}

try {
    // დაიწყეთ ტრანზაქცია
    $mysqli->begin_transaction();
    
    // წაშალეთ ძველი ინგრედიენტები ამ კერძისთვის
    $delete_stmt = $mysqli->prepare("DELETE FROM recipe_ingredients WHERE dish_id = ?");
    $delete_stmt->bind_param("i", $dish_id);
    $delete_stmt->execute();
    $delete_stmt->close();
    
    // დაამატეთ ახალი ინგრედიენტები
    $insert_stmt = $mysqli->prepare("
        INSERT INTO recipe_ingredients (dish_id, product_id, quantity, unit) 
        VALUES (?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE quantity = VALUES(quantity), unit = VALUES(unit)
    ");
    
    $success_count = 0;
    foreach ($ingredients as $ingredient) {
        $product_id = intval($ingredient['product_id'] ?? 0);
        $quantity = floatval($ingredient['quantity'] ?? 0);
        $unit = isset($ingredient['unit']) ? trim($ingredient['unit']) : null;
        
        if ($product_id > 0 && $quantity > 0) {
            $insert_stmt->bind_param("iids", $dish_id, $product_id, $quantity, $unit);
            if ($insert_stmt->execute()) {
                $success_count++;
            }
        }
    }
    
    $insert_stmt->close();
    
    // დაასრულეთ ტრანზაქცია
    $mysqli->commit();
    
    echo json_encode([
        'status' => 1,
        'message' => 'რეცეპტი წარმატებით შენახულია',
        'saved_count' => $success_count,
        'total_count' => count($ingredients)
    ]);
    
} catch (Exception $e) {
    // გააუქმეთ ტრანზაქცია შეცდომის შემთხვევაში
    $mysqli->rollback();
    
    error_log('Error saving recipe: ' . $e->getMessage());
    
    echo json_encode([
        'status' => 0,
        'message' => 'შეცდომა რეცეპტის შენახვისას: ' . $e->getMessage()
    ]);
}

exit;
?>