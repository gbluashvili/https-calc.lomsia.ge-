<?php
require_once __DIR__ . '/../config/db.php';

error_reporting(E_ALL);
ini_set('display_errors', 1);

header('Content-Type: application/json; charset=utf-8');

// Check request method
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['status' => 0, 'message' => 'არასწორი მოთხოვნის მეთოდი']);
    exit;
}

// Get data
$items_json = isset($_POST['items']) ? $_POST['items'] : '[]';
$total_quantity = isset($_POST['total_quantity']) ? intval($_POST['total_quantity']) : 0;
$total_amount = isset($_POST['total_amount']) ? floatval($_POST['total_amount']) : 0;
$vat_amount = isset($_POST['vat_amount']) ? floatval($_POST['vat_amount']) : 0;
$final_amount = isset($_POST['final_amount']) ? floatval($_POST['final_amount']) : 0;

// Decode items
$items = json_decode($items_json, true);
if ($items === null || !is_array($items)) {
    echo json_encode(['status' => 0, 'message' => 'არასწორი ფორმატი']);
    exit;
}

if (count($items) === 0) {
    echo json_encode(['status' => 0, 'message' => 'არ არის კერძები']);
    exit;
}

try {
    $mysqli->begin_transaction();
    
    // 1. დავამატოთ გაყიდვა sales ცხრილში
    $sale_stmt = $mysqli->prepare("INSERT INTO sales 
        (dish_id, dish_name, quantity, net_amount, vat_amount, total_amount, sale_price, total_price, sale_date) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())");
    
    if (!$sale_stmt) {
        throw new Exception("შეცდომა გაყიდვის მომზადებისას: " . $mysqli->error);
    }
    
    // 2. განვაახლოთ პროდუქტების ნაშთები რეცეპტის მიხედვით
    foreach ($items as $item) {
        $dish_id = intval($item['dish_id']);
        $quantity = intval($item['quantity']);
        $price = floatval($item['price']);
        $total = floatval($item['total']);
        
        // გამოვთვალოთ დღგ
        $net_amount = $total / 1.18;
        $vat_amount_item = $total - $net_amount;
        
        // დავამატოთ გაყიდვა
        $sale_stmt->bind_param("isiddddd", 
            $dish_id,
            $item['dish_name'],
            $quantity,
            $net_amount,
            $vat_amount_item,
            $total,
            $price,
            $total
        );
        
        if (!$sale_stmt->execute()) {
            throw new Exception("შეცდომა გაყიდვის ჩაწერისას: " . $sale_stmt->error);
        }
        
        // განვაახლოთ პროდუქტების ნაშთები
        updateProductStock($mysqli, $dish_id, $quantity);
    }
    
    $sale_stmt->close();
    
    // 3. მივიღოთ ბოლო გაყიდვის ID
    $last_id = $mysqli->insert_id;
    
    $mysqli->commit();
    
    echo json_encode([
        'status' => 1,
        'message' => 'გაყიდვა წარმატებით დასრულდა',
        'sale_id' => $last_id,
        'total_items' => count($items),
        'total_amount' => $total_amount
    ]);
    
} catch (Exception $e) {
    $mysqli->rollback();
    error_log("Sale error: " . $e->getMessage());
    echo json_encode(['status' => 0, 'message' => $e->getMessage()]);
}

$mysqli->close();

// ფუნქცია პროდუქტების ნაშთის განახლებისთვის
function updateProductStock($mysqli, $dish_id, $quantity) {
    // მივიღოთ კერძის რეცეპტი
    $recipe_query = $mysqli->prepare("
        SELECT dc.product_id, dc.quantity as recipe_qty, dc.unit, p.quantity as stock_qty
        FROM dish_calc dc
        LEFT JOIN products p ON dc.product_id = p.id
        WHERE dc.dish_id = ?
    ");
    
    $recipe_query->bind_param("i", $dish_id);
    $recipe_query->execute();
    $result = $recipe_query->get_result();
    
    while ($row = $result->fetch_assoc()) {
        $product_id = $row['product_id'];
        $recipe_qty = floatval($row['recipe_qty']);
        $stock_qty = floatval($row['stock_qty']);
        
        // გამოვთვალოთ საჭირო რაოდენობა
        $required_qty = $recipe_qty * $quantity;
        
        // განვაახლოთ ნაშთი
        $update_stmt = $mysqli->prepare("UPDATE products SET quantity = quantity - ? WHERE id = ?");
        $update_stmt->bind_param("di", $required_qty, $product_id);
        $update_stmt->execute();
        $update_stmt->close();
    }
    
    $recipe_query->close();
}
?>