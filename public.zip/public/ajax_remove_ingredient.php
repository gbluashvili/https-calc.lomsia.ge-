<?php
// ajax_remove_ingredient.php
error_reporting(E_ALL);
ini_set('display_errors', 0);
header('Content-Type: application/json');

require_once __DIR__ . '/../config/db.php';

$res = ['status' => 0, 'message' => 'უცნობი შეცდომა'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = isset($_POST['id']) ? intval($_POST['id']) : 0;
    
    // ვალიდაცია
    if ($id <= 0) {
        $res['message'] = 'არასწორი ინგრედიენტის ID';
        echo json_encode($res);
        exit;
    }
    
    try {
        // მივიღოთ ინფორმაცია წასაშლელი ინგრედიენტის შესახებ (ლოგინგისთვის)
        $info_stmt = $mysqli->prepare("SELECT dc.*, d.name as dish_name, p.name as product_name 
                                       FROM dish_calc dc
                                       JOIN dishes d ON dc.dish_id = d.id
                                       JOIN products p ON dc.product_id = p.id
                                       WHERE dc.id = ?");
        $info_stmt->bind_param("i", $id);
        $info_stmt->execute();
        $info_result = $info_stmt->get_result();
        
        if ($info_result->num_rows === 0) {
            throw new Exception('ინგრედიენტი არ მოიძებნა');
        }
        
        $ingredient = $info_result->fetch_assoc();
        $info_stmt->close();
        
        // წაშალეთ ინგრედიენტი
        $delete_stmt = $mysqli->prepare("DELETE FROM dish_calc WHERE id = ?");
        $delete_stmt->bind_param("i", $id);
        
        if ($delete_stmt->execute()) {
            $res['status'] = 1;
            $res['message'] = 'ინგრედიენტი წარმატებით წაიშალა';
            $res['deleted'] = [
                'id' => $id,
                'dish_id' => $ingredient['dish_id'],
                'dish_name' => $ingredient['dish_name'],
                'product_id' => $ingredient['product_id'],
                'product_name' => $ingredient['product_name'],
                'quantity' => $ingredient['quantity']
            ];
        } else {
            throw new Exception('ბაზის შეცდომა: ' . $delete_stmt->error);
        }
        
        $delete_stmt->close();
        
    } catch (Exception $e) {
        $res['message'] = $e->getMessage();
        $res['debug'] = ['id' => $id];
    }
} else {
    $res['message'] = 'არასწორი მოთხოვნის მეთოდი';
}

echo json_encode($res);
?>