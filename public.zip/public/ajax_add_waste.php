<?php
require_once __DIR__ . '/../config/db.php';

$p_id   = intval($_POST['product_id']);
$qty    = floatval($_POST['quantity']);
$reason = $_POST['reason'];

if ($p_id > 0 && $qty > 0) {
    // 1. ვწერთ ჩამოწერის ისტორიაში
    $stmt = $mysqli->prepare("INSERT INTO waste (product_id, quantity, reason) VALUES (?, ?, ?)");
    $stmt->bind_param("ids", $p_id, $qty, $reason);
    $stmt->execute();

    // 2. ვაკლებთ ნაშთს საწყობიდან
    $mysqli->query("UPDATE products SET quantity = quantity - $qty WHERE id = $p_id");

    echo json_encode(['status' => 'success']);
} else {
    echo json_encode(['status' => 'error']);
}