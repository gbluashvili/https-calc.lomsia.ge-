<?php
require_once __DIR__ . '/../config/db.php';

$date_from = $_GET['date_from'] ?? date('Y-m-d');
$date_to   = $_GET['date_to']   ?? date('Y-m-d');

$query = "SELECT * FROM sales WHERE DATE(sale_date) >= ? AND DATE(sale_date) <= ? ORDER BY sale_date DESC";
$stmt = $mysqli->prepare($query);
$stmt->bind_param("ss", $date_from, $date_to);
$stmt->execute();
$sales = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

$total_cost = 0;
$total_revenue = 0;
$total_quantity = 0;

foreach($sales as $s) {
    $total_cost += $s['total_amount']; // თვითღირებულება
    $total_revenue += ($s['sale_price'] * $s['quantity']); // ნავაჭრი
    $total_quantity += $s['quantity']; // მთლიანი რაოდენობა
}

$total_profit = $total_revenue - $total_cost;

// ===========================================
// ჰედერის ჩასმა აქ
// ===========================================
$page_title = "გაყიდვების რეპორტები"; // ეს გადაეცემა ჰედერს
include '../includes/header.php'; // ეს ჩაიტვირთება header.php ფაილი
// ===========================================
?>

<!-- მთავარი კონტენტი იწყება აქ (ჰედერის შემდეგ) -->

<div class="container" style="max-width: 1200px; margin: 20px auto; background: white; padding: 25px; border-radius: 12px; box-shadow: 0 4px 20px rgba(0,0,0,0.08);">
    
    <!-- ფილტრის ფორმა -->
    <div class="filter-bar" style="background: #f8f9fa; padding: 20px; border-radius: 10px; margin-bottom: 25px;">
        <h3 style="margin-top: 0; margin-bottom: 15px; color: #333;">ფილტრაცია პერიოდის მიხედვით</h3>
        <form method="GET" style="display: flex; align-items: center; gap: 15px; flex-wrap: wrap;">
            <div style="display: flex; align-items: center; gap: 8px;">
                <label style="font-weight: 600; color: #555;">დან:</label>
                <input type="date" name="date_from" value="<?= $date_from ?>" 
                       style="padding: 10px 15px; border: 2px solid #ddd; border-radius: 8px; font-size: 14px;">
            </div>
            <div style="display: flex; align-items: center; gap: 8px;">
                <label style="font-weight: 600; color: #555;">მდე:</label>
                <input type="date" name="date_to" value="<?= $date_to ?>" 
                       style="padding: 10px 15px; border: 2px solid #ddd; border-radius: 8px; font-size: 14px;">
            </div>
            <button type="submit" class="btn btn-blue" style="padding: 10px 20px;">
                🔍 გაფილტვრა
            </button>
            <a href="reports.php" class="btn btn-gray" style="padding: 10px 20px;">
                🗑️ გასუფთავება
            </a>
        </form>
    </div>

    <!-- სტატისტიკის ბარათები -->
    <div class="stat-cards" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px; margin-bottom: 30px;">
        <div class="stat-card" style="border-color: #17a2b8; background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);">
            <h4 style="color: #17a2b8; font-size: 14px; margin-bottom: 10px;">📊 ნავაჭრი</h4>
            <div class="stat-value" style="color: #17a2b8; font-size: 2em;">
                <?= number_format($total_revenue, 2) ?> ₾
            </div>
            <p style="color: #666; font-size: 13px; margin-top: 5px;">მთლიანი შემოსავალი</p>
        </div>
        
        <div class="stat-card" style="border-color: #dc3545; background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);">
            <h4 style="color: #dc3545; font-size: 14px; margin-bottom: 10px;">💰 თვითღირებულება</h4>
            <div class="stat-value" style="color: #dc3545; font-size: 2em;">
                <?= number_format($total_cost, 2) ?> ₾
            </div>
            <p style="color: #666; font-size: 13px; margin-top: 5px;">მთლიანი ხარჯი</p>
        </div>
        
        <div class="stat-card" style="border-color: #28a745; background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);">
            <h4 style="color: #28a745; font-size: 14px; margin-bottom: 10px;">💵 მოგება</h4>
            <div class="stat-value" style="color: #28a745; font-size: 2em;">
                <?= number_format($total_profit, 2) ?> ₾
            </div>
            <p style="color: #666; font-size: 13px; margin-top: 5px;">
                <?= $total_profit >= 0 ? 'წმინდა მოგება' : 'ზარალი' ?>
            </p>
        </div>
        
        <div class="stat-card" style="border-color: #6f42c1; background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);">
            <h4 style="color: #6f42c1; font-size: 14px; margin-bottom: 10px;">📦 გაყიდული რაოდენობა</h4>
            <div class="stat-value" style="color: #6f42c1; font-size: 2em;">
                <?= number_format($total_quantity, 3) ?>
            </div>
            <p style="color: #666; font-size: 13px; margin-top: 5px;">ჯამური რაოდენობა</p>
        </div>
    </div>

    <!-- ცხრილი -->
    <div class="table-container">
        <h2 style="margin-top: 0; padding-bottom: 15px; border-bottom: 2px solid #f0f0f0; color: #333; font-size: 1.5em;">
            📈 გაყიდვების დეტალური რეპორტი
        </h2>
        
        <?php if(empty($sales)): ?>
            <div class="empty-message" style="text-align: center; padding: 40px; background: #f8f9fa; border-radius: 8px; margin: 20px 0;">
                <h3 style="color: #666; margin-bottom: 10px;">📭 გაყიდვების რეპორტი ცარიელია</h3>
                <p style="color: #888;">არჩეულ პერიოდში არ არის გაყიდვები</p>
                <p style="color: #888; font-size: 14px;">გთხოვთ აირჩიოთ სხვა პერიოდი</p>
            </div>
        <?php else: ?>
            <table id="reportsTable" class="display compact" style="width:100%">
                <thead>
                    <tr>
                        <th>თარიღი</th>
                        <th>კერძი</th>
                        <th>რაოდენობა</th>
                        <th>თვითღირებულება</th>
                        <th>გასაყიდი ფასი</th>
                        <th>მოგება</th>
                        <th>მომგებიანობა</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($sales as $s): 
                        $rev = $s['sale_price'] * $s['quantity'];
                        $prof = $rev - $s['total_amount'];
                        $profitability = $s['total_amount'] > 0 ? ($prof / $s['total_amount']) * 100 : 0;
                    ?>
                    <tr>
                        <td>
                            <?= date('d.m.Y', strtotime($s['sale_date'])) ?><br>
                            <small style="color: #888;"><?= date('H:i', strtotime($s['sale_date'])) ?></small>
                        </td>
                        <td><strong><?= htmlspecialchars($s['dish_name']) ?></strong></td>
                        <td style="text-align: center;"><?= number_format($s['quantity'], 3) ?></td>
                        <td style="text-align: right; color: #dc3545; font-weight: 600;">
                            <?= number_format($s['total_amount'], 2) ?> ₾
                        </td>
                        <td style="text-align: right;"><?= number_format($s['sale_price'], 2) ?> ₾</td>
                        <td style="text-align: right; <?= $prof >= 0 ? 'color: #28a745;' : 'color: #dc3545;' ?> font-weight: 600;">
                            <?= number_format($prof, 2) ?> ₾
                        </td>
                        <td style="text-align: center;">
                            <span style="display: inline-block; padding: 4px 8px; border-radius: 4px; font-size: 12px; font-weight: 600; 
                                <?= $profitability >= 20 ? 'background: #d4edda; color: #155724;' : 
                                   ($profitability >= 0 ? 'background: #fff3cd; color: #856404;' : 
                                   'background: #f8d7da; color: #721c24;') ?>">
                                <?= number_format($profitability, 1) ?>%
                            </span>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
                <tfoot>
                    <tr style="background: #f8f9fa; font-weight: bold;">
                        <td colspan="2" style="text-align: right;">ჯამი:</td>
                        <td style="text-align: center;"><?= number_format($total_quantity, 3) ?></td>
                        <td style="text-align: right; color: #dc3545;"><?= number_format($total_cost, 2) ?> ₾</td>
                        <td style="text-align: right;">-</td>
                        <td style="text-align: right; <?= $total_profit >= 0 ? 'color: #28a745;' : 'color: #dc3545;' ?>">
                            <?= number_format($total_profit, 2) ?> ₾
                        </td>
                        <td style="text-align: center;">
                            <?php 
                            $avg_profitability = $total_cost > 0 ? ($total_profit / $total_cost) * 100 : 0;
                            ?>
                            <span style="display: inline-block; padding: 4px 8px; border-radius: 4px; font-size: 12px; font-weight: 600; 
                                <?= $avg_profitability >= 20 ? 'background: #d4edda; color: #155724;' : 
                                   ($avg_profitability >= 0 ? 'background: #fff3cd; color: #856404;' : 
                                   'background: #f8d7da; color: #721c24;') ?>">
                                <?= number_format($avg_profitability, 1) ?>%
                            </span>
                        </td>
                    </tr>
                </tfoot>
            </table>
        <?php endif; ?>
    </div>
</div>

<script>
$(document).ready(function() {
    <?php if(!empty($sales)): ?>
    // DataTable ინიციალიზაცია
    $('#reportsTable').DataTable({
        "language": {
            "url": "//cdn.datatables.net/plug-ins/1.11.5/i18n/ka.json"
        },
        "pageLength": 25,
        "lengthMenu": [10, 25, 50, 100],
        "order": [[0, "desc"]],
        "responsive": true,
        "dom": '<"top"lf>rt<"bottom"ip><"clear">',
        "columnDefs": [
            { 
                "targets": [0, 2, 3, 4, 5, 6], 
                "className": "dt-center"
            }
        ],
        "footerCallback": function (row, data, start, end, display) {
            // ფუტერის ცვლილებები ავტომატურად მუშავდება
        }
    });
    <?php endif; ?>
    
    // დროის შევსება
    $('input[type="date"]').each(function() {
        if (!$(this).val()) {
            $(this).val(new Date().toISOString().split('T')[0]);
        }
    });
    
    // ექსპორტის ფუნქცია (სურვილისამებრ)
    function exportToCSV() {
        let csv = [];
        let rows = document.querySelectorAll("#reportsTable tr");
        
        for (let i = 0; i < rows.length; i++) {
            let row = [], cols = rows[i].querySelectorAll("td, th");
            
            for (let j = 0; j < cols.length; j++) {
                row.push(cols[j].innerText);
            }
            
            csv.push(row.join(","));
        }
        
        let csvContent = csv.join("\n");
        let blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        let link = document.createElement("a");
        let url = URL.createObjectURL(blob);
        
        link.setAttribute("href", url);
        link.setAttribute("download", "გაყიდვების_რეპორტი_<?= $date_from ?>_<?= $date_to ?>.csv");
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }
    
    // ექსპორტის ღილაკის დამატება
    $('.table-container h2').append(
        '<button onclick="exportToCSV()" class="btn btn-green" style="float: right; padding: 8px 15px; font-size: 14px; margin-left: 10px;">📥 CSV ექსპორტი</button>'
    );
});
</script>

<?php
// ===========================================
// ფუტერის ჩასმა აქ (მთავარი კონტენტის ბოლოს)
// ===========================================
include '../includes/footer.php'; // ეს ჩაიტვირთება footer.php ფაილი
// ===========================================
?>