<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../config/db.php';

$dish_id = intval($_GET['dish_id'] ?? 0);

if ($dish_id <= 0) {
    echo json_encode(['status' => 0, 'message' => 'არასწორი კერძი']);
    exit;
}

try {
    // 1. კერძის მონაცემები
    $stmt = $mysqli->prepare("SELECT * FROM dishes WHERE id = ?");
    $stmt->bind_param("i", $dish_id);
    $stmt->execute();
    $dish_result = $stmt->get_result();
    $dish = $dish_result->fetch_assoc();
    $stmt->close();
    
    if (!$dish) {
        echo json_encode(['status' => 0, 'message' => 'კერძი არ მოიძებნა']);
        exit;
    }
    
    // გადავიყვანოთ sale_price რიცხვში
    $dish['sale_price'] = floatval($dish['sale_price']);
    
    // 2. რეცეპტის ინგრედიენტები (უსაფრთხო SQL - ვამოწმებთ სვეტის არსებობას)
    $check_column = $mysqli->query("SHOW COLUMNS FROM products LIKE 'has_vat'");
    $has_vat_column_exists = $check_column->num_rows > 0;
    
    if ($has_vat_column_exists) {
        $sql = "SELECT dc.id, dc.dish_id, dc.product_id, dc.quantity, dc.unit, dc.yield_coeff,
                       p.name as product_name, p.price, p.has_vat
                FROM dish_calc dc 
                JOIN products p ON dc.product_id = p.id 
                WHERE dc.dish_id = ?";
    } else {
        $sql = "SELECT dc.id, dc.dish_id, dc.product_id, dc.quantity, dc.unit, dc.yield_coeff,
                       p.name as product_name, p.price, 1 as has_vat
                FROM dish_calc dc 
                JOIN products p ON dc.product_id = p.id 
                WHERE dc.dish_id = ?";
    }
    
    $stmt = $mysqli->prepare($sql);
    $stmt->bind_param("i", $dish_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $raw_items = $result->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
    
    // 3. მონაცემთა გადამუშავება
    $items = [];
    $total_cost_with_vat = 0;
    $total_cost_excluding_vat = 0;
    
    foreach ($raw_items as $raw_item) {
        // გადავიყვანოთ ყველა რიცხვითი ველი
        $item = [
            'id' => intval($raw_item['id']),
            'dish_id' => intval($raw_item['dish_id']),
            'product_id' => intval($raw_item['product_id']),
            'quantity' => floatval($raw_item['quantity']),
            'unit' => $raw_item['unit'],
            'yield_coeff' => floatval($raw_item['yield_coeff']),
            'product_name' => $raw_item['product_name'],
            'price' => floatval($raw_item['price']),
            'has_vat' => isset($raw_item['has_vat']) ? intval($raw_item['has_vat']) : 1
        ];
        
        // ღირებულების გაანგარიშება
        $cost_with_vat = $item['quantity'] * $item['price'];
        $cost_excluding_vat = $item['has_vat'] ? $cost_with_vat / 1.18 : $cost_with_vat;
        
        $item['cost_details'] = [
            'cost_with_vat' => $cost_with_vat,
            'cost_excluding_vat' => $cost_excluding_vat,
            'cost_percentage' => 0
        ];
        
        $total_cost_with_vat += $cost_with_vat;
        $total_cost_excluding_vat += $cost_excluding_vat;
        
        $items[] = $item;
    }
    
    // პროცენტული განაწილების გაანგარიშება
    foreach ($items as &$item) {
        if ($total_cost_with_vat > 0) {
            $item['cost_details']['cost_percentage'] = 
                ($item['cost_details']['cost_with_vat'] / $total_cost_with_vat) * 100;
        }
    }
    
    // 4. შემოსავალი და მოგება
    $revenue_with_vat = $dish['sale_price'];
    $revenue_excluding_vat = $revenue_with_vat / 1.18;
    $vat_on_revenue = $revenue_with_vat * 0.18;
    $profit_excluding_vat = $revenue_excluding_vat - $total_cost_excluding_vat;
    
    $margin_percent_excluding_vat = $total_cost_excluding_vat > 0 ? 
        ($profit_excluding_vat / $total_cost_excluding_vat) * 100 : 0;
    
    $profitability = $revenue_excluding_vat > 0 ? 
        ($profit_excluding_vat / $revenue_excluding_vat) * 100 : 0;
    
    // 5. პასუხი
    echo json_encode([
        'status' => 1,
        'message' => 'წარმატებით',
        'dish' => [
            'id' => intval($dish['id']),
            'name' => $dish['name'],
            'sale_price' => floatval($dish['sale_price']),
            'description' => $dish['description'] ?? ''
        ],
        'items' => $items,
        'summary' => [
            'cost_summary' => [
                'total_cost_with_vat' => floatval($total_cost_with_vat),
                'total_cost_excluding_vat' => floatval($total_cost_excluding_vat)
            ],
            'revenue_summary' => [
                'revenue_with_vat' => floatval($revenue_with_vat),
                'revenue_excluding_vat' => floatval($revenue_excluding_vat),
                'vat_on_revenue' => floatval($vat_on_revenue)
            ],
            'profit_summary' => [
                'profit_excluding_vat' => floatval($profit_excluding_vat),
                'margin_percent_excluding_vat' => floatval($margin_percent_excluding_vat),
                'profitability' => floatval($profitability)
            ],
            'debug' => [
                'has_vat_column_exists' => $has_vat_column_exists,
                'total_items' => count($items)
            ]
        ]
    ]);
    
} catch (Exception $e) {
    echo json_encode([
        'status' => 0, 
        'message' => 'შეცდომა: ' . $e->getMessage(),
        'error' => $e->getMessage(),
        'trace' => $e->getTraceAsString()
    ]);
}