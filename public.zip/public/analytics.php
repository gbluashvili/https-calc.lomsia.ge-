<?php
require_once __DIR__ . '/../config/db.php';

// თარიღების დიაპაზონის განსაზღვრა
$date_from = $_GET['from'] ?? date('Y-m-d', strtotime('-7 days'));
$date_to   = $_GET['to'] ?? date('Y-m-d');

// 1. ფინანსური შეჯამება არჩეული პერიოდისთვის
$stats_query = $mysqli->prepare("
    SELECT 
        SUM(s.total_amount) as revenue,
        SUM(
            (SELECT SUM(IF(dc.unit = 'გრ', dc.quantity/1000, dc.quantity) * p.price)
             FROM dish_calc dc 
             JOIN products p ON dc.product_id = p.id 
             WHERE dc.dish_id = s.dish_id) * s.quantity
        ) as cost
    FROM sales s
    WHERE DATE(s.sale_date) BETWEEN ? AND ?
");
$stats_query->bind_param("ss", $date_from, $date_to);
$stats_query->execute();
$stats = $stats_query->get_result()->fetch_assoc();

$revenue = $stats['revenue'] ?? 0;
$cost = $stats['cost'] ?? 0;
$profit = $revenue - $cost;

// 2. გაყიდვების დინამიკა (გრაფიკისთვის)
$sales_q = $mysqli->prepare("
    SELECT DATE(sale_date) as date, SUM(total_amount) as total 
    FROM sales 
    WHERE DATE(sale_date) BETWEEN ? AND ?
    GROUP BY DATE(sale_date)
    ORDER BY date ASC
");
$sales_q->bind_param("ss", $date_from, $date_to);
$sales_q->execute();
$sales_data = $sales_q->get_result()->fetch_all(MYSQLI_ASSOC);

// 3. პოპულარული კერძები
$dishes_q = $mysqli->prepare("
    SELECT d.name, SUM(s.quantity) as qty 
    FROM sales s 
    JOIN dishes d ON s.dish_id = d.id 
    WHERE DATE(s.sale_date) BETWEEN ? AND ?
    GROUP BY s.dish_id 
    ORDER BY qty DESC LIMIT 5
");
$dishes_q->bind_param("ss", $date_from, $date_to);
$dishes_q->execute();
$top_dishes = $dishes_q->get_result()->fetch_all(MYSQLI_ASSOC);

// 4. დანაკარგები
$waste_q = $mysqli->prepare("
    SELECT reason, SUM(quantity) as qty 
    FROM waste 
    WHERE DATE(waste_date) BETWEEN ? AND ?
    GROUP BY reason
");
$waste_q->bind_param("ss", $date_from, $date_to);
$waste_q->execute();
$waste_reasons = $waste_q->get_result()->fetch_all(MYSQLI_ASSOC);

// ===========================================
// ჰედერის ჩასმა აქ
// ===========================================
$page_title = "ბიზნეს ანალიტიკა"; // ეს გადაეცემა ჰედერს
include '../includes/header.php'; // ეს ჩაიტვირთება header.php ფაილი
// ===========================================
?>

<!-- მთავარი კონტენტი იწყება აქ (ჰედერის შემდეგ) -->

<!-- ამოიღეთ ძველი ნავიგაცია, რადგან ის უკვე ჰედერშია -->
<!-- 
<div style="display: flex; justify-content: space-between; align-items: center;">
    <a href="index.php" class="nav-btn">← უკან დაბრუნება</a>
    <h2>📊 ბიზნეს ანალიტიკა</h2>
</div>
-->

<div class="filter-bar" style="margin-top: 20px;">
    <form method="GET" style="display: flex; align-items: center; gap: 15px; flex-wrap: wrap;">
        <div style="display: flex; align-items: center; gap: 5px;">
            <label style="font-weight: 600;">დან:</label>
            <input type="date" name="from" value="<?= $date_from ?>" style="padding: 8px; border: 2px solid #e0e0e0; border-radius: 8px;">
        </div>
        <div style="display: flex; align-items: center; gap: 5px;">
            <label style="font-weight: 600;">მდე:</label>
            <input type="date" name="to" value="<?= $date_to ?>" style="padding: 8px; border: 2px solid #e0e0e0; border-radius: 8px;">
        </div>
        <button type="submit" class="btn btn-green" style="padding: 8px 15px;">გაფილტვრა</button>
        <a href="analytics.php" class="btn btn-gray" style="padding: 8px 15px;">გასუფთავება</a>
    </form>
</div>

<div class="stat-cards" style="margin: 20px 0;">
    <div class="stat-card" style="border-color: #007bff;">
        <h4>შემოსავალი პერიოდში</h4>
        <div class="stat-value" style="color: #007bff;"><?= number_format($revenue, 2) ?> ₾</div>
    </div>
    <div class="stat-card" style="border-color: #dc3545;">
        <h4>თვითღირებულება</h4>
        <div class="stat-value" style="color: #dc3545;"><?= number_format($cost, 2) ?> ₾</div>
    </div>
    <div class="stat-card" style="border-color: #28a745;">
        <h4>წმინდა მოგება</h4>
        <div class="stat-value" style="color: #28a745;"><?= number_format($profit, 2) ?> ₾</div>
    </div>
</div>

<div class="grid" style="display: grid; grid-template-columns: 2fr 1fr; gap: 20px; margin-top: 30px;">
    <div class="card">
        <h3 style="margin-top: 0; padding-bottom: 15px; border-bottom: 2px solid #f0f0f0;">📈 შემოსავლების დინამიკა</h3>
        <canvas id="salesChart" height="100"></canvas>
    </div>
    
    <div style="display: flex; flex-direction: column; gap: 20px;">
        <div class="card">
            <h3 style="margin-top: 0; padding-bottom: 15px; border-bottom: 2px solid #f0f0f0;">🏆 ტოპ 5 გაყიდვადი კერძი</h3>
            <canvas id="dishesChart"></canvas>
        </div>
        
        <div class="card">
            <h3 style="margin-top: 0; padding-bottom: 15px; border-bottom: 2px solid #f0f0f0;">🗑️ დანაკარგების ანალიზი</h3>
            <canvas id="wasteChart"></canvas>
        </div>
    </div>
</div>

<script>
// უზრუნველყოთ, რომ Chart.js ჩაიტვირთოს
document.addEventListener('DOMContentLoaded', function() {
    // შემოსავლების გრაფიკი
    const salesCtx = document.getElementById('salesChart')?.getContext('2d');
    if (salesCtx) {
        new Chart(salesCtx, {
            type: 'line',
            data: {
                labels: <?= json_encode(array_column($sales_data, 'date')) ?>,
                datasets: [{
                    label: 'შემოსავალი (₾)',
                    data: <?= json_encode(array_column($sales_data, 'total')) ?>,
                    borderColor: '#007bff',
                    backgroundColor: 'rgba(0, 123, 255, 0.1)',
                    fill: true,
                    tension: 0.4,
                    borderWidth: 3
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                plugins: {
                    legend: {
                        display: true,
                        position: 'top'
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return value.toFixed(2) + ' ₾';
                            }
                        }
                    }
                }
            }
        });
    }
    
    // პოპულარული კერძების გრაფიკი
    const dishesCtx = document.getElementById('dishesChart')?.getContext('2d');
    if (dishesCtx) {
        new Chart(dishesCtx, {
            type: 'bar',
            data: {
                labels: <?= json_encode(array_column($top_dishes, 'name')) ?>,
                datasets: [{
                    label: 'რაოდენობა',
                    data: <?= json_encode(array_column($top_dishes, 'qty')) ?>,
                    backgroundColor: [
                        '#28a745',
                        '#20c997',
                        '#17a2b8',
                        '#007bff',
                        '#6610f2'
                    ],
                    borderColor: '#fff',
                    borderWidth: 2
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    }
    
    // დანაკარგების გრაფიკი
    const wasteCtx = document.getElementById('wasteChart')?.getContext('2d');
    if (wasteCtx) {
        new Chart(wasteCtx, {
            type: 'doughnut',
            data: {
                labels: <?= json_encode(array_column($waste_reasons, 'reason')) ?>,
                datasets: [{
                    data: <?= json_encode(array_column($waste_reasons, 'qty')) ?>,
                    backgroundColor: [
                        '#dc3545',
                        '#ffc107',
                        '#17a2b8',
                        '#6610f2',
                        '#e83e8c',
                        '#6f42c1'
                    ],
                    borderWidth: 2,
                    borderColor: '#fff'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                plugins: {
                    legend: {
                        position: 'bottom'
                    }
                }
            }
        });
    }
});
</script>

<?php
// ===========================================
// ფუტერის ჩასმა აქ (მთავარი კონტენტის ბოლოს)
// ===========================================
include '../includes/footer.php'; // ეს ჩაიტვირთება footer.php ფაილი
// ===========================================
?>