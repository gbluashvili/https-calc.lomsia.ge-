<?php
// ajax_add_ingredient.php
error_reporting(E_ALL);
ini_set('display_errors', 0);
header('Content-Type: application/json');

require_once __DIR__ . '/../config/db.php';

$res = ['status' => 0, 'message' => 'უცნობი შეცდომა'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $dish_id = isset($_POST['dish_id']) ? intval($_POST['dish_id']) : 0;
    $product_id = isset($_POST['product_id']) ? intval($_POST['product_id']) : 0;
    $quantity = isset($_POST['quantity']) ? floatval($_POST['quantity']) : 0;
    
    // ვალიდაცია
    if ($dish_id <= 0) {
        $res['message'] = 'არასწორი კერძის ID';
        echo json_encode($res);
        exit;
    }
    
    if ($product_id <= 0) {
        $res['message'] = 'არასწორი პროდუქტის ID';
        echo json_encode($res);
        exit;
    }
    
    if ($quantity <= 0) {
        $res['message'] = 'რაოდენობა უნდა იყოს 0-ზე მეტი';
        echo json_encode($res);
        exit;
    }
    
    try {
        // შეამოწმეთ არსებობს თუ არა კერძი
        $check_dish = $mysqli->prepare("SELECT id, name FROM dishes WHERE id = ?");
        $check_dish->bind_param("i", $dish_id);
        $check_dish->execute();
        $dish_result = $check_dish->get_result();
        
        if ($dish_result->num_rows === 0) {
            throw new Exception('კერძი არ მოიძებნა');
        }
        
        $dish = $dish_result->fetch_assoc();
        $check_dish->close();
        
        // შეამოწმეთ არსებობს თუ არა პროდუქტი
        $check_product = $mysqli->prepare("SELECT id, name, unit FROM products WHERE id = ?");
        $check_product->bind_param("i", $product_id);
        $check_product->execute();
        $product_result = $check_product->get_result();
        
        if ($product_result->num_rows === 0) {
            throw new Exception('პროდუქტი არ მოიძებნა');
        }
        
        $product = $product_result->fetch_assoc();
        $check_product->close();
        
        // შეამოწმეთ არის თუ არა უკვე დამატებული
        $check_exists = $mysqli->prepare("SELECT id FROM dish_calc WHERE dish_id = ? AND product_id = ?");
        $check_exists->bind_param("ii", $dish_id, $product_id);
        $check_exists->execute();
        $exists_result = $check_exists->get_result();
        
        if ($exists_result->num_rows > 0) {
            throw new Exception('ეს ინგრედიენტი უკვე დამატებულია ამ კერძში');
        }
        $check_exists->close();
        
        // დაამატეთ ახალი ინგრედიენტი
        $insert_stmt = $mysqli->prepare("INSERT INTO dish_calc (dish_id, product_id, quantity) VALUES (?, ?, ?)");
        $insert_stmt->bind_param("iid", $dish_id, $product_id, $quantity);
        
        if ($insert_stmt->execute()) {
            $res['status'] = 1;
            $res['message'] = 'ინგრედიენტი წარმატებით დაემატა';
            $res['insert_id'] = $insert_stmt->insert_id;
            $res['dish'] = [
                'id' => $dish_id,
                'name' => $dish['name']
            ];
            $res['product'] = [
                'id' => $product_id,
                'name' => $product['name'],
                'unit' => $product['unit']
            ];
        } else {
            throw new Exception('ბაზის შეცდომა: ' . $insert_stmt->error);
        }
        
        $insert_stmt->close();
        
    } catch (Exception $e) {
        $res['message'] = $e->getMessage();
        $res['debug'] = [
            'dish_id' => $dish_id,
            'product_id' => $product_id,
            'quantity' => $quantity
        ];
    }
} else {
    $res['message'] = 'არასწორი მოთხოვნის მეთოდი';
}

echo json_encode($res);
?>