<?php
header('Content-Type: application/json');
require_once '../config/db.php';

$dish_id = (int)($_POST['dish_id']??0);
$type = $_POST['discount_type']??'percent';
$value = (float)($_POST['discount_value']??0);
$start = $_POST['start_date']??null;
$end = $_POST['end_date']??null;
$category = $_POST['category']??null;

if($dish_id<=0 || $value<=0){
    echo json_encode(['status'=>0,'message'=>'Invalid data']);
    exit;
}

$stmt = $mysqli->prepare("
    INSERT INTO discounts (dish_id, discount_type, discount_value, start_date, end_date, category)
    VALUES (?,?,?,?,?,?)
");
$stmt->bind_param("isssss",$dish_id,$type,$value,$start,$end,$category);
$stmt->execute();

echo json_encode(['status'=>1,'message'=>'Discount saved']);
