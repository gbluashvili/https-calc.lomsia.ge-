<?php
header('Content-Type: application/json');
require_once __DIR__.'/../config/db.php';

$dish_id = intval($_POST['dish_id'] ?? 0);
$items = json_decode($_POST['items'] ?? '[]', true);

if(!$dish_id || !is_array($items) || empty($items)){
    echo json_encode(['status'=>0,'message'=>'Invalid data']);
    exit;
}

$mysqli->begin_transaction();

try {
    // წაშლა ძველი კალკულაციის დეტალების
    $stmt = $mysqli->prepare("DELETE FROM dish_products WHERE dish_id=?");
    $stmt->bind_param("i", $dish_id);
    $stmt->execute();

    foreach($items as $item){
        $product_id = intval($item['product_id']);
        $quantity = floatval($item['quantity']);

        // ამოღება არსებული პროდუქტი
        $res = $mysqli->query("SELECT quantity, price, vat_rate FROM products WHERE id=$product_id FOR UPDATE");
        if(!$res || $res->num_rows==0){
            throw new Exception("Product $product_id not found");
        }

        $prod = $res->fetch_assoc();
        $stock = floatval($prod['quantity']);
        $unit_price = floatval($prod['price']);

        if($quantity > $stock){
            throw new Exception("Not enough stock for product ID $product_id. Available: $stock");
        }

        // განახლება ნაშთის
        $new_stock = $stock - $quantity;
        $stmt = $mysqli->prepare("UPDATE products SET quantity=? WHERE id=?");
        $stmt->bind_param("di", $new_stock, $product_id);
        $stmt->execute();

        // კალკულაციის ფასის აღება (quantity * unit_price)
        $used_price = $unit_price * $quantity;

        // კალკულაციის ჩანაწერის შენახვა
        $stmt = $mysqli->prepare("INSERT INTO dish_products (dish_id, product_id, quantity, price) VALUES (?,?,?,?)");
        $stmt->bind_param("iidd", $dish_id, $product_id, $quantity, $used_price);
        $stmt->execute();
    }

    $mysqli->commit();
    echo json_encode(['status'=>1,'message'=>'Dish calculation saved successfully']);

} catch(Exception $e){
    $mysqli->rollback();
    echo json_encode(['status'=>0,'message'=>$e->getMessage()]);
}
