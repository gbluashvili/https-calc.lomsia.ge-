<?php
require_once __DIR__ . '/../config/db.php';

header('Content-Type: application/json');

$response = ['status' => 0, 'message' => ''];

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    $response['message'] = 'არასწორი მეთოდი';
    echo json_encode($response);
    exit;
}

$product_id = $_POST['product_id'] ?? 0;
$product_name = $_POST['product_name'] ?? '';
$quantity = $_POST['quantity'] ?? 0;
$unit = $_POST['unit'] ?? '';
$unit_price = $_POST['unit_price'] ?? 0;
$total_price = $_POST['total_price'] ?? 0;
$comment = $_POST['comment'] ?? '';

// მონაცემების ვალიდაცია
if ($product_id <= 0 || $quantity <= 0 || $unit_price <= 0) {
    $response['message'] = 'არასწორი მონაცემები';
    echo json_encode($response);
    exit;
}

try {
    // შევამოწმოთ არსებობს თუ არა ცხრილი, თუ არა - შევქმნათ
    $table_check = $mysqli->query("SHOW TABLES LIKE 'sales_history'");
    if ($table_check->num_rows === 0) {
        $create_table = $mysqli->query("
            CREATE TABLE sales_history (
                id INT AUTO_INCREMENT PRIMARY KEY,
                product_id INT NOT NULL,
                product_name VARCHAR(255) NOT NULL,
                quantity DECIMAL(10,3) NOT NULL,
                unit VARCHAR(20) NOT NULL,
                unit_price DECIMAL(10,2) NOT NULL,
                total_price DECIMAL(10,2) NOT NULL,
                sale_date DATETIME DEFAULT CURRENT_TIMESTAMP,
                comment TEXT,
                FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE SET NULL
            )
        ");
        
        if (!$create_table) {
            $response['message'] = 'ცხრილის შექმნის შეცდომა: ' . $mysqli->error;
            echo json_encode($response);
            exit;
        }
    }
    
    // ჩანაწერის დამატება
    $stmt = $mysqli->prepare("
        INSERT INTO sales_history 
        (product_id, product_name, quantity, unit, unit_price, total_price, comment) 
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ");
    
    if ($stmt) {
        $stmt->bind_param(
            'isddsds', 
            $product_id, 
            $product_name,
            $quantity,
            $unit,
            $unit_price,
            $total_price,
            $comment
        );
        
        if ($stmt->execute()) {
            $response['status'] = 1;
            $response['message'] = 'გაყიდვა ჩაიწერა წარმატებით';
        } else {
            $response['message'] = 'ჩაწერის შეცდომა: ' . $stmt->error;
        }
        $stmt->close();
    } else {
        $response['message'] = 'SQL შეცდომა: ' . $mysqli->error;
    }
    
} catch (Exception $e) {
    $response['message'] = 'გაუთვალისწინებელი შეცდომა: ' . $e->getMessage();
}

echo json_encode($response);
exit;