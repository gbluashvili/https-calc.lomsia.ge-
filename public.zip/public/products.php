<?php
// products.php
?>
<!DOCTYPE html>
<html lang="ka">
<head>
<meta charset="UTF-8">
<title>პროდუქტების მართვა</title>
<style>
body { font-family: Arial; padding:20px; }
table { border-collapse: collapse; width:100%; margin-top:15px; }
th, td { border:1px solid #ccc; padding:8px; text-align:center; }
input, select { padding:5px; width:150px; }
button { padding:5px 10px; cursor:pointer; }
form { margin-bottom:20px; background:#f5f5f5; padding:15px; }
</style>
</head>
<body>

<h2>პროდუქტის დამატება / რედაქტირება</h2>

<form id="productForm">
    <input type="hidden" id="product_id">

    სახელი:
    <input type="text" name="name" required>

    ერთეული:
    <select name="unit">
        <option value="კგ">კგ</option>
        <option value="გრ">გრ</option>
        <option value="ლიტრი">ლიტრი</option>
        <option value="ცალი">ცალი</option>
    </select>

    ნაშთი:
    <input type="number" name="quantity" step="0.001" value="0">

    ფასი:
    <input type="number" name="price" step="0.01" required>

    VAT %:
    <input type="number" name="vat_rate" step="0.01" value="18">

    <button type="submit">შენახვა</button>
    <button type="button" onclick="resetForm()">გაუქმება</button>
</form>

<hr>

<h2>პროდუქტების სია</h2>
<table id="productTable"></table>

<script>
let editId = 0;

// ---------- LOAD PRODUCTS ----------
function loadProducts() {
    fetch('ajax_get_products.php')
        .then(r => r.json())
        .then(res => {
            let html = `
            <tr>
                <th>ID</th>
                <th>სახელი</th>
                <th>ნაშთი</th>
                <th>ერთეული</th>
                <th>ფასი</th>
                <th>VAT %</th>
                <th>ქმედება</th>
            </tr>`;

            res.data.forEach(p => {
                html += `
                <tr>
                    <td>${p.id}</td>
                    <td>${p.name}</td>
                    <td>${p.quantity}</td>
                    <td>${p.unit}</td>
                    <td>${p.price}</td>
                    <td>${p.vat_rate}</td>
                    <td>
                        <button onclick="editProduct(${p.id})">✏️</button>
                        <button onclick="deleteProduct(${p.id})">🗑️</button>
                    </td>
                </tr>`;
            });

            document.getElementById('productTable').innerHTML = html;
        });
}

// ---------- ADD / UPDATE ----------
document.getElementById('productForm').onsubmit = e => {
    e.preventDefault();

    let fd = new FormData(e.target);
    if (editId > 0) fd.append('id', editId);

    fetch('ajax_add_product.php', {
        method: 'POST',
        body: fd
    })
    .then(r => r.json())
    .then(res => {
        if (res.status == 1) {
            resetForm();
            loadProducts();
        } else {
            alert(res.message || 'შეცდომა');
        }
    });
};

// ---------- EDIT ----------
function editProduct(id) {
    fetch('ajax_get_products.php')
        .then(r => r.json())
        .then(res => {
            const p = res.data.find(x => x.id == id);
            if (!p) return;

            editId = p.id;
            document.querySelector('[name="name"]').value = p.name;
            document.querySelector('[name="unit"]').value = p.unit;
            document.querySelector('[name="quantity"]').value = p.quantity;
            document.querySelector('[name="price"]').value = p.price;
            document.querySelector('[name="vat_rate"]').value = p.vat_rate;
        });
}

// ---------- DELETE ----------
function deleteProduct(id) {
    if (!confirm('დარწმუნებული ხარ რომ გინდა წაშლა?')) return;

    fetch('ajax_delete_product.php', {
        method: 'POST',
        headers: {'Content-Type':'application/x-www-form-urlencoded'},
        body: 'id=' + id
    })
    .then(r => r.json())
    .then(res => {
        if(res.status == 1){
            loadProducts();
        } else {
            alert(res.message || 'წაშლა ვერ მოხერხდა');
        }
    });
}

// ---------- RESET ----------
function resetForm() {
    editId = 0;
    document.getElementById('productForm').reset();
}

// INIT
loadProducts();
</script>

</body>
</html>
