<?php
require_once __DIR__ . '/../config/db.php';

$product_id = $_POST['product_id'] ?? 0;
$quantity = $_POST['quantity'] ?? 0;
$reason = $_POST['reason'] ?? '';
$note = $_POST['note'] ?? '';

if ($product_id <= 0 || $quantity <= 0) {
    echo json_encode(['status' => 0, 'message' => 'არასწორი მონაცემები']);
    exit;
}

// დამატება waste ცხრილში
$mysqli->query("INSERT INTO waste (product_id, quantity, reason, note) 
                VALUES ($product_id, $quantity, '$reason', '$note')");

// პროდუქტის ნაშთის განახლება (შემცირება)
$mysqli->query("UPDATE products SET quantity = quantity - $quantity WHERE id = $product_id");

echo json_encode(['status' => 1, 'message' => 'ჩამოწერა დაემატა']);
?>