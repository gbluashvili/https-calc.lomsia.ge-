<?php
// test_connection.php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/../config/db.php';

echo "<h3>კავშირის ტესტი</h3>";

if (!$mysqli) {
    die("ბაზასთან დაკავშირება ვერ მოხერხდა: " . ($mysqli->connect_error ?? "Unknown error"));
}

echo "ბაზასთან დაკავშირება წარმატებულია<br>";

// ცხრილის შემოწმება
$result = $mysqli->query("SHOW TABLES LIKE 'products'");
if ($result && $result->num_rows > 0) {
    echo "products ცხრილი არსებობს<br>";
    
    // მოდით ვნახოთ სტრუქტურა
    $result2 = $mysqli->query("DESCRIBE products");
    echo "<h4>products ცხრილის სტრუქტურა:</h4>";
    echo "<table border='1'><tr><th>Field</th><th>Type</th><th>Null</th><th>Key</th><th>Default</th></tr>";
    while ($row = $result2->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row['Field'] . "</td>";
        echo "<td>" . $row['Type'] . "</td>";
        echo "<td>" . $row['Null'] . "</td>";
        echo "<td>" . $row['Key'] . "</td>";
        echo "<td>" . $row['Default'] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "products ცხრილი არ არსებობს<br>";
}

$mysqli->close();
?>