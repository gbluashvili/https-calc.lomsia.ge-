<?php
require_once __DIR__.'/../config/db.php';
require_once __DIR__.'/../functions/getDishes.php';

$dishes = getDishes($mysqli);
?>
<!DOCTYPE html>
<html lang="ka">
<head>
<meta charset="UTF-8">
<title>კერძები</title>
<style>
table { border-collapse: collapse; width:80%; }
th,td { border:1px solid #ccc; padding:8px; text-align:center; }
button { padding:5px 10px; }
</style>
</head>
<body>

<h2>კერძები</h2>

<form id="dishForm">
    <input type="hidden" name="id" id="dish_id">
    სახელი:
    <input type="text" name="name" id="dish_name" required>
    VAT:
    <input type="checkbox" disabled>
    <button>შენახვა</button>
</form>

<br>

<table>
<tr>
    <th>ID</th>
    <th>სახელი</th>
    <th>VAT</th>
    <th>ქმედება</th>
</tr>

<?php foreach($dishes as $d): ?>
<tr>
    <td><?= $d['id'] ?></td>
    <td><?= htmlspecialchars($d['name']) ?></td>
    <td><?= $d['enable_vat'] ? 'კი' : 'არა' ?></td>
    <td>
        <a href="dish_products.php?dish_id=<?= $d['id'] ?>">რეცეპტი</a>
        <button onclick="deleteDish(<?= $d['id'] ?>)">წაშლა</button>
    </td>
</tr>
<?php endforeach; ?>
</table>

<script>
document.getElementById('dishForm').onsubmit = e => {
    e.preventDefault();
    fetch('ajax_save_dish.php', {
        method:'POST',
        body:new FormData(e.target)
    }).then(()=>location.reload());
};

function deleteDish(id){
    if(confirm('წავშალო?')){
        fetch('ajax_delete_dish.php',{
            method:'POST',
            headers:{'Content-Type':'application/x-www-form-urlencoded'},
            body:'id='+id
        }).then(()=>location.reload());
    }
}
</script>

</body>
</html>
