<?php
// save_product.php
error_reporting(E_ALL);
ini_set('display_errors', 0);

header('Content-Type: application/json');

require_once __DIR__ . '/../config/db.php';

$res = ['success' => false, 'message' => 'უცნობი შეცდომა'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    // მონაცემების მიღება
    $id          = isset($_POST['id']) ? intval($_POST['id']) : 0;
    $name        = isset($_POST['name']) ? $mysqli->real_escape_string(trim($_POST['name'])) : '';
    $unit        = isset($_POST['unit']) ? $mysqli->real_escape_string(trim($_POST['unit'])) : 'კგ';
    $quantity    = isset($_POST['quantity']) ? floatval($_POST['quantity']) : 0;
    $price       = isset($_POST['price']) ? floatval($_POST['price']) : 0;
    $min_limit   = isset($_POST['min_limit']) ? floatval($_POST['min_limit']) : 0;
    $vat_checked = isset($_POST['vat']) ? intval($_POST['vat']) : 0;
    
    // VAT rate დაფიქსირებული 18% ან 0%
    $vat_rate = $vat_checked ? 18.00 : 0.00;
    $vat_status = $vat_checked ? 'დღგ-თი' : 'დღგ-ის გარეშე';
    
    // სხვა ველებისთვის დეფოლტი მნიშვნელობები
    $stock_quantity = $quantity; // ნაშთი = quantity
    $price_per_kg = ($unit == 'კგ') ? $price : 0; // მხოლოდ კგ-ზე

    if (empty($name)) {
        $res['message'] = 'დასახელება აუცილებელია!';
        echo json_encode($res);
        exit;
    }

    try {
        if ($id > 0) {
            // რედაქტირება - მოვერგოთ თქვენს ცხრილის სტრუქტურას
            $sql = "UPDATE products SET 
                    name = '$name', 
                    unit = '$unit', 
                    quantity = '$quantity', 
                    price = '$price', 
                    min_quantity = '$min_limit',  -- min_limit -> min_quantity
                    vat_rate = '$vat_rate',
                    vat_status = '$vat_status',
                    stock_quantity = '$stock_quantity',
                    price_per_kg = '$price_per_kg'
                    WHERE id = $id";
            
            if ($mysqli->query($sql)) {
                $res['success'] = true;
                $res['message'] = 'მონაცემები წარმატებით განახლდა';
            } else {
                throw new Exception('ბაზის შეცდომა განახლებისას: ' . $mysqli->error);
            }

        } else {
            // ახალი პროდუქტი
            $sql = "INSERT INTO products (
                    name, unit, quantity, price, 
                    min_quantity, vat_rate, vat_status, 
                    stock_quantity, price_per_kg
                ) VALUES (
                    '$name', '$unit', '$quantity', '$price',
                    '$min_limit', '$vat_rate', '$vat_status',
                    '$stock_quantity', '$price_per_kg'
                )";
            
            if ($mysqli->query($sql)) {
                $res['success'] = true;
                $res['message'] = 'პროდუქტი წარმატებით დაემატა';
                $res['insert_id'] = $mysqli->insert_id;
            } else {
                throw new Exception('ბაზის შეცდომა დამატებისას: ' . $mysqli->error);
            }
        }
        
    } catch (Exception $e) {
        $res['message'] = $e->getMessage();
    }
    
} else {
    $res['message'] = 'არასწორი მოთხოვნის მეთოდი';
}

echo json_encode($res);
?>